package io.github.xjrga.snack.interfaces;

/**
 *
 * @author jr
 */
public interface ShowCategory {

    void showCategory( int option );
}
