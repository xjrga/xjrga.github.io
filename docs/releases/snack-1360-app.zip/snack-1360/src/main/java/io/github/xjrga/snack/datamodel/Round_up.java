package io.github.xjrga.snack.datamodel;

public interface Round_up {
  void set_precision(Integer precision);
}
