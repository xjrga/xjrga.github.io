package io.github.xjrga.snack.datamodel;

public interface Reload_mixid {
  void reload(String mixid);
}
