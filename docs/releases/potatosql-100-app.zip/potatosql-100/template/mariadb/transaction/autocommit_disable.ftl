SET autocommit=0;
/
