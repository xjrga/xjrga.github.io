DELETE FROM ${table.name};
/
