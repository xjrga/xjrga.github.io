package io.github.xjrga.snack.gui;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import io.github.xjrga.snack.csv.DriReport;
import io.github.xjrga.snack.csv.FoodComparisonReport;
import io.github.xjrga.snack.csv.MD5MixResults;
import io.github.xjrga.snack.csv.MealPlanCaloriesReport;
import io.github.xjrga.snack.csv.MealPlanMacronutrientsReport;
import io.github.xjrga.snack.csv.MealPlanPortionsReport;
import io.github.xjrga.snack.csv.MealPlanUsageReport;
import io.github.xjrga.snack.csv.MixComparisonReport;
import io.github.xjrga.snack.csv.MixResultsReport;
import io.github.xjrga.snack.csv.MixResultsReportDn;
import io.github.xjrga.snack.csv.MixTotalsReport;
import io.github.xjrga.snack.csv.NutrientContentReport;
import io.github.xjrga.snack.database.Connect;
import io.github.xjrga.snack.database.callable.FoodCreator;
import io.github.xjrga.snack.database.callable.delete.DeleteAllFoodCategoriesTask;
import io.github.xjrga.snack.database.callable.delete.DeleteAllFoodsTask;
import io.github.xjrga.snack.database.callable.delete.DeleteAllMixesTask;
import io.github.xjrga.snack.database.callable.delete.DeleteCategoryLinkTask;
import io.github.xjrga.snack.database.callable.delete.DeleteCategoryTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodConstraintTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodGroupConstraintTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodGroupTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodInFoodGroupTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodPortionTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodRatioConstraintTask;
import io.github.xjrga.snack.database.callable.delete.DeleteFoodTask;
import io.github.xjrga.snack.database.callable.delete.DeleteMealPlanUsageTask;
import io.github.xjrga.snack.database.callable.delete.DeleteMealTask;
import io.github.xjrga.snack.database.callable.delete.DeleteMixFoodTask;
import io.github.xjrga.snack.database.callable.delete.DeleteMixTask;
import io.github.xjrga.snack.database.callable.delete.DeleteNutrientConstraintTask;
import io.github.xjrga.snack.database.callable.delete.DeleteNutrientRatioConstraintTask;
import io.github.xjrga.snack.database.callable.function.FetchTniScoreTask;
import io.github.xjrga.snack.database.callable.insert.CreateMealTask;
import io.github.xjrga.snack.database.callable.insert.CreateMixTask;
import io.github.xjrga.snack.database.callable.insert.DuplicateCategoryTask;
import io.github.xjrga.snack.database.callable.insert.DuplicateFoodGroupTask;
import io.github.xjrga.snack.database.callable.insert.InsertAndCalculateFoodPortionTask;
import io.github.xjrga.snack.database.callable.insert.InsertCategoryTask;
import io.github.xjrga.snack.database.callable.insert.InsertFoodCategoryLinkTask;
import io.github.xjrga.snack.database.callable.insert.InsertFoodGroupTask;
import io.github.xjrga.snack.database.callable.insert.InsertGroupFoodTask;
import io.github.xjrga.snack.database.callable.insert.InsertMixFoodTask;
import io.github.xjrga.snack.database.callable.insert.MergeFoodConstraintTask;
import io.github.xjrga.snack.database.callable.insert.MergeFoodRatioConstraintTask;
import io.github.xjrga.snack.database.callable.insert.MergeGroupConstraintTask;
import io.github.xjrga.snack.database.callable.insert.MergeMealPlanUsageTask;
import io.github.xjrga.snack.database.callable.insert.MergeNutrientConstraintTask;
import io.github.xjrga.snack.database.callable.insert.MergeNutrientRatioConstraintTask;
import io.github.xjrga.snack.database.callable.other.DenormalizeFoodFactsTask;
import io.github.xjrga.snack.database.callable.other.DuplicateMixTask;
import io.github.xjrga.snack.database.callable.other.ExportMixTask;
import io.github.xjrga.snack.database.callable.other.PinAndDeleteTask;
import io.github.xjrga.snack.database.callable.other.PinAndKeepTask;
import io.github.xjrga.snack.database.callable.select.DerivedFoodFactsTask;
import io.github.xjrga.snack.database.callable.select.DriDiffTask;
import io.github.xjrga.snack.database.callable.select.DriNutrientsTask;
import io.github.xjrga.snack.database.callable.select.FetchMixesToListTask;
import io.github.xjrga.snack.database.callable.select.FetchMixesToRecordTask;
import io.github.xjrga.snack.database.callable.select.FoodCategoriesTask02UsingRecords;
import io.github.xjrga.snack.database.callable.select.FoodCategoriesTaskUsingRecords;
import io.github.xjrga.snack.database.callable.select.FoodCategoryCountTask;
import io.github.xjrga.snack.database.callable.select.FoodConstraintsTask;
import io.github.xjrga.snack.database.callable.select.FoodDiffTask;
import io.github.xjrga.snack.database.callable.select.FoodFactsTask;
import io.github.xjrga.snack.database.callable.select.FoodGroupsTask;
import io.github.xjrga.snack.database.callable.select.FoodGroupsTaskGroupDO;
import io.github.xjrga.snack.database.callable.select.FoodRatioConstraintsTask;
import io.github.xjrga.snack.database.callable.select.FoodsAndCategoriesTask;
import io.github.xjrga.snack.database.callable.select.FoodsInCategoryTask;
import io.github.xjrga.snack.database.callable.select.FoodsInFoodGroupTask;
import io.github.xjrga.snack.database.callable.select.GetFoodListForCategoryTask;
import io.github.xjrga.snack.database.callable.select.GetFoodListTask;
import io.github.xjrga.snack.database.callable.select.GetFoodXmlFixedCategoryTask;
import io.github.xjrga.snack.database.callable.select.GetFoodXmlTask;
import io.github.xjrga.snack.database.callable.select.GroupConstraintsTask;
import io.github.xjrga.snack.database.callable.select.LifestageDriTask;
import io.github.xjrga.snack.database.callable.select.LifestagesTask;
import io.github.xjrga.snack.database.callable.select.MealPlanMealsTask;
import io.github.xjrga.snack.database.callable.select.MealPlanPortionsTask;
import io.github.xjrga.snack.database.callable.select.MealPlanResultsMacronutrientsTask;
import io.github.xjrga.snack.database.callable.select.MealPlanResultsTask;
import io.github.xjrga.snack.database.callable.select.MealPlanUsageResultsTask;
import io.github.xjrga.snack.database.callable.select.MealPlanUsageTask;
import io.github.xjrga.snack.database.callable.select.MixDiffTask;
import io.github.xjrga.snack.database.callable.select.MixFoodFactsTask;
import io.github.xjrga.snack.database.callable.select.MixResultsTask;
import io.github.xjrga.snack.database.callable.select.MixStatsTask;
import io.github.xjrga.snack.database.callable.select.MixesTask;
import io.github.xjrga.snack.database.callable.select.NamedMixFoodSortedByIdTask;
import io.github.xjrga.snack.database.callable.select.NamedMixFoodSortedByNameTask;
import io.github.xjrga.snack.database.callable.select.NewItemFoodFactsTask;
import io.github.xjrga.snack.database.callable.select.NutrientConstraintsTask;
import io.github.xjrga.snack.database.callable.select.NutrientContainingFoodsTask;
import io.github.xjrga.snack.database.callable.select.NutrientRatioConstraintsTask;
import io.github.xjrga.snack.database.callable.select.UnallocatedFoodPercentageTask;
import io.github.xjrga.snack.database.callable.select.lhs.DRIAverageDeficiencyLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.DRIAverageExcessLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.DRIExcessAndDeficiencyLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.FoodLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.FoodRatioLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.GroupLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.NutrientLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.NutrientRatioLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.ObjectiveDeficiencyLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.ObjectiveExcessAndDeficiencyLhsTask;
import io.github.xjrga.snack.database.callable.select.lhs.ULAverageExcessLhsTask;
import io.github.xjrga.snack.database.callable.select.rhs.DRIExcessAndDeficiencyRhsTask;
import io.github.xjrga.snack.database.callable.select.rhs.FoodRatioRhsTask;
import io.github.xjrga.snack.database.callable.select.rhs.FoodRhsTask;
import io.github.xjrga.snack.database.callable.select.rhs.GroupRhsTask;
import io.github.xjrga.snack.database.callable.select.rhs.NutrientRatioRhsTask;
import io.github.xjrga.snack.database.callable.select.rhs.NutrientRhsTask;
import io.github.xjrga.snack.database.callable.update.UpdateCategoryTask;
import io.github.xjrga.snack.database.callable.update.UpdateFoodGroupTask;
import io.github.xjrga.snack.database.callable.update.UpdateFoodPortionActualWeightTask;
import io.github.xjrga.snack.database.callable.update.UpdateFoodTask;
import io.github.xjrga.snack.database.callable.update.UpdateMealTask;
import io.github.xjrga.snack.database.callable.update.UpdateNameOnMixTask;
import io.github.xjrga.snack.database.query.MixFoodsQuery;
import io.github.xjrga.snack.database.query.UpdateMixAction;
import io.github.xjrga.snack.database.query.UpdateMixFoodAction;
import io.github.xjrga.snack.database.runnable.CreateAllFoodsReportDnTask;
import io.github.xjrga.snack.database.runnable.CreateAllFoodsReportTask;
import io.github.xjrga.snack.database.runnable.UpdateMixTask;
import io.github.xjrga.snack.datamodel.FoodStats;
import io.github.xjrga.snack.datamodel.MixFoodLoader;
import io.github.xjrga.snack.datamodel.NutrientLoader;
import io.github.xjrga.snack.datamodel.RelationshipLoader;
import io.github.xjrga.snack.datamodel.TreeModelFood;
import io.github.xjrga.snack.dataobject.DriDO;
import io.github.xjrga.snack.dataobject.Food;
import io.github.xjrga.snack.dataobject.GroupDO;
import io.github.xjrga.snack.dataobject.LhsContainer;
import io.github.xjrga.snack.dataobject.LifeStageDO;
import io.github.xjrga.snack.dataobject.MixDO;
import io.github.xjrga.snack.dataobject.MixFoodDO;
import io.github.xjrga.snack.dataobject.NutrientDO;
import io.github.xjrga.snack.dataobject.RelationshipDO;
import io.github.xjrga.snack.jcomponents.ComboBox;
import io.github.xjrga.snack.jcomponents.FoodFactInputPanel;
import io.github.xjrga.snack.jcomponents.LifestageFinder;
import io.github.xjrga.snack.jcomponents.Spinner;
import io.github.xjrga.snack.jcomponents.TableCategory;
import io.github.xjrga.snack.jcomponents.TableDri;
import io.github.xjrga.snack.jcomponents.TableFood;
import io.github.xjrga.snack.jcomponents.TableFoodDiff;
import io.github.xjrga.snack.jcomponents.TableFoodFactInput;
import io.github.xjrga.snack.jcomponents.TableFoodFacts;
import io.github.xjrga.snack.jcomponents.TableFoodQuantityConstraint;
import io.github.xjrga.snack.jcomponents.TableFoodRatioConstraint;
import io.github.xjrga.snack.jcomponents.TableGroupQuantityConstraint;
import io.github.xjrga.snack.jcomponents.TableGroups;
import io.github.xjrga.snack.jcomponents.TableInventoryDays;
import io.github.xjrga.snack.jcomponents.TableLog;
import io.github.xjrga.snack.jcomponents.TableMealCalories;
import io.github.xjrga.snack.jcomponents.TableMealGrams;
import io.github.xjrga.snack.jcomponents.TableMealPlanUsageResults;
import io.github.xjrga.snack.jcomponents.TableMix;
import io.github.xjrga.snack.jcomponents.TableMixDiff;
import io.github.xjrga.snack.jcomponents.TableMixResults;
import io.github.xjrga.snack.jcomponents.TableNutrientLookup;
import io.github.xjrga.snack.jcomponents.TableNutrientQuantity;
import io.github.xjrga.snack.jcomponents.TableNutrientRatioConstraint;
import io.github.xjrga.snack.jcomponents.TablePortion;
import io.github.xjrga.snack.jcomponents.TablePortionMeals;
import io.github.xjrga.snack.jcomponents.TablePortionMeals.Row;
import io.github.xjrga.snack.jpanels.NutrientCategorySelector;
import io.github.xjrga.snack.jpanels.NutrientCategorySelector.Nutrients;
import io.github.xjrga.snack.launcher.FeedBackLauncher;
import io.github.xjrga.snack.launcher.TaskLauncher;
import io.github.xjrga.snack.logger.LoggerImpl;
import io.github.xjrga.snack.lp.LP;
import io.github.xjrga.snack.lp.LpToC;
import io.github.xjrga.snack.lp.LpToCplex;
import io.github.xjrga.snack.lp.LpToCplexExp;
import io.github.xjrga.snack.lp.LpToCplexMeals;
import io.github.xjrga.snack.lp.LpToJava;
import io.github.xjrga.snack.lp.LpToR;
import io.github.xjrga.snack.lp.LpToRust;
import io.github.xjrga.snack.other.AlphaLinolenicRequired;
import io.github.xjrga.snack.other.CunninghamFormula;
import io.github.xjrga.snack.other.DigestibleCarbohydrate;
import io.github.xjrga.snack.other.Dimensions;
import io.github.xjrga.snack.other.FileName;
import io.github.xjrga.snack.other.GlycemicIndexRange;
import io.github.xjrga.snack.other.GlycemicLoad;
import io.github.xjrga.snack.other.ImageUtilities;
import io.github.xjrga.snack.other.KatchMcArdleFormula;
import io.github.xjrga.snack.other.MinimumNutrientRequirements;
import io.github.xjrga.snack.other.Namer;
import io.github.xjrga.snack.other.NumberCheck;
import io.github.xjrga.snack.other.Objective;
import io.github.xjrga.snack.other.ObjectiveFormatter;
import io.github.xjrga.snack.other.RegexCheck;
import io.github.xjrga.snack.other.Shutdown;
import io.github.xjrga.snack.other.StringCheck;
import io.github.xjrga.snack.other.U;
import io.github.xjrga.snack.records.FoodListRecord;
import io.github.xjrga.snack.records.Records.Mix;
import io.github.xjrga.snack.records.TableCategoryRow;
import io.github.xjrga.snack.renderers.ComboMixRenderer;
import io.github.xjrga.snack.xml.FoodsImporter;
import io.github.xjrga.snack.xml.MixImporter;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.net.URI;
import java.net.URL;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Future;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JFormattedTextField.AbstractFormatterFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpinnerListModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.tree.DefaultMutableTreeNode;
import org.apache.commons.lang3.StringUtils;

public class Main {

    private BufferedImage logo;
    private CellConstraints cc;
    private ComboBox<GroupDO> cmbFoodGroup;
    private ComboBox<LifeStageDO> cmbLifestage;
    private ComboBox<MixDO> cmbMixes;
    private ComboBox<MixFoodDO> cmbFoodQuantityFood;
    private ComboBox<MixFoodDO> cmbFoodRatioFoodA;
    private ComboBox<MixFoodDO> cmbFoodRatioFoodB;
    private ComboBox<MixFoodDO> cmbPortionFood;
    private ComboBox<NutrientDO> cmbFoodQuantityNutrient;
    private ComboBox<NutrientDO> cmbFoodRatioNutrientA;
    private ComboBox<NutrientDO> cmbFoodRatioNutrientB;
    private ComboBox<NutrientDO> cmbGroupNutrient;
    private ComboBox<NutrientDO> cmbNutrientContentNutrient;
    private ComboBox<NutrientDO> cmbNutrientQuantityNutrient;
    private ComboBox<NutrientDO> cmbNutrientRatioNutrientA;
    private ComboBox<NutrientDO> cmbNutrientRatioNutrientB;
    private ComboBox<RelationshipDO> cmbFoodQuantityRelationship;
    private ComboBox<RelationshipDO> cmbFoodRatioRelationship;
    private ComboBox<RelationshipDO> cmbGroupRelationship;
    private ComboBox<RelationshipDO> cmbNutrientQuantityRelationship;
    private ComboBox<RelationshipDO> cmbNutrientRatioRelationship;
    private Connection connection;
    private DefaultListModel lstmdl_Tni;
    private DefaultListModel lstmdl_Cost;
    private FoodStats foodStats;
    private JButton btnAddFood;
    private JButton btnAddFoodQuantityConstraint;
    private JButton btnAddFoodRatioConstraint;
    private JButton btnAddGroupQuantityConstraint;
    private JButton btnAddMeal;
    private JButton btnAddNutrientConstraint;
    private JButton btnAddNutrientRatio;
    private JButton btnAddPortion;
    private JButton btnBlock;
    private JButton btnDeleteFood;
    private JButton btnDeleteFoodQuantityConstraint;
    private JButton btnDeleteFoodRatioConstraint;
    private JButton btnDeleteGroupQuantityConstraint;
    private JButton btnDeleteMeal;
    private JButton btnDeleteNutrientConstraint;
    private JButton btnDeleteNutrientRatio;
    private JButton btnDeletePortion;
    private JButton btnDeriveFood;
    private JButton btnGroupBlock;
    private JButton btnRenameFood;
    private JButton btnSolve;
    private JButton btnUpdateMeal;
    private JButton btnUpdatePortionWeight;
    private JCheckBox cbToC;
    private JCheckBox cbToCplex;
    private JCheckBox cbToCplexExp;
    private JCheckBox cbToCplexMeals;
    private JCheckBox cbToJava;
    private JCheckBox cbToR;
    private JCheckBox cbToRust;
    private JCheckBox chkResultRoundUp;
    private JFileChooser fch_Mix;
    private JFileChooser fch_Foods;
    private JFrame frm;
    private JLabel lblFoodCount;
    private JLabel lblFoodRatioCount;
    private JLabel lblGroupCount;
    private JLabel lblNutrientCount;
    private JLabel lblNutrientRatioCount;
    private JList lst_Cost;
    private JList lst_Tni;
    private JMenu mnuDELETE;
    private JMenu mnuData;
    private JMenu mnuFoodsData;
    private JMenu mnuHelp;
    private JMenu mnuMix;
    private JMenu mnuMixModel;
    private JMenu mnuMixResult;
    private JMenu mnuProgram;
    private JMenu mnuReport;
    private JMenu mnuSettings;
    private JMenu mnuTools;
    private JMenuItem mniAbout;
    private JMenuItem mniCalculateALARequired;
    private JMenuItem mniCalculateBMR;
    private JMenuItem mniCalculateDigestibleCarbs;
    private JMenuItem mniCalculateGIRange;
    private JMenuItem mniCalculateGL;
    private JMenuItem mniCalculateProteinRequired;
    private JMenuItem mniConvertDRI;
    private JMenuItem mniConvertMix;
    private JMenuItem mniCreateAllFoodsReport;
    private JMenuItem mniCreateAllFoodsReportDn;
    private JMenuItem mniCreateFoodComparisonReport;
    private JMenuItem mniCreateMD5MixResultsReport;
    private JMenuItem mniCreateMealPlanCaloriesReport;
    private JMenuItem mniCreateMealPlanMacronutrientsReport;
    private JMenuItem mniCreateMealPlanPortionsReport;
    private JMenuItem mniCreateMealPlanUsageReport;
    private JMenuItem mniCreateMix;
    private JMenuItem mniCreateMixComparisonReport;
    private JMenuItem mniCreateMixDriReport;
    private JMenuItem mniCreateMixResultsReport;
    private JMenuItem mniCreateMixResultsReportDn;
    private JMenuItem mniCreateMixTotalsReport;
    private JMenuItem mniCreateNutrientSearchReport;
    private JMenuItem mniDELETEALL;
    private JMenuItem mniDELETEMIXES;
    private JMenuItem mniDeleteMix;
    private JMenuItem mniDuplicateMix;
    private JMenuItem mniExit;
    private JMenuItem mniExportFoods;
    private JMenuItem mniExportMix;
    private JMenuItem mniImportFoods;
    private JMenuItem mniImportMix;
    private JMenuItem mniPinMixAndDeleteConstraints;
    private JMenuItem mniPinMixAndKeepConstraints;
    private JMenuItem mniRenameMix;
    private JMenuItem mniSetConstraints;
    private JMenuItem mniShowCarbohydrateRequired;
    private JMenuItem mniShowMixStats;
    private JSplitPane splMain;
    private JTabbedPane tabMain;
    private JTabbedPane tabResults;
    private JTextArea txaLpProgram;
    private JTextArea txtMinimization;
    private JTextField txtFoodNutrientRatioQuantityA;
    private JTextField txtFoodNutrientRatioQuantityB;
    private JTextField txtFoodQuantityValue;
    private JTextField txtGroupQuantityValue;
    private JTextField txtNutrientQuantityValue;
    private JTextField txtNutrientRatioNutrientA;
    private JTextField txtNutrientRatioNutrientB;
    private JTextField txtNutrientSearchQuantity;
    private JTextField txtPortionPct;
    private JTextField txtTotalPct;
    private JTree tree;
    private MixFoodLoader mixFoodLoader;
    private NutrientCategorySelector selectorMixResultsTable;
    private NutrientLoader nutrientLoader;
    private Objective minimizationOption;
    private RelationshipLoader relationshipLoader;
    private Spinner<LifeStageDO> spnLifestage;
    private Spinner<Objective> spnMinimizationOption;
    private TableCategory tblAllFoodCategories;
    private TableDri tblDri;
    private TableFood tblAllFoods;
    private TableFood tblFoodDiffA;
    private TableFood tblFoodDiffB;
    private TableFood tblFoodsInCategory;
    private TableFood tblFoodsInFoodGroup;
    private TableFood tblMixFood;
    private TableFood tblSelectedFoods;
    private TableFoodDiff tblFoodDiff;
    private TableFoodFacts tblFoodFacts;
    private TableFoodQuantityConstraint tblFoodQuantityConstraint;
    private TableFoodRatioConstraint tblFoodRatioConstraint;
    private TableGroupQuantityConstraint tblGroupQuantityConstraint;
    private TableGroups tblFoodGroups;
    private TableInventoryDays tblMealPlanUsage;
    private TableLog tblLog;
    private TableMealCalories tblMealCalories;
    private TableMealGrams tblMealMacronutrients;
    private TableMealPlanUsageResults tblMealPlanUsageResults;
    private TableMix tblMealPlanUsageMixes;
    private TableMix tblMixDiffA;
    private TableMix tblMixDiffB;
    private TableMixDiff tblMixDiff;
    private TableMixResults tblMixResults;
    private TableNutrientLookup tblNutrientLookup;
    private TableNutrientQuantity tblNutrientQuantityConstraint;
    private TableNutrientRatioConstraint tblNutrientRatio;
    private TablePortion tblMealPortions;
    private TablePortionMeals tblMeals;
    private TreeModelFood treeModel;
    public MixDO selectedMix;

    public MixDO getSelectedMix() {
        return selectedMix;
    }

    public void setSelectedMix(MixDO mix) {
        selectedMix = mix;
    }

    public Main(Splash splash) {
        LoggerImpl.INSTANCE.filter("io.github.xjrga.*");
        logo = ImageUtilities.readImageFromUrl(U.getResourceAsUrl("/resources/images/logo.png"));
        cc = new CellConstraints();
        cmbFoodQuantityFood = new ComboBox();
        cmbFoodGroup = new ComboBox();
        cmbFoodRatioFoodA = new ComboBox();
        cmbFoodRatioFoodB = new ComboBox();
        cmbPortionFood = new ComboBox<>();
        cmbFoodQuantityNutrient = new ComboBox();
        cmbGroupNutrient = new ComboBox();
        cmbFoodRatioNutrientA = new ComboBox();
        cmbFoodRatioNutrientB = new ComboBox();
        cmbNutrientContentNutrient = new ComboBox();
        cmbNutrientQuantityNutrient = new ComboBox();
        cmbNutrientRatioNutrientA = new ComboBox();
        cmbNutrientRatioNutrientB = new ComboBox();
        cmbFoodQuantityRelationship = new ComboBox();
        cmbGroupRelationship = new ComboBox();
        cmbFoodRatioRelationship = new ComboBox();
        cmbNutrientQuantityRelationship = new ComboBox();
        cmbNutrientRatioRelationship = new ComboBox();
        lstmdl_Tni = new DefaultListModel();
        lstmdl_Cost = new DefaultListModel();
        foodStats = new FoodStats();
        btnAddFood = new JButton("+");
        btnAddFoodQuantityConstraint = new JButton("+");
        btnAddGroupQuantityConstraint = new JButton("+");
        btnAddFoodRatioConstraint = new JButton("+");
        btnAddMeal = new JButton("+");
        btnAddNutrientConstraint = new JButton("+");
        btnAddNutrientRatio = new JButton("+");
        btnAddPortion = new JButton("+");
        btnDeleteFood = new JButton("-");
        btnDeleteFoodQuantityConstraint = new JButton("-");
        btnDeleteGroupQuantityConstraint = new JButton("-");
        btnDeleteFoodRatioConstraint = new JButton("-");
        btnDeleteMeal = new JButton("-");
        btnDeleteNutrientConstraint = new JButton("-");
        btnDeleteNutrientRatio = new JButton("-");
        btnDeletePortion = new JButton("-");
        btnRenameFood = new JButton("r");
        btnSolve = new JButton("Solve");
        btnDeriveFood = new JButton("d");
        btnUpdateMeal = new JButton("u");
        btnUpdatePortionWeight = new JButton("w");
        btnBlock = new JButton("Block");
        btnGroupBlock = new JButton("Block");
        cbToCplexMeals = new JCheckBox();
        cbToCplexExp = new JCheckBox();
        cbToCplex = new JCheckBox();
        cbToR = new JCheckBox();
        cbToJava = new JCheckBox();
        cbToRust = new JCheckBox();
        cbToC = new JCheckBox();
        chkResultRoundUp = new JCheckBox();
        fch_Mix = new JFileChooser();
        fch_Foods = new JFileChooser();
        frm = new JFrame();
        lblFoodCount = new JLabel();
        lblGroupCount = new JLabel();
        lblFoodRatioCount = new JLabel();
        // lblGroupRatioCount = new JLabel();
        lblNutrientCount = new JLabel();
        lblNutrientRatioCount = new JLabel();
        lst_Tni = new JList();
        lst_Cost = new JList();
        mnuDELETE = new JMenu();
        mnuData = new JMenu();
        mnuFoodsData = new JMenu();
        mnuHelp = new JMenu();
        mnuMix = new JMenu();
        mnuMixModel = new JMenu();
        mnuMixResult = new JMenu();
        mnuReport = new JMenu();
        mnuProgram = new JMenu();
        mnuSettings = new JMenu();
        mnuTools = new JMenu();
        mniAbout = new JMenuItem();
        mniCalculateALARequired = new JMenuItem();
        mniCalculateBMR = new JMenuItem();
        mniCalculateDigestibleCarbs = new JMenuItem();
        mniCalculateGIRange = new JMenuItem();
        mniCalculateGL = new JMenuItem();
        mniCalculateProteinRequired = new JMenuItem();
        mniConvertDRI = new JMenuItem();
        mniConvertMix = new JMenuItem();
        mniCreateAllFoodsReport = new JMenuItem();
        mniCreateAllFoodsReportDn = new JMenuItem();
        mniCreateMixDriReport = new JMenuItem();
        mniCreateFoodComparisonReport = new JMenuItem();
        mniCreateMealPlanUsageReport = new JMenuItem();
        mniCreateMealPlanCaloriesReport = new JMenuItem();
        mniCreateMealPlanMacronutrientsReport = new JMenuItem();
        mniCreateMealPlanPortionsReport = new JMenuItem();
        mniCreateMix = new JMenuItem();
        mniCreateMixComparisonReport = new JMenuItem();
        mniCreateMixTotalsReport = new JMenuItem();
        mniCreateMixResultsReportDn = new JMenuItem();
        mniCreateMixResultsReport = new JMenuItem();
        mniCreateNutrientSearchReport = new JMenuItem();
        mniCreateMD5MixResultsReport = new JMenuItem();
        mniDELETEALL = new JMenuItem();
        mniDELETEMIXES = new JMenuItem();
        mniDeleteMix = new JMenuItem();
        mniDuplicateMix = new JMenuItem();
        mniExit = new JMenuItem();
        mniExportMix = new JMenuItem();
        mniImportFoods = new JMenuItem();
        mniExportFoods = new JMenuItem();
        mniImportMix = new JMenuItem();
        mniPinMixAndDeleteConstraints = new JMenuItem();
        mniPinMixAndKeepConstraints = new JMenuItem();
        mniRenameMix = new JMenuItem();
        mniSetConstraints = new JMenuItem();
        mniShowCarbohydrateRequired = new JMenuItem();
        mniShowMixStats = new JMenuItem();
        splMain = new JSplitPane();
        tabMain = new JTabbedPane();
        tabResults = new JTabbedPane();
        txaLpProgram = new JTextArea();
        txtFoodNutrientRatioQuantityA = new JTextField();
        txtFoodNutrientRatioQuantityB = new JTextField();
        txtFoodQuantityValue = new JTextField();
        txtGroupQuantityValue = new JTextField();
        txtNutrientSearchQuantity = new JTextField();
        txtNutrientQuantityValue = new JTextField();
        txtNutrientRatioNutrientA = new JTextField();
        txtNutrientRatioNutrientB = new JTextField();
        txtPortionPct = new JTextField();
        txtTotalPct = new JTextField();
        txtMinimization = new JTextArea();
        tree = new JTree();
        mixFoodLoader = new MixFoodLoader();
        nutrientLoader = new NutrientLoader();
        relationshipLoader = new RelationshipLoader();
        tblMealPlanUsageMixes = new TableMix();
        treeModel = new TreeModelFood();
        minimizationOption = Objective.DRIUL;
        txtMinimization.setText("DRI Deficiency");
        txtMinimization.setLineWrap(true);
        txtMinimization.setEditable(false);
        frm.setIconImage(logo);
        frm.setJMenuBar(getMenuBar());
        tabMain.setTabPlacement(SwingConstants.BOTTOM);
        tabMain.add(getEditorPanel());
        tabMain.add(getFoodList());
        tabMain.add(getFoodComparisonPanel());
        tabMain.add(getMixComparisonPanel());
        tabMain.add(getNutrientSearchPanel());
        tabMain.add(getFoodCategoriesPanel());
        tabMain.add(getMealPlanUsagePanel());
        tabMain.add(getModelLogPanel());
        int length = 17;
        String txt0 = StringUtils.center("Editor", length);
        String txt1 = StringUtils.center("Food List", length);
        String txt2 = StringUtils.center("Food Comparison", length);
        String txt3 = StringUtils.center("Mix Comparison", length);
        String txt4 = StringUtils.center("Nutrient Search", length);
        String txt5 = StringUtils.center("Food Category", length);
        String txt6 = StringUtils.center("Food Shopping", length);
        String txt7 = StringUtils.center("Mixes Log", length);
        tabMain.setTitleAt(0, txt0);
        tabMain.setToolTipTextAt(0, "Create, edit and solve your diet here");
        tabMain.setTitleAt(1, txt1);
        tabMain.setToolTipTextAt(1, "This is your list of favorite food items");
        tabMain.setTitleAt(2, txt2);
        tabMain.setToolTipTextAt(2, "This is where you compare two 100 Kcal food servings");
        tabMain.setTitleAt(3, txt3);
        tabMain.setToolTipTextAt(3, "This is where you compare two mixes");
        tabMain.setTitleAt(4, txt4);
        tabMain.setToolTipTextAt(4, "This is where you search food items for nutrient content");
        tabMain.setTitleAt(5, txt5);
        tabMain.setToolTipTextAt(5, "This is where you put food items into categories");
        tabMain.setTitleAt(6, txt6);
        tabMain.setToolTipTextAt(6, "This is where you find out how much food you need to buy");
        tabMain.setTitleAt(7, txt7);
        tabMain.setToolTipTextAt(7, "This is keeps track of changes made to mixes in this session");
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(tabMain);
        frm.add(scrollPane);
        frm.setDefaultCloseOperation(3);
        Dimension size = new Dimension(1500, 870);
        frm.setSize(size);
        frm.setVisible(true);
        frm.setTitle(StringUtils.center("Snack", 7));
        frm.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exit();
            }

        });
        cmbMixes.setMaximumRowCount(24);
        connection = Connect.getInstance().getConnection();
        reloadCbNutrientData();
        reloadCbRelationshipData();
        reloadMixesTask();
        reloadFoods();
        try {
            Future<List<LifeStageDO>> task = TaskLauncher.submit(new LifestagesTask());
            List<LifeStageDO> lifestages = task.get();
            cmbLifestage.reload(lifestages);
            spnLifestage.reload(lifestages);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        fch_Mix.setPreferredSize(new Dimension(600, 600));
        fch_Mix.setAcceptAllFileFilterUsed(false);
        fch_Mix.addChoosableFileFilter(new FileNameExtensionFilter("Xml Document", "xml"));
        Action detailsImport = fch_Mix.getActionMap().get("viewTypeDetails");
        detailsImport.actionPerformed(null);
        fch_Foods.setPreferredSize(new Dimension(600, 600));
        fch_Foods.setAcceptAllFileFilterUsed(false);
        fch_Foods.addChoosableFileFilter(new FileNameExtensionFilter("Xml Document", "xml"));
        Action detailsExport = fch_Foods.getActionMap().get("viewTypeDetails");
        detailsExport.actionPerformed(null);
        LifeStageDO lifestage22 = new LifeStageDO(22, "Daily Value");
        cmbLifestage.setSelectedItem(lifestage22);
        spnLifestage.setSelectedItem(lifestage22);
        spnMinimizationOption.setSelectedItem(Objective.DRIUL);
        setSplitPanelDivider();
        setQuantityScale();
        splash.halt();
    }

    public void reloadMixesTask() {
        try {
            Future<List<List>> task = TaskLauncher.submit(new MixesTask());
            List<List> lst = task.get();
            List<MixDO> mixesList = U.createMixDOListFromList(lst);
            cmbMixes.reload(mixesList);
            reloadMixes(lst);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    public void reloadFoods() {

        Future<List<List>> task00 = TaskLauncher.submit(new FoodFactsTask());
        Runnable feedback00 = () -> {
            try {
                List<List> foods = task00.get();
                List<List> filteredFoods = new ArrayList();
                int size = foods.size();
                for (int i = 0; i < size; i++) {
                    List food = foods.get(i);
                    ArrayList<Object> newFood = new ArrayList();
                    newFood.add(food.get(0));
                    newFood.add(food.get(1));
                    filteredFoods.add(newFood);
                }
                reloadFoodFacts(foods, filteredFoods);
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback00);

        Future<List<Map<String, Object>>> task01 = TaskLauncher.submit(new FoodsAndCategoriesTask());
        Runnable feedback01 = () -> {
            try {
                List<Map<String, Object>> treeFoods = task01.get();
                treeModel.reload(treeFoods);
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback01);

        Future<List<TableCategoryRow>> task = TaskLauncher.submit(new FoodCategoriesTaskUsingRecords());
        Runnable feedback02 = () -> {
            try {
                List<TableCategoryRow> categories = task.get();
                tblAllFoodCategories.reload(categories);
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback02);
    }

    public void reloadFoodFacts(List<List> foods, List<List> filteredFoods) {
        tblFoodFacts.reload(foods);
        tblFoodDiffA.reload(filteredFoods);
        tblFoodDiffB.reload(filteredFoods);
        tblAllFoods.reload(filteredFoods);
    }

    public void reloadMixes(List<List> lst) {
        tblMixDiffA.reload(lst);
        tblMixDiffB.reload(lst);
        tblMealPlanUsageMixes.reload(lst);
    }

    public void reloadCmbMixes(List<Mix> lst) {
        List<MixDO> mixesList = U.createMixDOListFromRecord(lst);
        cmbMixes.reload(mixesList);
    }

    private void clearMixesView() {
        // Mixes List
        cmbMixes.clear();
        tblMixDiffA.clear();
        tblMixDiffB.clear();
        tblMealPlanUsageMixes.clear();
        // Model Data
        tblMixFood.clear();
        tblSelectedFoods.clear();
        tblNutrientQuantityConstraint.clear();
        tblNutrientRatio.clear();
        cmbFoodQuantityFood.clear();
        tblFoodQuantityConstraint.clear();
        cmbFoodRatioFoodA.clear();
        cmbFoodRatioFoodB.clear();
        tblFoodRatioConstraint.clear();
        cmbFoodGroup.clear();
        tblGroupQuantityConstraint.clear();
        // Model Results Data
        tblMixResults.clear();
        tblDri.clear();
        txaLpProgram.setText("");
        // Model Meal Plan
        tblMeals.clear();
        cmbPortionFood.clear();
        tblMealPortions.clear();
        tblMealCalories.clear();
        tblMealMacronutrients.clear();
        // Mixes Comparison
        tblMixDiff.clear();
        // Meal Plan Usage
        tblMealPlanUsage.clear();
        tblMealPlanUsageResults.clear();
    }

    private void clearFoodsView() {
        treeModel.clear();
        tblMixFood.clear();
        tblSelectedFoods.clear();
        tblFoodFacts.clear();
        tblFoodDiffA.clear();
        tblFoodDiffB.clear();
        tblAllFoods.clear();
        tblFoodsInCategory.clear();
        tblAllFoodCategories.clear();
        cmbFoodQuantityFood.clear();
        cmbFoodRatioFoodA.clear();
        cmbFoodRatioFoodB.clear();
        tblFoodDiff.clear();
    }

    public void selectMix(MixDO mix) {
        cmbMixes.setSelectedItem(mix);
    }

    private void deleteFoodItem(String foodId) {
        try {
            Future<Boolean> task = TaskLauncher.submit(new DeleteFoodTask(foodId));
            Boolean completed = task.get();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        reloadFoods();
        try {
            Future<List<List>> task = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(getSelectedMix().getMixid()));
            List<List> foods = task.get();
            tblMixFood.reload(foods);
            tblSelectedFoods.reload(foods);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        setQuantityScale();
    }

    private void addMealPlanUsage() {
        if (tblMealPlanUsageMixes.isSelectionEmpty()) {
            return;
        }
        TableMix.Row row = tblMealPlanUsageMixes.getSelectedValue();
        Double days = getMixUsageInputForInventory();
        if (days == Double.NaN) {
            return;
        }
        try {
            Future<Boolean> task = TaskLauncher.submit(new MergeMealPlanUsageTask(row.getMixid(), days));
            task.get();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void deleteMealPlanUsage() {
        if (tblMealPlanUsage.isSelectionEmpty()) {
            return;
        }
        try {
            TableInventoryDays.Row row = tblMealPlanUsage.getSelectedValue();
            Future<Boolean> task = TaskLauncher.submit(new DeleteMealPlanUsageTask(row.getMixid()));
            task.get();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void expandTree(JTree tree, int startingIndex, int rowCount) {
        for (int i = startingIndex; i < rowCount; ++i) {
            tree.expandRow(i);
        }
        if (tree.getRowCount() != rowCount) {
            expandTree(tree, rowCount, tree.getRowCount());
        }
    }

    private JTabbedPane getConstraintsPanel() {
        JTabbedPane tab = new JTabbedPane();
        tblFoodQuantityConstraint = new TableFoodQuantityConstraint();
        int size = 19;
        String txt0 = StringUtils.rightPad("Food List", size);
        String txt1 = StringUtils.rightPad("Nutrient", size);
        String txt2 = StringUtils.rightPad("Nutrient Ratio", size);
        String txt3 = StringUtils.rightPad("Food", size);
        String txt4 = StringUtils.rightPad("Food Ratio", size);
        String txt5 = StringUtils.rightPad("Group", size);
        // String txt6 = StringUtils.rightPad("Group Ratio", size);
        tab.setBorder(new TitledBorder("Constraints"));
        tab.setTabPlacement(SwingConstants.RIGHT);
        tab.add(txt0, getMixFoodPanel());
        tab.add(txt1, getNutrientConstraintsPanel());
        tab.add(txt2, getNutrientRatioConstraintsPanel());
        tab.add(txt3, getFoodConstraintsPanel());
        tab.add(txt4, getFoodRatioConstraintsPanel());
        tab.add(txt5, getGroupConstraintsPanel());
        // tab.add(txt6, new PanelSpacer(new JPanel()));
        tab.setToolTipTextAt(0, "Add food items to this list");
        tab.setToolTipTextAt(1, "Limit a nutrient");
        tab.setToolTipTextAt(2, "Create relationship between two nutrients");
        tab.setToolTipTextAt(3, "Limit a food item");
        tab.setToolTipTextAt(4, "Create relationship between two food items");
        tab.setToolTipTextAt(5, "Limit a group");
        // tab.setToolTipTextAt(6, "Create relationship between two groups");
        return tab;
    }

    private JPanel getEditorPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "min:GROW", // columns
                "min,FILL:min:GROW" // rows
        );
        pnl.setLayout(lyo);
        pnl.add(getEditorTopPanel(), cc.xy(1, 1));
        pnl.add(getEditorBottomPanel(), cc.xy(1, 2));
        cmbMixes.addActionListener((ActionEvent evt) -> {
            if (!cmbMixes.isSelectionEmpty()) {
                clearResultTables();
                loadSelectedMix();
                LifeStageDO find
                        = LifestageFinder.find(((SpinnerListModel) spnLifestage.getModel()).getList(), getSelectedMix().getLifestageid());
                spnLifestage.setSelectedItem(find);
            }
        });
        return pnl;
    }

    private JPanel getMealPlanPanel() {
        JPanel pnl = new JPanel();
        JTabbedPane tab = new JTabbedPane();
        FormLayout lyo = new FormLayout(
                "min:GROW", // columns
                "FILL:min:GROW" // rows
        );
        pnl.setLayout(lyo);
        tab.setTabPlacement(SwingConstants.RIGHT);
        tab.add("Portions      ", getMealPortionsPanel());
        tab.add("Calories      ", getMealCaloriesPanel());
        tab.add("Macronutrients", getMealMacronutrientsPanel());
        tab.setSelectedIndex(0);
        tab.setToolTipTextAt(
                0,
                "Allocate food amount by specifying a percentage, selecting a food item, one or more meals"
                + " and pressing '+'");
        tab.setToolTipTextAt(1, "Calories per meal");
        tab.setToolTipTextAt(2, "Grams per meal");
        pnl.add(tab, cc.xy(1, 1));
        return pnl;
    }

    private JPanel getEditorTopPanel() {
        cmbMixes = new ComboBox<>();
        cmbMixes.setRenderer(new ComboMixRenderer());
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "p:GROW,4px,156px", // columns
                "FILL:30px:GROW" // rows
        );
        pnl.setLayout(lyo);
        pnl.setBorder(new TitledBorder("Mix"));
        btnSolve.setToolTipText("Find lowest calorie diet");
        pnl.add(cmbMixes, cc.xy(1, 1));
        pnl.add(btnSolve, cc.xy(3, 1));
        btnSolve.addActionListener((ActionEvent evt) -> {
            if (cmbMixes.isSelectionEmpty()) {
                return;
            }
            if (tblMixFood.isEmpty()) {
                return;
            }
            solveMixAndUpdateResults();
            //TODO - DELETE
            LifeStageDO selectedLifestage = spnLifestage.getSelectedItem();
            Integer selectedLifestageId = selectedLifestage.getLifeStageId();
        });
        return pnl;
    }

    private JPanel getEditorModel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "min:GROW", // columns
                "FILL:pref:GROW" // rows
        );
        pnl.setLayout(lyo);
        try {
            URL url = U.getResourceAsUrl("/resources/fonts/inconsolata.ttf");
            InputStream is = url.openStream();
            Font font = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(13f);
            txaLpProgram.setFont(font);
            txaLpProgram.setLineWrap(false);
            JScrollPane scrollPane = new JScrollPane(txaLpProgram);
            scrollPane.setPreferredSize(new Dimension(0, 0));
            pnl.add(scrollPane, cc.xy(1, 1));
        } catch (IOException | FontFormatException e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        return pnl;
    }

    private JPanel getEditorDri(TableDri tblDri) {
        JScrollPane scr = new JScrollPane(tblDri);
        FormLayout lyo = new FormLayout(
                "p:GROW", // columns
                "5dlu,min,5dlu,FILL:min:GROW" // rows
        );
        FormLayout lyoLifestage = new FormLayout(
                "5dlu,min:GROW,5dlu,min", // columns
                "min" // rows
        );
        JPanel pnlLifestage = new JPanel();
        pnlLifestage.setLayout(lyoLifestage);
        JLabel lbl = new JLabel(" Lifestage:");
        cmbLifestage = new ComboBox<>();
        lbl.setHorizontalAlignment(SwingConstants.RIGHT);
        pnlLifestage.add(lbl, cc.xy(2, 1));
        pnlLifestage.add(cmbLifestage, cc.xy(4, 1));
        JPanel pnl = new JPanel();
        pnl.setLayout(lyo);
        pnl.add(pnlLifestage, cc.xy(1, 2));
        pnl.add(scr, cc.xy(1, 4));
        scr.setBorder(new TitledBorder("DRI Check"));
        cmbLifestage.addActionListener((ActionEvent evt) -> {
            if (!cmbLifestage.isSelectionEmpty()) {
                if (getSelectedMix() != null) {
                    LifeStageDO lifestage = (LifeStageDO) cmbLifestage.getSelectedItem();
                    try {
                        Future<List<List>> task
                                = TaskLauncher.submit(new DriDiffTask(getSelectedMix().getMixid(), lifestage.getLifeStageId()));
                        List<List> diff = task.get();
                        tblDri.reload(diff);
                        setQuantityScale();
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            }
        });
        JPopupMenu pmn = new JPopupMenu();
        JMenuItem item01 = new JMenuItem("Do nutrient search");
        JMenuItem item02 = new JMenuItem("Show nutrient contribution by food");
        pmn.add(item01);
        pmn.add(item02);
        item01.addActionListener((ActionEvent evt) -> {
            if (!tblDri.isSelectionEmpty()) {
                calculateNutrientContent();
            } else {
                Message.showMessage("Please select nutrient");
            }
        });
        item02.addActionListener((ActionEvent evt) -> {
            String nutrient = tblDri.getSelectedValue().getNutrient();
            boolean carbohydrates = nutrient.startsWith("Carbohydrates");
            boolean pufa = nutrient.startsWith("Fats, Linole");
            boolean fats = nutrient.startsWith("Fats, Total");
            boolean minerals = nutrient.startsWith("Minerals");
            boolean potassium = nutrient.startsWith("Minerals, Potassium");
            boolean sodium = nutrient.startsWith("Minerals, Sodium");
            boolean other = nutrient.startsWith("Other");
            boolean protein = nutrient.startsWith("Protein");
            boolean vitamins = nutrient.startsWith("Vitamins");
            tabResults.setSelectedIndex(0);
            if (carbohydrates) {
                selectorMixResultsTable.setSelected(Nutrients.Carbohydrates);
            }
            if (pufa) {
                selectorMixResultsTable.setSelected(Nutrients.Polyunsaturated);
            }
            if (fats) {
                selectorMixResultsTable.setSelected(Nutrients.Fats);
            }
            if (minerals) {
                if (potassium || sodium) {
                    selectorMixResultsTable.setSelected(Nutrients.Electrolytes);
                } else {
                    selectorMixResultsTable.setSelected(Nutrients.Minerals);
                }
            }
            if (other) {
                selectorMixResultsTable.setSelected(Nutrients.Other);
            }
            if (protein) {
                selectorMixResultsTable.setSelected(Nutrients.Protein);
            }
            if (vitamins) {
                selectorMixResultsTable.setSelected(Nutrients.Vitamins);
            }
        });
        tblDri.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                showPopup(e, pmn);
            }

        });
        return pnl;
    }

    private JSplitPane getModelPanel() {
        JPanel pnlMain = new JPanel();
        JPanel pnlRight = new JPanel();
        JPanel pnlObjective = new JPanel();
        JPanel pnlConstraintCount = new JPanel();
        FormLayout lyoMainPanel = new FormLayout(
                "p:GROW,right:p", // columns
                "FILL:min:GROW" // rows
        );
        FormLayout lyoRightPanel = new FormLayout(
                "160px", // columns
                "min,FILL:min:GROW" // rows
        );
        FormLayout lyoConstraintCountPanel = new FormLayout(
                "p,p", // columns
                "4dlu,min,min,min,min,min,min,4dlu" // rows
        );
        FormLayout lyoObjective = new FormLayout(
                "160px", // columns
                "min,FILL:32px,min,FILL:32px,min,FILL:min:GROW,min,FILL:min:GROW" // rows
        );
        pnlMain.setLayout(lyoMainPanel);
        pnlRight.setLayout(lyoRightPanel);
        pnlConstraintCount.setLayout(lyoConstraintCountPanel);
        pnlObjective.setLayout(lyoObjective);
        JScrollPane scrTni = new JScrollPane(lst_Tni);
        JScrollPane scrCost = new JScrollPane(lst_Cost);
        scrTni.setBorder(new TitledBorder(""));
        scrCost.setBorder(new TitledBorder(""));
        scrTni.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrCost.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        pnlObjective.setBorder(new TitledBorder(""));
        scrTni.setToolTipText("Press delete button to clear list");
        scrCost.setToolTipText("Press delete button to clear list");
        pnlConstraintCount.setBorder(new TitledBorder("Constraints"));
        lst_Tni.setModel(lstmdl_Tni);
        lst_Cost.setModel(lstmdl_Cost);
        DefaultListCellRenderer renderer = (DefaultListCellRenderer) lst_Tni.getCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.RIGHT);
        DefaultListCellRenderer rendererObjective = (DefaultListCellRenderer) lst_Cost.getCellRenderer();
        rendererObjective.setHorizontalAlignment(SwingConstants.RIGHT);
        tabResults.setBorder(new TitledBorder("Results"));
        tabResults.setTabPlacement(SwingConstants.BOTTOM);
        JLabel lblNutrient = new JLabel("Nutrient: ");
        JLabel lblNutrientRatio = new JLabel("Nutrient Ratio: ");
        JLabel lblFood = new JLabel("Food: ");
        JLabel lblFoodRatio = new JLabel("Food Ratio: ");
        JLabel lblGroup = new JLabel("Group: ");
        // JLabel lblGroupRatio = new JLabel("Group Ratio: ");
        tblMixResults = new TableMixResults();
        tblDri = new TableDri();
        spnLifestage = new Spinner<>();
        spnMinimizationOption = new Spinner<>();
        JFormattedTextField txtLifestage = ((DefaultEditor) spnLifestage.getEditor()).getTextField();
        JFormattedTextField txtMinimizationOption = ((DefaultEditor) spnMinimizationOption.getEditor()).getTextField();
        txtLifestage.setEditable(false);
        txtLifestage.setCaretColor(new Color(95, 99, 102));
        txtMinimizationOption.setEditable(false);
        txtMinimizationOption.setCaretColor(new Color(95, 99, 102));
        ArrayList list = new ArrayList();
        list.add(Objective.DRI);
        list.add(Objective.DRIUL);
        list.add(Objective.DRIDRI);
        spnMinimizationOption.reload(list);
        lblNutrient.setHorizontalAlignment(SwingConstants.RIGHT);
        lblFood.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNutrientRatio.setHorizontalAlignment(SwingConstants.RIGHT);
        lblFoodRatio.setHorizontalAlignment(SwingConstants.RIGHT);
        lblGroup.setHorizontalAlignment(SwingConstants.RIGHT);
        // lblGroupRatio.setHorizontalAlignment(SwingConstants.RIGHT);
        pnlConstraintCount.add(lblNutrient, cc.xy(1, 2));
        pnlConstraintCount.add(lblNutrientRatio, cc.xy(1, 3));
        pnlConstraintCount.add(lblFood, cc.xy(1, 4));
        pnlConstraintCount.add(lblFoodRatio, cc.xy(1, 5));
        pnlConstraintCount.add(lblGroup, cc.xy(1, 6));
        // pnlConstraintCount.add(lblGroupRatio, cc.xy(1, 7));
        pnlConstraintCount.add(lblNutrientCount, cc.xy(2, 2));
        pnlConstraintCount.add(lblNutrientRatioCount, cc.xy(2, 3));
        pnlConstraintCount.add(lblFoodCount, cc.xy(2, 4));
        pnlConstraintCount.add(lblFoodRatioCount, cc.xy(2, 5));
        pnlConstraintCount.add(lblGroupCount, cc.xy(2, 6));
        // pnlConstraintCount.add(lblGroupRatioCount, cc.xy(2, 7));
        JPanel pnl = new JPanel();
        FormLayout lyoPnl = new FormLayout(
                "4px,min:GROW,4px,p,4px", // columns
                "4px,FILL:min:GROW,4px" // rows
        );
        pnl.setLayout(lyoPnl);
        pnl.add(new JScrollPane(tblMixResults), cc.xy(2, 2));
        selectorMixResultsTable = new NutrientCategorySelector(tblMixResults);
        selectorMixResultsTable.setSelected(Nutrients.Calories);
        pnl.add(selectorMixResultsTable, cc.xy(4, 2));
        tabResults.add(pnl);
        tabResults.add(getEditorDri(tblDri));
        tabResults.add(getEditorModel());
        int size = 32;
        String txt0 = StringUtils.center("Nutrient Contribution By Food", size);
        String txt1 = StringUtils.center("Dietary Reference Intake", 32);
        String txt2 = StringUtils.center("Linear Programming Model", 32);
        tabResults.setTitleAt(0, txt0);
        tabResults.setTitleAt(1, txt1);
        tabResults.setTitleAt(2, txt2);
        pnlObjective.add(new JLabel("Lifestage"), cc.xy(1, 1));
        pnlObjective.add(spnLifestage, cc.xy(1, 2));
        pnlObjective.add(new JLabel("Minimization Option"), cc.xy(1, 3));
        pnlObjective.add(spnMinimizationOption, cc.xy(1, 4));
        pnlObjective.add(new JLabel("Objective Value"), cc.xy(1, 5));
        pnlObjective.add(scrCost, cc.xy(1, 6));
        pnlObjective.add(new JLabel("Total Nutrient Index"), cc.xy(1, 7));
        pnlObjective.add(scrTni, cc.xy(1, 8));
        pnlRight.add(pnlConstraintCount, cc.xy(1, 1));
        pnlRight.add(pnlObjective, cc.xy(1, 2));
        pnlMain.add(tabResults, cc.xy(1, 1));
        pnlMain.add(pnlRight, cc.xy(2, 1));
        splMain.setOrientation(JSplitPane.VERTICAL_SPLIT);
        splMain.setOneTouchExpandable(true);
        splMain.setTopComponent(pnlMain);
        splMain.setBottomComponent(getConstraintsPanel());
        lst_Tni.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE) {
                    clearCost();
                    clearHighscore();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }

            @Override
            public void keyTyped(KeyEvent e) {
            }

        });
        lst_Cost.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE) {
                    clearCost();
                    clearHighscore();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }

            @Override
            public void keyTyped(KeyEvent e) {
            }

        });
        Action high = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                splMain.setDividerLocation(0.0);
            }

        };
        Action middle = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                setSplitPanelDivider();
            }

        };
        Action low = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                splMain.setDividerLocation(1.0);
            }

        };
        InputMap inputMap = tabMain.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        ActionMap actionMap = tabMain.getActionMap();
        inputMap.put(KeyStroke.getKeyStroke("control L"), "min");
        inputMap.put(KeyStroke.getKeyStroke("control M"), "mid");
        inputMap.put(KeyStroke.getKeyStroke("control H"), "max");
        actionMap.put("min", low);
        actionMap.put("mid", middle);
        actionMap.put("max", high);
        spnLifestage.addChangeListener((ChangeEvent e) -> {
            LifeStageDO lifestage = spnLifestage.getSelectedItem();
            cmbLifestage.setSelectedItem(lifestage);
        });
        spnMinimizationOption.addChangeListener((ChangeEvent e) -> {
            minimizationOption = spnMinimizationOption.getSelectedItem();
            txtMinimizationOption.setFormatterFactory(new AbstractFormatterFactory() {
                @Override
                public AbstractFormatter getFormatter(JFormattedTextField tf) {
                    return new ObjectiveFormatter();
                }

            });
            txtMinimizationOption.setToolTipText(minimizationOption.tooltip());
            lstmdl_Cost.clear();
            lstmdl_Tni.clear();
        });
        return splMain;
    }

    private JTabbedPane getEditorBottomPanel() {
        JTabbedPane tab = new JTabbedPane();
        tab.setTabPlacement(SwingConstants.BOTTOM);
        int size = 7;
        String txt0 = StringUtils.center("Mix", size);
        String txt1 = StringUtils.center("Meals", size);
        String txt2 = StringUtils.center("Groups", size);
        tab.add(txt0, getModelPanel());
        tab.add(txt1, getMealPlanPanel());
        tab.add(txt2, getFoodGroupsPanel());
        tab.setToolTipTextAt(0, "This is where you create your food mix.");
        tab.setToolTipTextAt(1, "This is where you create your meal plan for mix.");
        tab.setToolTipTextAt(2, "This is where you create food groups that participate in the mix.");
        return tab;
    }

    private JPanel getFoodCategoriesPanel() {
        tblAllFoods = new TableFood();
        tblAllFoodCategories = new TableCategory();
        tblFoodsInCategory = new TableFood();
        TableCategory tblParentCategories = new TableCategory();
        JScrollPane scrAllFoods = new JScrollPane(tblAllFoods);
        scrAllFoods.setBorder(new TitledBorder("All Foods"));
        JScrollPane scrAllFoodCategories = new JScrollPane(tblAllFoodCategories);
        scrAllFoodCategories.setBorder(new TitledBorder("Categories"));
        JScrollPane scrFoodsInCategory = new JScrollPane(tblFoodsInCategory);
        JScrollPane scrParentCategories = new JScrollPane(tblParentCategories);
        JTextField txtSearchCategories = tblAllFoodCategories.getTxtSearch();
        JTextField txtSearchAllFoods = tblAllFoods.getTxtSearch();
        JTextField txtSearchFoodsInCategory = tblFoodsInCategory.getTxtSearch();
        JPanel pnlMain = new JPanel();
        JPanel pnlCategories = new JPanel();
        JPanel pnlAllFoods = new JPanel();
        JPanel pnlCategoryFoods = new JPanel();
        JPanel pnlCategoryButtons = new JPanel();
        JPanel pnlFoodButtons = new JPanel();
        JPanel pnlButtons = new JPanel();
        FormLayout lyoMain = new FormLayout(
                "m:GROW,8px,m:GROW", // columns
                "FILL:200px,8px,FILL:min:GROW,min" // rows
        );
        lyoMain.setColumnGroups(new int[][]{{1, 3}});
        FormLayout lyoCategories = new FormLayout(
                "min,min:GROW", // columns
                "8px,FILL:28px,FILL:min:GROW" // rows
        );
        FormLayout lyoAllFoods = new FormLayout(
                "min,min:GROW", // columns
                "8px,FILL:28px,FILL:min:GROW" // rows
        );
        FormLayout lyoCategoryFoods = new FormLayout(
                "min,min:GROW", // columns
                "FILL:28px,FILL:min:GROW" // rows
        );
        FormLayout lyoButtons = new FormLayout(
                "m:GROW,min,min,m:GROW", // columns
                "min,8px" // rows
        );
        JLabel lblSearchCategories = new JLabel("Search: ");
        JLabel lblSearchAllFoods = new JLabel("Search: ");
        JLabel lblSearchFoodsInCategory = new JLabel("Search: ");
        JButton btnAddCategory = new JButton("+");
        JButton btnDeleteCategory = new JButton("-");
        JButton btnRenameCategory = new JButton("r");
        JButton btnDuplicateCategory = new JButton("d");
        JButton btnExportCategory = new JButton("e");
        JButton btnAddFoodToCategory = new JButton("+");
        JButton btnDeleteFoodFromCategory = new JButton("-");
        JPopupMenu pmn = new JPopupMenu();
        JMenuItem mniFoodCategories = new JMenuItem("Show food categories");
        pnlCategories.setLayout(lyoCategories);
        pnlCategoryFoods.setLayout(lyoCategoryFoods);
        lblSearchCategories.setToolTipText(
                "Search field input should be a valid regex expression (case insensitive match)");
        lblSearchAllFoods.setToolTipText(
                "Search field input should be a valid regex expression (case insensitive match)");
        lblSearchFoodsInCategory.setToolTipText(
                "Search field input should be a valid regex expression (case insensitive match)");
        pnlCategoryButtons.add(btnAddCategory);
        pnlCategoryButtons.add(btnDeleteCategory);
        pnlCategoryButtons.add(btnRenameCategory);
        pnlCategoryButtons.add(btnDuplicateCategory);
        pnlCategoryButtons.add(btnExportCategory);
        pnlCategoryButtons.setBorder(new TitledBorder("Category"));
        pnlButtons.setLayout(lyoButtons);
        pnlButtons.add(pnlCategoryButtons, cc.xy(2, 1));
        pnlButtons.add(pnlFoodButtons, cc.xy(3, 1));
        pnlFoodButtons.add(btnAddFoodToCategory);
        pnlFoodButtons.add(btnDeleteFoodFromCategory);
        pnlFoodButtons.setBorder(new TitledBorder("Food"));
        btnAddCategory.setToolTipText("Create category");
        btnDeleteCategory.setToolTipText("Delete category");
        btnRenameCategory.setToolTipText("Rename category");
        btnDuplicateCategory.setToolTipText("Duplicate category");
        btnExportCategory.setToolTipText("Export category");
        btnAddFoodToCategory.setToolTipText("Add food item to category");
        btnDeleteFoodFromCategory.setToolTipText("Remove food item from category");
        scrFoodsInCategory.setBorder(new TitledBorder("Category Foods"));
        pnlMain.setLayout(lyoMain);
        pnlAllFoods.setLayout(lyoAllFoods);
        pnlCategories.add(lblSearchCategories, cc.xy(1, 2));
        pnlCategories.add(txtSearchCategories, cc.xy(2, 2));
        pnlCategories.add(scrAllFoodCategories, cc.xyw(1, 3, 2));
        pnlCategoryFoods.add(lblSearchFoodsInCategory, cc.xy(1, 1));
        pnlCategoryFoods.add(txtSearchFoodsInCategory, cc.xy(2, 1));
        pnlCategoryFoods.add(scrFoodsInCategory, cc.xyw(1, 2, 2));
        pnlAllFoods.add(lblSearchAllFoods, cc.xy(1, 2));
        pnlAllFoods.add(txtSearchAllFoods, cc.xy(2, 2));
        pnlAllFoods.add(scrAllFoods, cc.xyw(1, 3, 2));
        pnlMain.add(pnlAllFoods, cc.xywh(1, 1, 1, 4));
        pnlMain.add(pnlCategories, cc.xy(3, 1));
        pnlMain.add(pnlCategoryFoods, cc.xy(3, 3));
        pnlMain.add(pnlButtons, cc.xy(3, 4));
        try {
            Future<List<TableCategoryRow>> task = TaskLauncher.submit(new FoodCategoriesTaskUsingRecords());
            List<TableCategoryRow> foodcategories = task.get();
            tblAllFoodCategories.reload(foodcategories);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        btnAddCategory.addActionListener((ActionEvent evt) -> {
            addCategory();
        });
        btnRenameCategory.addActionListener((ActionEvent evt) -> {
            renameCategory();
        });
        btnDeleteCategory.addActionListener((ActionEvent evt) -> {
            deleteCategory();
        });
        btnDuplicateCategory.addActionListener((ActionEvent evt) -> {
            duplicateCategory();
        });
        btnExportCategory.addActionListener((ActionEvent evt) -> {
            exportCategory();
        });
        tblAllFoodCategories.getSelectionModel().addListSelectionListener((ListSelectionEvent a) -> {
            if (a.getValueIsAdjusting()) {
                return;
            }
            if (tblAllFoodCategories.isSelectionEmpty()) {
                return;
            }
            TableCategoryRow category = tblAllFoodCategories.getSelectedValue();
            try {
                Future<List<List>> task = TaskLauncher.submit(new FoodsInCategoryTask((category.categoryId())));
                List<List> categoryFoods = task.get();
                tblFoodsInCategory.reload(categoryFoods);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        });
        btnAddFoodToCategory.addActionListener((ActionEvent evt) -> {
            addFoodToCategory();
        });
        btnDeleteFoodFromCategory.addActionListener((ActionEvent evt) -> {
            removeFoodFromCategory();
        });
        pmn.add(mniFoodCategories);
        mniFoodCategories.addActionListener((ActionEvent evt) -> {
            if (!tblAllFoods.isSelectionEmpty()) {
                TableFood.Row food = tblAllFoods.getSelectedValue();
                try {
                    Future<List<TableCategoryRow>> task = TaskLauncher.submit(new FoodCategoriesTask02UsingRecords((food.getFoodid())));
                    List<TableCategoryRow> categoryFoods = task.get();
                    tblParentCategories.reload(categoryFoods);
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                JPanel input_panel = new JPanel();
                input_panel.add(scrParentCategories);
                scrParentCategories.setPreferredSize(new Dimension(200, 100));
                JComponent[] inputs = {input_panel};
                Message.showMessage(inputs, "Food Categories");
            } else {
                Message.showMessage("Please select food item");
            }
        });
        tblAllFoods.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (SwingUtilities.isRightMouseButton(e)) {
                    Component component = e.getComponent();
                    pmn.show(component, e.getX(), e.getY());
                }
            }

        });
        return pnlMain;
    }

    private JPanel getFoodComparisonPanel() {
        JPanel pnl = new JPanel();
        tblFoodDiffA = new TableFood();
        tblFoodDiffB = new TableFood();
        tblFoodDiff = new TableFoodDiff();
        JScrollPane scrC = new JScrollPane(tblFoodDiff);
        JPanel pnlSearch = new JPanel();
        JLabel lblSearch = new JLabel("Search: ");
        lblSearch.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        FormLayout lyo = new FormLayout(
                "4px,391px:GROW,4px,391px:GROW,4px,678px:GROW,4px", // columns
                "min,FILL:min:GROW,4px" // rows
        );
        FormLayout lyo02 = new FormLayout(
                "min,min:GROW", // columns
                "4dlu,FILL:28px,4dlu" // rows
        );
        JPanel pnlFoodAList = new JPanel();
        JPanel pnlFoodBList = new JPanel();
        FormLayout lyo03 = new FormLayout(
                "min,min:GROW", // columns
                "4dlu,FILL:28px,4dlu,FILL:min:GROW" // rows
        );
        pnlFoodAList.setLayout(lyo03);
        JScrollPane scrA = new JScrollPane(tblFoodDiffA);
        scrA.setBorder(new TitledBorder("Food A"));
        JLabel lblA = new JLabel("Search: ");
        lblA.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        pnlFoodAList.add(lblA, cc.xy(1, 2));
        JTextField txtComparisonFoodASearch = tblFoodDiffA.getTxtSearch();
        pnlFoodAList.add(txtComparisonFoodASearch, cc.xy(2, 2));
        pnlFoodAList.add(scrA, cc.xyw(1, 4, 2));
        pnlFoodBList.setLayout(lyo03);
        JScrollPane scrB = new JScrollPane(tblFoodDiffB);
        scrB.setBorder(new TitledBorder("Food B"));
        JLabel lblB = new JLabel("Search: ");
        lblB.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        pnlFoodBList.add(lblB, cc.xy(1, 2));
        JTextField txtComparisonFoodBSearch = tblFoodDiffB.getTxtSearch();
        pnlFoodBList.add(txtComparisonFoodBSearch, cc.xy(2, 2));
        pnlFoodBList.add(scrB, cc.xyw(1, 4, 2));
        pnl.setLayout(lyo);
        pnl.add(pnlFoodAList, cc.xywh(2, 1, 1, 2));
        pnl.add(pnlFoodBList, cc.xywh(4, 1, 1, 2));
        pnlSearch.setLayout(lyo02);
        lblSearch.setHorizontalAlignment(SwingConstants.RIGHT);
        pnlSearch.add(lblSearch, cc.xy(1, 2));
        pnlSearch.add(tblFoodDiff.getSearchField(), cc.xy(2, 2));
        pnl.add(pnlSearch, cc.xy(6, 1));
        pnl.add(scrC, cc.xy(6, 2));
        scrC.setBorder(new TitledBorder("Food Difference"));
        tblFoodDiffA.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            calculateFoodDifference(e);
        });
        tblFoodDiffB.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            calculateFoodDifference(e);
        });
        return pnl;
    }

    private void calculateFoodDifference(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) {
            return;
        }
        if (tblFoodDiffA.isSelectionEmpty()) {
            return;
        }
        if (tblFoodDiffB.isSelectionEmpty()) {
            return;
        }
        int selectedRowA = tblFoodDiffA.getSelectedRow();
        int selectedRowB = tblFoodDiffB.getSelectedRow();
        String fooddiffida = (String) tblFoodDiffA.getValueAt(selectedRowA, 0);
        String fooddiffidb = (String) tblFoodDiffB.getValueAt(selectedRowB, 0);
        try {
            Future<List<List>> task = TaskLauncher.submit(new FoodDiffTask(fooddiffida, fooddiffidb));
            List<List> diff = task.get();
            tblFoodDiff.reload(diff);
        } catch (Exception ex) {
            LoggerImpl.INSTANCE.logProblem(ex);
        }
    }

    private JPanel getFoodConstraintsPanel() {
        JPanel pnl = new JPanel();
        FormLayout panelLayout = new FormLayout(
                "min:GROW,250px:GROW,250px:GROW,45px,100px,28px,min:GROW", // columns
                "FILL:28px,FILL:145px:GROW,min" // rows
        );
        pnl.setLayout(panelLayout);
        tblFoodQuantityConstraint = new TableFoodQuantityConstraint();
        JScrollPane scrollPane = new JScrollPane(tblFoodQuantityConstraint);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JPanel buttons = new JPanel();
        pnl.add(cmbFoodQuantityFood, cc.xy(2, 1));
        pnl.add(cmbFoodQuantityNutrient, cc.xy(3, 1));
        pnl.add(cmbFoodQuantityRelationship, cc.xy(4, 1));
        pnl.add(txtFoodQuantityValue, cc.xy(5, 1));
        pnl.add(scrollPane, cc.xyw(2, 2, 5));
        buttons.add(btnAddFoodQuantityConstraint);
        buttons.add(btnDeleteFoodQuantityConstraint);
        buttons.add(btnBlock);
        pnl.add(buttons, cc.xyw(2, 3, 5));
        scrollPane.setBorder(new TitledBorder("Food Nutrient Constraints"));
        cmbFoodQuantityNutrient.setMaximumRowCount(10);
        cmbFoodQuantityRelationship.setMaximumRowCount(3);
        ((JLabel) cmbFoodQuantityRelationship.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        cmbFoodQuantityFood.setMaximumRowCount(10);
        btnAddFoodQuantityConstraint.setToolTipText("Add Constraint");
        btnDeleteFoodQuantityConstraint.setToolTipText("Delete Constraint");
        btnAddFoodQuantityConstraint.addActionListener((ActionEvent evt) -> {
            addFoodQuantityConstraint();
        });
        btnDeleteFoodQuantityConstraint.addActionListener((ActionEvent evt) -> {
            if (tblFoodQuantityConstraint.isSelectionEmpty()) {
                return;
            }
            deleteFoodQuantityConstraint();
        });
        btnBlock.addActionListener((ActionEvent evt) -> {
            blockFood();
        });
        tblFoodQuantityConstraint.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            if (tblFoodQuantityConstraint.isSelectionEmpty()) {
                return;
            }
            setFoodQuantityConstraintGuiValues();
        });
        JPopupMenu pmn = new JPopupMenu();
        JMenuItem item01 = new JMenuItem("Plus");
        JMenuItem item02 = new JMenuItem("Minus");
        pmn.add(item01);
        pmn.add(item02);
        item01.addActionListener((ActionEvent evt) -> {
            if (txtFoodQuantityValue.getText().isBlank()) {
                return;
            }
            Double total = plusQuantity(Double.valueOf(txtFoodQuantityValue.getText()));
            txtFoodQuantityValue.setText(String.valueOf(total));
        });
        item02.addActionListener((ActionEvent evt) -> {
            if (txtFoodQuantityValue.getText().isBlank()) {
                return;
            }
            Double total = minusQuantity(Double.valueOf(txtFoodQuantityValue.getText()));
            txtFoodQuantityValue.setText(String.valueOf(total));
        });
        txtFoodQuantityValue.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                showPopup(e, pmn);
            }

        });
        return pnl;
    }

    private JPanel getFoodList() {
        JPanel pnl = new JPanel();
        FormLayout paneLayout = new FormLayout(
                "4px,min:GROW,4px,min,4px", // columns
                "min,FILL:min:GROW,4px,min,4px" // rows
        );
        pnl.setLayout(paneLayout);
        JPanel searchPanel = new JPanel();
        FormLayout searchPanelLayout = new FormLayout(
                "min,min:GROW", // columns
                "4px,FILL:28px,4px" // rows
        );
        searchPanel.setLayout(searchPanelLayout);
        JPanel buttonPanel = new JPanel();
        FormLayout buttonPanelLayout = new FormLayout(
                "min:GROW,min,min,min,min,min:GROW", // columns
                "min" // rows
        );
        buttonPanel.setLayout(buttonPanelLayout);
        tblFoodFacts = new TableFoodFacts();
        NutrientCategorySelector selectorFoodFactsTable = new NutrientCategorySelector(tblFoodFacts);
        selectorFoodFactsTable.setSelected(Nutrients.Calories);
        JScrollPane scrollPaneTable01 = new JScrollPane(tblFoodFacts);
        scrollPaneTable01.setToolTipText("A new food item is generated everytime a food nutrient quantity is updated.");
        scrollPaneTable01.getViewport().setScrollMode(JViewport.BLIT_SCROLL_MODE);
        JLabel label = new JLabel("Search: ");
        label.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        label.setHorizontalAlignment(SwingConstants.RIGHT);
        searchPanel.add(label, cc.xy(1, 2));
        searchPanel.add(tblFoodFacts.getTxtSearch(), cc.xy(2, 2));
        buttonPanel.add(btnAddFood, cc.xy(2, 1));
        buttonPanel.add(btnDeriveFood, cc.xy(3, 1));
        buttonPanel.add(btnRenameFood, cc.xy(4, 1));
        buttonPanel.add(btnDeleteFood, cc.xy(5, 1));
        pnl.add(searchPanel, cc.xyw(2, 1, 2));
        pnl.add(scrollPaneTable01, cc.xy(2, 2));
        pnl.add(selectorFoodFactsTable, cc.xy(4, 2));
        pnl.add(buttonPanel, cc.xyw(2, 4, 3));
        scrollPaneTable01.setBorder(new TitledBorder("Food List"));
        btnAddFood.setToolTipText("Add new food item");
        btnDeriveFood.setToolTipText("Create new food item from existing one");
        btnRenameFood.setToolTipText("Rename food item");
        btnDeleteFood.setToolTipText("Delete food item");
        btnAddFood.addActionListener((ActionEvent evt) -> {
            addFoodToDatabase();
        });
        btnDeriveFood.addActionListener((ActionEvent evt) -> {
            addDerivedFoodToDatabase();
        });
        btnRenameFood.addActionListener((ActionEvent evt) -> {
            renameFood();
        });
        btnDeleteFood.addActionListener((ActionEvent evt) -> {
            removeFoodFromDatabase();
        });
        tblFoodFacts.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            if (tblFoodFacts.isSelectionEmpty()) {
            }
        });
        JPopupMenu pmn = new JPopupMenu();
        JMenuItem mniFoodStats = new JMenuItem("Show food statistics");
        pmn.add(mniFoodStats);
        mniFoodStats.addActionListener((ActionEvent evt) -> {
            if (!tblFoodFacts.isSelectionEmpty()) {
                TableFoodFacts.Row food = tblFoodFacts.getSelectedValue();
                foodStats.reload(food.getId_food_id());
                Message.showMessage(foodStats.get_stats());
            } else {
                Message.showMessage("Please select food item");
            }
        });
        tblFoodFacts.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (SwingUtilities.isRightMouseButton(e)) {
                    Component component = e.getComponent();
                    pmn.show(component, e.getX(), e.getY());
                }
            }

        });
        return pnl;
    }

    private JPanel getFoodRatioConstraintsPanel() {
        JPanel pnl = new JPanel();
        tblFoodRatioConstraint = new TableFoodRatioConstraint();
        JScrollPane scrollPane = new JScrollPane(tblFoodRatioConstraint);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JPanel buttons = new JPanel();
        FormLayout panelLayout = new FormLayout(
                "255px:GROW,255px:GROW,100px,45px,255px:GROW,255px:GROW,100px,28px", // columns
                "FILL:28px,FILL:145px:GROW,min" // rows;
        );
        pnl.setLayout(panelLayout);
        scrollPane.setBorder(new TitledBorder("Food Nutrient Ratio Constraints"));
        pnl.add(cmbFoodRatioFoodA, cc.xy(1, 1));
        pnl.add(cmbFoodRatioNutrientA, cc.xy(2, 1));
        pnl.add(txtFoodNutrientRatioQuantityA, cc.xy(3, 1));
        pnl.add(cmbFoodRatioRelationship, cc.xy(4, 1));
        pnl.add(cmbFoodRatioFoodB, cc.xy(5, 1));
        pnl.add(cmbFoodRatioNutrientB, cc.xy(6, 1));
        pnl.add(txtFoodNutrientRatioQuantityB, cc.xy(7, 1));
        pnl.add(scrollPane, cc.xyw(1, 2, 8));
        buttons.add(btnAddFoodRatioConstraint);
        buttons.add(btnDeleteFoodRatioConstraint);
        pnl.add(buttons, cc.xyw(1, 3, 8));
        btnAddFoodRatioConstraint.setToolTipText("Add Constraint");
        btnDeleteFoodRatioConstraint.setToolTipText("Delete Constraint");
        ((JLabel) cmbFoodRatioRelationship.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        btnAddFoodRatioConstraint.addActionListener((ActionEvent evt) -> {
            addFoodRatioConstraint();
        });
        btnDeleteFoodRatioConstraint.addActionListener((ActionEvent evt) -> {
            if (tblFoodRatioConstraint.isSelectionEmpty()) {
                return;
            }
            deleteFoodRatioConstraint();
        });
        tblFoodRatioConstraint.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            if (tblFoodRatioConstraint.isSelectionEmpty()) {
                return;
            }
            setFoodRatioConstraintGuiValues();
        });
        return pnl;
    }

    private JPanel getMealPlanUsagePanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "p:GROW", // columns
                "FILL:min:GROW" // rows
        );
        pnl.setLayout(lyo);
        JSplitPane spl00 = new JSplitPane();
        JSplitPane spl01 = new JSplitPane();
        spl00.setLeftComponent(getMealPlanUsageMixesPanel());
        spl00.setRightComponent(getMealPlanUsageDaysPanel());
        spl01.setLeftComponent(spl00);
        spl01.setRightComponent(getMealPlanUsageResultPanel());
        pnl.add(spl01, cc.xy(1, 1));
        exectureMealPlanUsageTasks();
        return pnl;
    }

    private void exectureMealPlanUsageTasks() {
        try {
            Future<List<List>> task = TaskLauncher.submit(new MealPlanUsageTask());
            List<List> usage = task.get();
            tblMealPlanUsage.reload(usage);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        try {
            Future<List<List>> task = TaskLauncher.submit(new MealPlanUsageResultsTask());
            List<List> results = task.get();
            tblMealPlanUsageResults.reload(results);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private JPanel getMealsPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "p:GROW", // columns
                "FILL:min:GROW,min" // rows
        );
        pnl.setLayout(lyo);
        tblMeals = new TablePortionMeals();
        JScrollPane spTable = new JScrollPane(tblMeals);
        spTable.setPreferredSize(Dimensions.D1.get());
        JPanel buttons = new JPanel();
        pnl.add(spTable, cc.xy(1, 1));
        buttons.add(btnAddMeal);
        buttons.add(btnDeleteMeal);
        buttons.add(btnUpdateMeal);
        pnl.add(buttons, cc.xy(1, 2));
        spTable.setBorder(new TitledBorder("Meals"));
        btnAddMeal.setToolTipText("Add Meal");
        btnDeleteMeal.setToolTipText("Delete Meal");
        btnUpdateMeal.setToolTipText("Update Meal");
        btnAddMeal.addActionListener((ActionEvent evt) -> {
            addMeal();
        });
        btnDeleteMeal.addActionListener((ActionEvent evt) -> {
            deleteMeal();
        });
        btnUpdateMeal.addActionListener((ActionEvent evt) -> {
            updateMeal();
        });
        return pnl;
    }

    private JPanel getMealCaloriesPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "min:GROW,878px,min:GROW", // columns
                "FILL:p:GROW" // rows
        );
        pnl.setLayout(lyo);
        tblMealCalories = new TableMealCalories();
        JScrollPane spTable = new JScrollPane(tblMealCalories);
        pnl.add(spTable, cc.xy(2, 1));
        return pnl;
    }

    private JPanel getMealMacronutrientsPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "min:GROW,953px,min:GROW", // columns
                "FILL:p:GROW" // rows
        );
        pnl.setLayout(lyo);
        tblMealMacronutrients = new TableMealGrams();
        JScrollPane spTable = new JScrollPane(tblMealMacronutrients);
        pnl.add(spTable, cc.xy(2, 1));
        return pnl;
    }

    private JPanel getMealPortionsPanel() {
        JPanel pnl = new JPanel();
        tblMealPortions = new TablePortion();
        FormLayout lyo = new FormLayout(
                "min:GROW,p,p,p,812px,p,p,p,min:GROW", // columns
                "FILL:29px,FILL:200px,FILL:28px,FILL:min:GROW,min" // rows
        );
        pnl.setLayout(lyo);
        JScrollPane spPortions = new JScrollPane(tblMealPortions);
        JPanel buttons = new JPanel();
        txtTotalPct.setEditable(false);
        txtTotalPct.setPreferredSize(Dimensions.Pct.get());
        txtPortionPct.setPreferredSize(Dimensions.Pct.get());
        JLabel lblSearch = new JLabel("Search: ");
        lblSearch.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        lblSearch.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel lblPortionPct = new JLabel("Portion: ");
        JLabel lblPortionPct2 = new JLabel("% ");
        lblPortionPct.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel lblAllocatedPct = new JLabel(" Allocated: ");
        lblAllocatedPct.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel lblTotalPct2 = new JLabel("%");
        buttons.add(btnAddPortion);
        buttons.add(btnDeletePortion);
        buttons.add(btnUpdatePortionWeight);

        pnl.add(lblPortionPct, cc.xy(2, 1));
        pnl.add(txtPortionPct, cc.xy(3, 1));
        pnl.add(lblPortionPct2, cc.xy(4, 1));
        pnl.add(cmbPortionFood, cc.xy(5, 1));
        pnl.add(lblAllocatedPct, cc.xy(6, 1));
        pnl.add(txtTotalPct, cc.xy(7, 1));
        pnl.add(lblTotalPct2, cc.xy(8, 1));

        pnl.add(getMealsPanel(), cc.xyw(2, 2, 7));

        pnl.add(lblSearch, cc.xy(2, 3));
        pnl.add(tblMealPortions.getSearchField(), cc.xyw(3, 3, 6));

        pnl.add(spPortions, cc.xyw(2, 4, 7));

        pnl.add(buttons, cc.xyw(2, 5, 7));

        spPortions.setBorder(new TitledBorder("Food Portions"));
        cmbPortionFood.setMaximumRowCount(6);
        btnAddPortion.setToolTipText("Add one or more food portions");
        btnDeletePortion.setToolTipText("Delete one or more food portions");
        btnUpdatePortionWeight.setToolTipText("Update weight of food portion consumed");
        btnAddPortion.addActionListener((ActionEvent evt) -> {
            addFoodPortion();
        });
        btnDeletePortion.addActionListener((ActionEvent evt) -> {
            deleteFoodPortion();
        });
        btnUpdatePortionWeight.addActionListener((ActionEvent evt) -> {
            updateFoodPortionWeight();
        });
        cmbPortionFood.addActionListener((ActionEvent evt) -> {
            calculateRemainingFoodAllocationPercentage();
        });
        JPopupMenu pmn = new JPopupMenu();
        JMenuItem item01 = new JMenuItem("Assign portion to meal");
        pmn.add(item01);
        item01.addActionListener((ActionEvent evt) -> {
            moveFoodPortion();
        });
        tblMealPortions.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                showPopup(e, pmn);
            }

        });
        return pnl;
    }

    private JMenuBar getMenuBar() {
        JMenuBar mnuBar = new JMenuBar();
        mnuBar.add(mnuProgram);
        mnuBar.add(mnuMix);
        mnuBar.add(mnuTools);
        mnuBar.add(mnuData);
        mnuBar.add(mnuReport);
        mnuBar.add(mnuHelp);
        mnuProgram.add(mnuSettings);
        mnuProgram.add(mniExit);
        mnuTools.add(mniConvertDRI);
        mnuTools.add(mniCalculateBMR);
        mnuTools.add(mniCalculateProteinRequired);
        mnuTools.add(mniShowCarbohydrateRequired);
        mnuTools.add(mniCalculateDigestibleCarbs);
        mnuTools.add(mniCalculateGL);
        mnuTools.add(mniCalculateGIRange);
        mnuTools.add(mniCalculateALARequired);
        mnuData.add(mnuFoodsData);
        mnuData.add(new JSeparator());
        mnuData.add(new JSeparator());
        mnuData.add(new JSeparator());
        mnuData.add(mnuMixModel);
        mnuData.add(new JSeparator());
        mnuData.add(new JSeparator());
        mnuData.add(new JSeparator());
        mnuData.add(mnuDELETE);
        mnuReport.add(mniCreateFoodComparisonReport);
        mnuReport.add(mniCreateMealPlanCaloriesReport);
        mnuReport.add(mniCreateMealPlanMacronutrientsReport);
        mnuReport.add(mniCreateMealPlanPortionsReport);
        mnuReport.add(mniCreateMealPlanUsageReport);
        mnuReport.add(mniCreateMixComparisonReport);
        mnuReport.add(mniCreateMixDriReport);
        mnuReport.add(mniCreateMixResultsReportDn);
        mnuReport.add(mniCreateMixResultsReport);
        mnuReport.add(mniCreateMixTotalsReport);
        mnuReport.add(mniCreateNutrientSearchReport);
        mnuReport.add(new JSeparator());
        mnuReport.add(mniCreateAllFoodsReportDn);
        mnuReport.add(mniCreateAllFoodsReport);
        mnuDELETE.add(mniDELETEMIXES);
        mnuDELETE.add(mniDELETEALL);
        mnuMixModel.add(mniImportMix);
        mnuMixModel.add(mniExportMix);
        mnuFoodsData.add(mniImportFoods);
        mnuFoodsData.add(mniExportFoods);
        mnuHelp.add(mniAbout);
        mnuSettings.add(chkResultRoundUp);
        mnuSettings.add(cbToJava);
        mnuSettings.add(cbToCplex);
        mnuSettings.add(cbToCplexExp);
        mnuSettings.add(cbToCplexMeals);
        mnuSettings.add(cbToRust);
        mnuSettings.add(cbToC);
        mnuSettings.add(cbToR);
        mnuSettings.add(mniSetConstraints);
        mnuMix.add(mniCreateMix);
        mnuMix.add(mniDeleteMix);
        mnuMix.add(mniRenameMix);
        mnuMix.add(mniDuplicateMix);
        mnuMix.add(mniPinMixAndDeleteConstraints);
        mnuMix.add(mniPinMixAndKeepConstraints);
        mnuMix.add(mniConvertMix);
        mnuMix.add(mniShowMixStats);
        mnuProgram.setText("Program");
        mnuMix.setText("Mix");
        mnuTools.setText("Tools");
        mnuData.setText("Data");
        mnuData.setToolTipText("Find your documents in snack's model directory");
        mnuHelp.setText("Help");
        mnuSettings.setText("Settings");
        mniExit.setText("Exit");
        mniConvertDRI.setText("Convert daily value (%DV) required to grams");
        mniCalculateBMR.setText("Calculate basal metabolic rate of an individual");
        mniCalculateProteinRequired.setText("Calculate complete protein required in a no fat, no carbohydrate regimen");
        mniShowCarbohydrateRequired.setText("Show carbohydrate required to inhibit ketosis");
        mniCalculateDigestibleCarbs.setText("Calculate digestible carbohydrate of a food item");
        mniCalculateGL.setText("Calculate glycemic load of a food item");
        mniCalculateALARequired.setText("Calculate alpha-linolenic acid required");
        mniCalculateGIRange.setText("Show glycemic index range of a food item");
        mnuReport.setText("Reports");
        mnuMixModel.setText("Model");
        mnuMixResult.setText("Result");
        mnuFoodsData.setText("Foods");
        mniCreateAllFoodsReportDn.setText("All Foods");
        mniCreateAllFoodsReport.setText("All Foods Normalized");
        mniCreateFoodComparisonReport.setText("Food Comparison");
        mniCreateMixDriReport.setText("Mix Daily Reference Intake");
        mniCreateMixComparisonReport.setText("Mix Comparison");
        mniCreateMixTotalsReport.setText("Mix Totals");
        mniCreateMixResultsReportDn.setText("Mix Results");
        mniCreateMixResultsReport.setText("Mix Results Normalized");
        mniCreateNutrientSearchReport.setText("Nutrient Search");
        mniCreateMealPlanCaloriesReport.setText("Meal Plan Calories");
        mniCreateMealPlanMacronutrientsReport.setText("Meal Plan Macronutrients");
        mniCreateMealPlanPortionsReport.setText("Meal Plan Portions");
        mniCreateMealPlanUsageReport.setText("Meal Plan Usage");
        mniCreateMD5MixResultsReport.setText("MD5 Mix Results");
        mniImportMix.setText("Import");
        mniExportMix.setText("Export");
        mniImportFoods.setText("Import");
        mniExportFoods.setText("Export");
        chkResultRoundUp.setText("Round up result values");
        cbToCplexMeals.setText("Write to Cplex Meals");
        cbToCplexExp.setText("Write to Cplex Exp");
        cbToCplex.setText("Write to Cplex");
        cbToR.setText("Write model to R");
        cbToJava.setText("Write model to Java");
        cbToRust.setText("Write model to Rust");
        cbToC.setText("Write model to C");
        mniSetConstraints.setText("Choose constraints");
        mniAbout.setText("About");
        mniCreateMix.setText("Create mix");
        mniDeleteMix.setText("Delete mix");
        mniRenameMix.setText("Rename mix");
        mniDuplicateMix.setText("Duplicate mix");
        mniPinMixAndDeleteConstraints.setText("Pin mix and delete constraints");
        mniPinMixAndKeepConstraints.setText("Pin mix and keep constraints");
        mniConvertMix.setText("Convert mix to food item");
        mniShowMixStats.setText("Show mix statistics");
        mnuDELETE.setText("DELETE");
        mniDELETEMIXES.setText("DELETE ALL MIXES");
        mniDELETEALL.setText("DELETE ALL MIXES AND ALL FOOD ITEMS");
        chkResultRoundUp.setSelected(true);
        mniConvertDRI.addActionListener((ActionEvent evt) -> {
            convertMicronutrient();
        });
        mniCalculateBMR.addActionListener((ActionEvent evt) -> {
            calculateBmr();
        });
        mniCalculateProteinRequired.addActionListener((ActionEvent evt) -> {
            calculateProteinNeededForNitrogenBalance();
        });
        mniShowCarbohydrateRequired.addActionListener((ActionEvent evt) -> {
            showKetosis();
        });
        mniCalculateDigestibleCarbs.addActionListener((ActionEvent evt) -> {
            calculateDigestibleCarbs();
        });
        mniCalculateGL.addActionListener((ActionEvent evt) -> {
            calculateGlycemicLoad();
        });
        mniCalculateALARequired.addActionListener((ActionEvent evt) -> {
            calculateN3FattyAcidRequired();
        });
        mniShowMixStats.addActionListener((ActionEvent evt) -> {
            showMixStats();
        });
        mniCalculateGIRange.addActionListener((ActionEvent evt) -> {
            calculateGlycemicIndexRange();
        });
        mniCreateAllFoodsReport.addActionListener((ActionEvent evt) -> {
            createAllFoodsReport();
        });
        mniCreateAllFoodsReportDn.addActionListener((ActionEvent evt) -> {
            createAllFoodsReportDn();
        });
        mniCreateFoodComparisonReport.addActionListener((ActionEvent evt) -> {
            if (tblFoodDiffA.isSelectionEmpty() || tblFoodDiffB.isSelectionEmpty()) {
                Message.showMessage("You need to select two food items to compare first.");
                return;
            }
            createFoodComparisonReport();
            Message.showMessage("Food Comparison Report created.");
        });
        mniCreateMixComparisonReport.addActionListener((ActionEvent evt) -> {
            if (tblMixDiffA.isSelectionEmpty() || tblMixDiffB.isSelectionEmpty()) {
                Message.showMessage("You need to select two mixes to compare first.");
                return;
            }
            createMixComparisonReport();
            Message.showMessage("Mix Comparison Report created.");
        });
        mniCreateMixTotalsReport.addActionListener((ActionEvent evt) -> {
            createMixTotalsReport();
            Message.showMessage("Mix Totals Report appended.");
        });
        mniCreateMixResultsReportDn.addActionListener((ActionEvent evt) -> {
            createMixResultsReportDn();
            Message.showMessage("Mix Results Report Denormalized created.");
        });
        mniCreateMixResultsReport.addActionListener((ActionEvent evt) -> {
            createMixResultsReport();
            Message.showMessage("Mix Results Report created.");
        });
        mniCreateMixDriReport.addActionListener((ActionEvent evt) -> {
            createDriReport();
            Message.showMessage("Daily Reference Intake Report created.");
        });
        mniCreateNutrientSearchReport.addActionListener((ActionEvent evt) -> {
            if (txtNutrientSearchQuantity.getText().isBlank()) {
                Message.showMessage("You need to search for food items that contain the nutrient first.");
                return;
            }
            createNutrientContentReport();
            Message.showMessage("Nutrient Search Report created.");
        });
        mniCreateMealPlanCaloriesReport.addActionListener((ActionEvent evt) -> {
            if (tblMealPortions.isEmpty()) {
                Message.showMessage("You need to create meal plan first.");
                return;
            }
            createMealPlanCaloriesReport();
            Message.showMessage("Meal Plan Calories Report created.");
        });
        mniCreateMealPlanMacronutrientsReport.addActionListener((ActionEvent evt) -> {
            if (tblMealPortions.isEmpty()) {
                Message.showMessage("You need to create meal plan first.");
                return;
            }
            createMealPlanMacronutrientsReport();
            Message.showMessage("Meal Plan Macronutrients Report created.");
        });
        mniCreateMealPlanPortionsReport.addActionListener((ActionEvent evt) -> {
            if (tblMealPortions.isEmpty()) {
                Message.showMessage("You need to create meal plan first.");
                return;
            }
            createMealPlanPortionsReport();
            Message.showMessage("Meal Plan Portions Report created.");
        });
        mniCreateMealPlanUsageReport.addActionListener((ActionEvent evt) -> {
            if (tblMealPlanUsage.isEmpty()) {
                Message.showMessage("You need to create meal plan usage first.");
                return;
            }
            createMealPlanUsageReport();
            Message.showMessage("Meal Plan Usage Report created.");
        });
        mniCreateMD5MixResultsReport.addActionListener((ActionEvent evt) -> {
            if (tblMixResults.isEmpty()) {
                Message.showMessage("There are no results.");
                return;
            }
            createMD5MixResultsReport();
            Message.showMessage("MD5 Mix Results Report created.");
        });
        mniDELETEMIXES.addActionListener((ActionEvent evt) -> {
            deleteAllMixes();
        });
        mniDELETEALL.addActionListener((ActionEvent evt) -> {
            deleteAll();
        });
        mniExportMix.addActionListener((ActionEvent evt) -> {
            exportMix();
        });
        mniImportMix.addActionListener((ActionEvent evt) -> {
            int returnVal = fch_Mix.showOpenDialog(null);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                File file = fch_Mix.getSelectedFile();
                fch_Mix.setCurrentDirectory(file);
                String path = file.getAbsolutePath();
                try {
                    MixDO mix = new MixImporter().receive(path);
                    frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                    setSelectedMix(mix);
                    LifeStageDO foundLifestage
                            = LifestageFinder.find(((SpinnerListModel) spnLifestage.getModel()).getList(), mix.getLifestageid());
                    spnLifestage.setSelectedItem(foundLifestage);
                } catch (Exception e) {
                    frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                    return;
                }
                importMixAndUpdateResults();
            }
        });

        mniImportFoods.addActionListener((ActionEvent evt) -> {
            int returnVal = fch_Foods.showOpenDialog(frm);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                File file = fch_Foods.getSelectedFile();
                String path = file.getAbsolutePath();
                fch_Foods.setCurrentDirectory(new File(path));
                try {
                    new FoodsImporter().importFoodListUsingResource("/resources/schemas/foods.xsd", path);
                    frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                    reloadFoods();
                    setQuantityScale();
                } catch (Exception ex) {
                    frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                }
            }
        }
        );
        mniExportFoods.addActionListener(
                (ActionEvent evt) -> {
                    exportAllCategories();
                }
        );
        mniAbout.addActionListener(
                (ActionEvent evt) -> {
                    showAbout();
                }
        );
        mniSetConstraints.addActionListener(
                (ActionEvent evt) -> {
                    (new ConstraintChooser()).show();
                    reloadCbNutrientData();
                }
        );
        chkResultRoundUp.addActionListener(
                (ActionEvent evt) -> {
                    setQuantityScale();
                }
        );
        mniExit.addActionListener(
                (ActionEvent evt) -> {
                    exit();
                }
        );
        mniCreateMix.addActionListener(
                (ActionEvent evt) -> {
                    createMix();
                }
        );
        mniDeleteMix.addActionListener(
                (ActionEvent evt) -> {
                    deleteMix();
                }
        );
        mniRenameMix.addActionListener(
                (ActionEvent evt) -> {
                    renameMix();
                }
        );
        mniDuplicateMix.addActionListener(
                (ActionEvent evt) -> {
                    duplicateMix();
                }
        );
        mniConvertMix.addActionListener(
                (ActionEvent evt) -> {
                    convertMixToFood();
                }
        );
        mniPinMixAndDeleteConstraints.addActionListener(
                (ActionEvent evt) -> {
                    pinAndDelete();
                }
        );
        mniPinMixAndKeepConstraints.addActionListener(
                (ActionEvent evt) -> {
                    pinAndKeep();
                }
        );
        return mnuBar;
    }

    private void exit() {
        mniExit.setEnabled(false);
        frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        TaskLauncher.execute(() -> {
            try {
                Connect.getInstance().getConnection().close();
                (new Shutdown()).execute();
            } catch (Exception e) {
            } finally {
                System.exit(0);
            }
        });
    }

    private JPanel getMixComparisonPanel() {
        JPanel pnl = new JPanel();
        tblMixDiffA = new TableMix();
        tblMixDiffB = new TableMix();
        tblMixDiff = new TableMixDiff();
        JScrollPane scrA = new JScrollPane(tblMixDiffA);
        JScrollPane scrB = new JScrollPane(tblMixDiffB);
        JScrollPane scrC = new JScrollPane(tblMixDiff);
        JPanel pnlSearch = new JPanel();
        JLabel lblSearch = new JLabel("Search: ");
        lblSearch.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        // create layouts
        FormLayout lyo00 = new FormLayout(
                "4px,391px:GROW,4px,391px:GROW,4px,678px:GROW,4px", // columns
                "4px,min,FILL:min:GROW,4px" // rows
        );
        FormLayout lyo01 = new FormLayout(
                "min,min:GROW", // columns
                "FILL:28px,4dlu" // rows
        );
        pnl.setLayout(lyo00);
        pnl.add(scrA, cc.xywh(2, 2, 1, 2));
        pnl.add(scrB, cc.xywh(4, 2, 1, 2));
        pnlSearch.setLayout(lyo01);
        lblSearch.setHorizontalAlignment(SwingConstants.RIGHT);
        pnlSearch.add(lblSearch, cc.xy(1, 1));
        pnlSearch.add(tblMixDiff.getSearchField(), cc.xy(2, 1));
        pnl.add(pnlSearch, cc.xy(6, 2));
        pnl.add(scrC, cc.xy(6, 3));
        scrA.setBorder(new TitledBorder("Mix A"));
        scrB.setBorder(new TitledBorder("Mix B"));
        scrC.setBorder(new TitledBorder("Mix Difference"));
        tblMixDiffA.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            calculateMixDifference(e);
        });
        tblMixDiffB.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            calculateMixDifference(e);
        });
        return pnl;
    }

    private void calculateMixDifference(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) {
            return;
        }
        if (tblMixDiffA.isSelectionEmpty()) {
            return;
        }
        if (tblMixDiffB.isSelectionEmpty()) {
            return;
        }
        TableMix.Row mixa = tblMixDiffA.getSelectedValue();
        TableMix.Row mixb = tblMixDiffB.getSelectedValue();
        try {
            Future<List<List>> task = TaskLauncher.submit(new MixDiffTask(mixa.getMixid(), mixb.getMixid()));
            List<List> diff = task.get();
            tblMixDiff.reload(diff);
        } catch (Exception ex) {
            LoggerImpl.INSTANCE.logProblem(ex);
        }
    }

    private JPanel getMixFoodPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "min:GROW,min,min:GROW", // columns
                "FILL:min:GROW" // rows
        );
        pnl.setLayout(lyo);
        JPanel pnlFood = new JPanel();
        FormLayout lyoFood = new FormLayout(
                "min:GROW", // columns
                "4px,min,4px,FILL:min:GROW" // rows
        );
        pnlFood.setLayout(lyoFood);
        JPanel pnlSearch = new JPanel();
        FormLayout lyoSearch = new FormLayout(
                "min,min:GROW", // columns
                "FILL:28px:GROW" // rows
        );
        pnlSearch.setLayout(lyoSearch);
        JPanel pnlButtons = new JPanel();
        FormLayout lyoButtons = new FormLayout(
                "min,min:GROW", // columns
                "min:GROW,min,min,min,min,min:GROW" // rows
        );
        pnlButtons.setLayout(lyoButtons);
        tblMixFood = new TableFood();
        JScrollPane mixFoodScrollPane = new JScrollPane(tblMixFood);
        mixFoodScrollPane.setBorder(new TitledBorder("Selected Food"));
        JScrollPane scrFood = new JScrollPane(tree);
        scrFood.setBorder(new TitledBorder("Available Food"));
        tree.setModel(treeModel);
        JButton buttonAddMixFood = new JButton("+");
        JButton buttonDeleteMixFood = new JButton("-");
        JButton buttonExpandMixFood = new JButton("e");
        JButton buttonCollapseMixFood = new JButton("c");
        JTextField txtSearch = new JTextField();
        pnlSearch.add(new JLabel("Search:"), cc.xy(1, 1));
        pnlSearch.add(txtSearch, cc.xy(2, 1));
        pnlFood.add(pnlSearch, cc.xy(1, 2));
        pnlFood.add(scrFood, cc.xy(1, 4));
        pnlButtons.add(buttonAddMixFood, cc.xy(1, 2));
        pnlButtons.add(buttonDeleteMixFood, cc.xy(1, 3));
        pnlButtons.add(buttonExpandMixFood, cc.xy(1, 4));
        pnlButtons.add(buttonCollapseMixFood, cc.xy(1, 5));
        pnl.add(pnlFood, cc.xy(1, 1));
        pnl.add(pnlButtons, cc.xy(2, 1));
        pnl.add(mixFoodScrollPane, cc.xy(3, 1));
        buttonAddMixFood.setToolTipText("Add Food Item to Mix");
        buttonDeleteMixFood.setToolTipText("Delete Food Item from Mix");
        buttonExpandMixFood.setToolTipText("Expand Food List");
        buttonCollapseMixFood.setToolTipText("Collapse Food List");
        buttonAddMixFood.addActionListener(e -> {
            if (cmbMixes.isEmpty()) {
                Message.showMessage("Create or import mix.");
            }
            addMixFood();
        });
        buttonDeleteMixFood.addActionListener(e -> {
            if (cmbMixes.isEmpty()) {
                Message.showMessage("Create or import mix.");
            }
            deleteMixFood();
        });
        buttonExpandMixFood.addActionListener(e -> {
            expandFoods();
        });
        buttonCollapseMixFood.addActionListener(e -> {
            collapseFoods();
        });
        txtSearch
                .getDocument()
                .addDocumentListener(
                        new DocumentListener() {
                    @Override
                    public void insertUpdate(final DocumentEvent e) {
                        createTreeModel();
                    }

                    @Override
                    public void removeUpdate(final DocumentEvent e) {
                        createTreeModel();
                    }

                    @Override
                    public void changedUpdate(final DocumentEvent e) {
                        createTreeModel();
                    }

                    public void createTreeModel() {
                        if (txtSearch.getText().isEmpty()) {
                            tree.setModel(treeModel);
                            return;
                        }
                        if (txtSearch.getText().length() < 2) {
                            return;
                        }
                        String regex = getRegex("(?i)" + txtSearch.getText());
                        RegexCheck check = new RegexCheck(regex);
                        if (!check.pass()) {
                            return;
                        }
                        //
                        TreeModelFilter treeModelRegexFilter = new TreeModelFilter(treeModel, regex);
                        //tree.setCellRenderer( new TreeModelRegexHighlighter( tree.getCellRenderer(), txtSearch.getText() ) );
                        tree.setModel(treeModelRegexFilter.model());
                        expandTree(tree);
                    }

                });
        return pnl;
    }

    private String getRegex(String regex) {
        StringBuilder sb = new StringBuilder();
        // sb.append("(?i)");
        sb.append(".*");
        sb.append(regex);
        sb.append(".*");
        return sb.toString();
    }

    private void expandTree(JTree tree) {
        for (int i = 0; i < tree.getRowCount(); i++) {
            tree.expandRow(i);
        }
    }

    private Double getMixUsageInputForInventory() {
        Double days = 1.0;
        JTextField input = new JTextField();
        JPanel input_panel = new JPanel();
        input.setPreferredSize(new Dimension(50, 25));
        input_panel.add(new JLabel("How many days will you be using this meal plan?"));
        input_panel.add(input);
        JComponent[] inputs = {input_panel};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Meal Plan Usage");
        if (optionValue == 0) {
            String s = input.getText();
            if (s != null && s.length() > 0) {
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(s);
                if (checkNumber.pass()) {
                    days = Double.valueOf(s);
                }
            }
        }
        return days;
    }

    private JPanel getMealPlanUsageDaysPanel() {
        JPanel pnl = new JPanel();
        pnl.setBorder(new TitledBorder("Meal Plan Usage"));
        FormLayout panelLayout = new FormLayout(
                "p:GROW", // columns
                "FILL:min:GROW,min" // rows
        );
        pnl.setLayout(panelLayout);
        tblMealPlanUsage = new TableInventoryDays();
        pnl.add(new JScrollPane(tblMealPlanUsage), cc.xy(1, 1));
        pnl.add(getMealPlanUsageButtonsPanel(), cc.xy(1, 2));
        return pnl;
    }

    private JPanel getMealPlanUsageButtonsPanel() {
        JPanel pnl = new JPanel();
        JButton btn_add = new JButton("+");
        JButton btn_delete = new JButton("-");
        btn_add.setToolTipText("Add meal plan to food forecast");
        btn_delete.setToolTipText("Delete meal plan from food forecast");
        pnl.add(btn_add);
        pnl.add(btn_delete);
        btn_add.addActionListener((ActionEvent a) -> {
            addMealPlanUsage();
            exectureMealPlanUsageTasks();
        });
        btn_delete.addActionListener((ActionEvent evt) -> {
            deleteMealPlanUsage();
            exectureMealPlanUsageTasks();
        });
        return pnl;
    }

    private JPanel getMealPlanUsageMixesPanel() {
        JPanel pnl = new JPanel();
        pnl.setBorder(new TitledBorder("Mix"));
        FormLayout panelLayout = new FormLayout(
                "p:GROW", // columns
                "FILL:min:GROW" // rows
        );
        pnl.setLayout(panelLayout);
        pnl.add(new JScrollPane(tblMealPlanUsageMixes), cc.xy(1, 1));
        return pnl;
    }

    private JPanel getMealPlanUsageResultPanel() {
        JPanel pnl = new JPanel();
        pnl.setBorder(new TitledBorder("Food Usage"));
        FormLayout panelLayout = new FormLayout(
                "p:GROW", // columns
                "FILL:min:GROW,min" // rows
        );
        pnl.setLayout(panelLayout);
        tblMealPlanUsageResults = new TableMealPlanUsageResults();
        pnl.add(new JScrollPane(tblMealPlanUsageResults), cc.xy(1, 1));
        return pnl;
    }

    private JPanel getNoSolutionPanel() {
        FormLayout lyo = new FormLayout(
                "pref:GROW", // columns
                "FILL:pref:GROW" // rows
        );
        StringBuilder sb = new StringBuilder();
        sb.append(getNoFeasibleSolutionText());
        JPanel pnl = new JPanel();
        JTextArea txa = new JTextArea(sb.toString());
        txa.setPreferredSize(new Dimension(700, 433));
        txa.setEditable(false);
        pnl.setLayout(lyo);
        txa.setLineWrap(false);
        pnl.add(new JScrollPane(txa), cc.xy(1, 1));
        return pnl;
    }

    private JPanel getNutrientConstraintsPanel() {
        JPanel pnl = new JPanel();
        FormLayout panelLayout = new FormLayout(
                "min:GROW,p:GROW,45px,100px,28px,min:GROW", // columns
                "FILL:28px,FILL:145px:GROW,min" // rows
        );
        pnl.setLayout(panelLayout);
        tblNutrientQuantityConstraint = new TableNutrientQuantity();
        JScrollPane scrollPane = new JScrollPane(tblNutrientQuantityConstraint);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JPanel buttons = new JPanel();
        pnl.add(cmbNutrientQuantityNutrient, cc.xy(2, 1));
        pnl.add(cmbNutrientQuantityRelationship, cc.xy(3, 1));
        pnl.add(txtNutrientQuantityValue, cc.xy(4, 1));
        pnl.add(scrollPane, cc.xyw(2, 2, 4));
        buttons.add(btnAddNutrientConstraint);
        buttons.add(btnDeleteNutrientConstraint);
        pnl.add(buttons, cc.xyw(2, 3, 4));
        scrollPane.setBorder(new TitledBorder("Nutrient Constraints"));
        btnAddNutrientConstraint.setToolTipText("Add Constraint");
        btnDeleteNutrientConstraint.setToolTipText("Delete Constraint");
        ((JLabel) cmbNutrientQuantityRelationship.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        btnAddNutrientConstraint.addActionListener((ActionEvent evt) -> {
            addNutrientQuantityConstraint();
        });
        btnDeleteNutrientConstraint.addActionListener((ActionEvent evt) -> {
            if (tblNutrientQuantityConstraint.isSelectionEmpty()) {
                return;
            }
            deleteNutrientQuantityConstraint();
        });
        tblNutrientQuantityConstraint.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            if (tblNutrientQuantityConstraint.isSelectionEmpty()) {
                return;
            }
            setNutrientQuantityConstraintGuiValues();
        });
        return pnl;
    }

    private JPanel getNutrientSearchPanel() {
        JPanel pnl = new JPanel();
        JPanel pnl01 = new JPanel();
        FormLayout lyo = new FormLayout(
                "4dlu:GROW,500dlu,4dlu:GROW", // columns
                "4dlu,min,4dlu,FILL:min:GROW,4dlu" // rows
        );
        FormLayout lyo01 = new FormLayout(
                "4dlu,p,p,4dlu,p,p:GROW,4dlu", // columns
                "4dlu,FILL:28px,4dlu,FILL:28px,4dlu" // rows
        );
        pnl.setLayout(lyo);
        pnl01.setLayout(lyo01);
        JLabel lblSearch = new JLabel("Search: ");
        lblSearch.setToolTipText("Search field input should be a valid regex expression (case insensitive match)");
        JLabel lblNutrient = new JLabel("Nutrient: ");
        lblNutrient.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel lblValue = new JLabel("Nutrient Quantity: ");
        lblValue.setHorizontalAlignment(SwingConstants.RIGHT);
        lblSearch.setHorizontalAlignment(SwingConstants.RIGHT);
        tblNutrientLookup = new TableNutrientLookup();
        tblNutrientLookup.setToolTipText("These food items contain the nutrient");
        JScrollPane scr = new JScrollPane(tblNutrientLookup);
        scr.setBorder(new TitledBorder("Nutrient Search"));
        pnl01.add(lblSearch, cc.xy(5, 2));
        pnl01.add(tblNutrientLookup.getSearchField(), cc.xy(6, 2));
        pnl01.add(lblNutrient, cc.xy(2, 4));
        pnl01.add(cmbNutrientContentNutrient, cc.xy(3, 4));
        pnl01.add(lblValue, cc.xy(5, 4));
        pnl01.add(txtNutrientSearchQuantity, cc.xy(6, 4));
        pnl.add(pnl01, cc.xy(2, 2));
        pnl.add(scr, cc.xy(2, 4));
        txtNutrientSearchQuantity.setToolTipText("Press enter to search for food items");
        txtNutrientSearchQuantity.addActionListener((ActionEvent evt) -> {
            reload_tblmdl_nutrient_lookup();
            setQuantityScale();
        });
        return pnl;
    }

    private JPanel getNutrientRatioConstraintsPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "min:GROW,p:GROW,100px,45px,p:GROW,100px,28px,min:GROW", // columns
                "FILL:28px,FILL:145px:GROW,min" // rows
        );
        pnl.setLayout(lyo);
        tblNutrientRatio = new TableNutrientRatioConstraint();
        JScrollPane scrollPane = new JScrollPane(tblNutrientRatio);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JPanel buttons = new JPanel();
        pnl.add(cmbNutrientRatioNutrientA, cc.xy(2, 1));
        pnl.add(txtNutrientRatioNutrientA, cc.xy(3, 1));
        pnl.add(cmbNutrientRatioRelationship, cc.xy(4, 1));
        pnl.add(cmbNutrientRatioNutrientB, cc.xy(5, 1));
        pnl.add(txtNutrientRatioNutrientB, cc.xy(6, 1));
        pnl.add(scrollPane, cc.xyw(2, 2, 6));
        buttons.add(btnAddNutrientRatio);
        buttons.add(btnDeleteNutrientRatio);
        pnl.add(buttons, cc.xyw(2, 3, 6));
        scrollPane.setBorder(new TitledBorder("Nutrient Ratio Constraints"));
        btnAddNutrientRatio.setToolTipText("Add Constraint");
        btnDeleteNutrientRatio.setToolTipText("Delete Constraint");
        ((JLabel) cmbNutrientRatioRelationship.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        btnAddNutrientRatio.addActionListener((ActionEvent evt) -> {
            addNutrientRatioConstraint();
        });
        btnDeleteNutrientRatio.addActionListener((ActionEvent evt) -> {
            if (tblNutrientRatio.isSelectionEmpty()) {
                return;
            }
            deleteNutrientRatioConstraint();
        });
        tblNutrientRatio.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            if (tblNutrientRatio.isSelectionEmpty()) {
                return;
            }
            setNutrientRatioConstraintGuiValues();
        });
        return pnl;
    }

    private String getFoodConstraintCount() {
        return String.format("%1$ 2d", tblFoodQuantityConstraint.getRowCount());
    }

    private String getFoodRatioConstraintCount() {
        return String.format("%1$ 2d", tblFoodRatioConstraint.getRowCount());
    }

    private String getGroupConstraintCount() {
        return String.format("%1$ 2d", tblGroupQuantityConstraint.getRowCount());
    }

    private String getNoFeasibleSolutionText() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            sb.append("\n");
        }
        for (int i = 0; i < 40; i++) {
            sb.append(" ");
        }
        sb.append("No Feasible Solution");
        sb.append("\n\n");
        for (int i = 0; i < 40; i++) {
            sb.append(" ");
        }
        sb.append("Things you can try:");
        sb.append("\n\n");
        for (int i = 0; i < 40; i++) {
            sb.append(" ");
        }
        sb.append("1. Delete a constraint");
        sb.append("\n\n");
        for (int i = 0; i < 40; i++) {
            sb.append(" ");
        }
        sb.append("2. Add a food item");
        sb.append("\n\n");
        for (int i = 0; i < 40; i++) {
            sb.append(" ");
        }
        sb.append("3. Pin the mix");
        return sb.toString();
    }

    private String getNutrientQuantityConstraintCount() {
        return String.format("%1$ 2d", tblNutrientQuantityConstraint.getRowCount());
    }

    private String getNutrientRatioConstraintCount() {
        return String.format("%1$ 2d", tblNutrientRatio.getRowCount());
    }

    private Boolean checkFoodConstraint() {
        boolean flag_isReady = false;
        boolean flag_mix = false;
        boolean flag_listFood = false;
        boolean flag_listNutrient = false;
        boolean flag_listRelationship = false;
        boolean flag_quantity = false;
        if (!getSelectedMix().getMixid().isEmpty()) {
            flag_mix = true;
        } else {
            Message.showMessage("Create or import mix");
        }
        if (!cmbFoodQuantityFood.isSelectionEmpty()) {
            flag_listFood = true;
        } else {
            Message.showMessage("Select food");
        }
        if (!cmbFoodQuantityNutrient.isSelectionEmpty()) {
            flag_listNutrient = true;
        } else {
            Message.showMessage("Select nutrient");
        }
        if (!cmbFoodQuantityRelationship.isSelectionEmpty()) {
            flag_listRelationship = true;
        } else {
            Message.showMessage("Select relationship");
        }
        if (!txtFoodQuantityValue.getText().isEmpty()) {
            flag_quantity = true;
        } else {
            Message.showMessage("Specify amount");
        }
        if (flag_listFood && flag_listNutrient && flag_listRelationship && flag_quantity) {
            flag_isReady = true;
        }
        return flag_isReady;
    }

    private Boolean checkFoodRatioConstraint() {
        boolean flag_isReady = false;
        boolean flag_mix = false;
        boolean flag_listFoodA = false;
        boolean flag_listNutrientA = false;
        boolean flag_quantityA = false;
        boolean flag_listFoodB = false;
        boolean flag_listNutrientB = false;
        boolean flag_quantityB = false;
        if (!getSelectedMix().getMixid().isEmpty()) {
            flag_mix = true;
        } else {
            Message.showMessage("Create or import mix");
        }
        if (!cmbFoodRatioFoodA.isSelectionEmpty()) {
            flag_listFoodA = true;
        } else {
            Message.showMessage("Select food A");
        }
        if (!cmbFoodRatioNutrientA.isSelectionEmpty()) {
            flag_listNutrientA = true;
        } else {
            Message.showMessage("Select nutrient A");
        }
        if (!txtFoodNutrientRatioQuantityA.getText().isEmpty()) {
            flag_quantityA = true;
        } else {
            Message.showMessage("Specify amount A");
        }
        if (!cmbFoodRatioFoodB.isSelectionEmpty()) {
            flag_listFoodB = true;
        } else {
            Message.showMessage("Select food B");
        }
        if (!cmbFoodRatioNutrientB.isSelectionEmpty()) {
            flag_listNutrientB = true;
        } else {
            Message.showMessage("Select nutrient B");
        }
        if (!txtFoodNutrientRatioQuantityB.getText().isEmpty()) {
            flag_quantityB = true;
        } else {
            Message.showMessage("Specify amount B");
        }
        if (flag_listFoodA
                && flag_listNutrientA
                && flag_quantityA
                && flag_listFoodB
                && flag_listNutrientB
                && flag_quantityB) {
            flag_isReady = true;
        }
        return flag_isReady;
    }

    private Boolean checkNutrientQuantityConstraint() {
        boolean flag_isReady = false;
        boolean flag_mix = false;
        boolean flag_listNutrient = false;
        boolean flag_listNutrientRelationship = false;
        boolean flag_textFieldNutrientConstraint = false;
        if (!getSelectedMix().getMixid().isEmpty()) {
            flag_mix = true;
        } else {
            Message.showMessage("Create or import mix");
        }
        if (!cmbNutrientQuantityNutrient.isSelectionEmpty()) {
            flag_listNutrient = true;
        } else {
            Message.showMessage("Select nutrient");
        }
        if (cmbNutrientQuantityRelationship.getSelectedIndex() != -1) {
            flag_listNutrientRelationship = true;
        } else {
            Message.showMessage("Select relationship");
        }
        if (!txtNutrientQuantityValue.getText().isEmpty()) {
            flag_textFieldNutrientConstraint = true;
        } else {
            Message.showMessage("Specify amount");
        }
        if (flag_listNutrient && flag_listNutrientRelationship && flag_textFieldNutrientConstraint) {
            flag_isReady = true;
        }
        return flag_isReady;
    }

    private Boolean checkNutrientRatioConstraint() {
        boolean flag_isReady = false;
        boolean flag_mix = false;
        boolean flag_listNutrientA = false;
        boolean flag_listNutrientB = false;
        boolean flag_quantityA = false;
        boolean flag_quantityB = false;
        if (!getSelectedMix().getMixid().isEmpty()) {
            flag_mix = true;
        } else {
            Message.showMessage("Create or import mix");
        }
        if (!cmbNutrientRatioNutrientA.isSelectionEmpty()) {
            flag_listNutrientA = true;
        } else {
            Message.showMessage("Select nutrient A");
        }
        if (!cmbNutrientRatioNutrientB.isSelectionEmpty()) {
            flag_listNutrientB = true;
        } else {
            Message.showMessage("Select nutrient B");
        }
        if (!txtNutrientRatioNutrientA.getText().isEmpty()) {
            flag_quantityA = true;
        } else {
            Message.showMessage("Specify amount A");
        }
        if (!txtNutrientRatioNutrientB.getText().isEmpty()) {
            flag_quantityB = true;
        } else {
            Message.showMessage("Specify amount B");
        }
        if (flag_listNutrientA && flag_listNutrientB && flag_quantityA && flag_quantityB) {
            flag_isReady = true;
        }
        return flag_isReady;
    }

    private void convertMixToFood() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        TableFoodFactInput tbl = new TableFoodFactInput();
        try {
            Future<List<List>> task = TaskLauncher.submit(new MixFoodFactsTask(getSelectedMix().getMixid()));
            List<List> foodfacts = task.get();
            tbl.reload(foodfacts);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        FoodFactInputPanel pnlFoodFactsInput = new FoodFactInputPanel(tbl);
        pnlFoodFactsInput.setFoodName(getSelectedMix().getName());
        JPanel pnl = pnlFoodFactsInput.getPanel();
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(
                inputs, "Add Mix As Food Item - Would you like to save specified values?");
        if (optionValue == 0) {
            Food food = pnlFoodFactsInput.getFood();
            Boolean completed = new FoodCreator(food).create();
            if (completed) {
                try {
                    Future<List<List>> task = TaskLauncher.submit(new FoodFactsTask());
                    List<List> foods = task.get();
                    reloadFoodFacts(foods, foods);
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                reloadFoods();
                try {
                    Future<List<List>> task = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(getSelectedMix().getMixid()));
                    List<List> foods = task.get();
                    tblMixFood.reload(foods);
                    tblSelectedFoods.reload(foods);
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                setQuantityScale();
                int rowIndex = tblFoodFacts.find(food.getFoodId());
                tblFoodFacts.showRow(rowIndex);
            }
        }
    }

    private void addCategory() {
        JTextField txtInput = new JTextField();
        JComponent[] inputs = {new JLabel("What is your new category name?"), txtInput};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "New Category");
        if (optionValue == 0) {
            String categoryname = txtInput.getText();
            if (categoryname != null && categoryname.length() > 0) {
                try {
                    Future<String> task00 = TaskLauncher.submit(new InsertCategoryTask(categoryname));
                    String id = task00.get();
                    if (task00.isDone()) {
                        Future<List<TableCategoryRow>> task02 = TaskLauncher.submit(new FoodCategoriesTaskUsingRecords());
                        List<TableCategoryRow> categories = task02.get();
                        tblAllFoodCategories.reload(categories);
                        int rowIndex = tblAllFoodCategories.find(id);
                        tblAllFoodCategories.selectRow(rowIndex);
                        tblAllFoodCategories.showRow(rowIndex);
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            }
        }
    }

    private void duplicateCategory() {
        if (!tblAllFoodCategories.isSelectionEmpty()) {
            TableCategoryRow category = tblAllFoodCategories.getSelectedValue();
            try {
                Future<String> task00 = TaskLauncher.submit(new DuplicateCategoryTask(category.categoryId()));
                String id = task00.get();
                if (task00.isDone()) {
                    Future<List<TableCategoryRow>> task02 = TaskLauncher.submit(new FoodCategoriesTaskUsingRecords());
                    List<TableCategoryRow> categories = task02.get();
                    tblAllFoodCategories.reload(categories);
                    int rowIndex = tblAllFoodCategories.find(id);
                    tblAllFoodCategories.selectRow(rowIndex);
                    tblAllFoodCategories.showRow(rowIndex);
                }
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void deleteCategory() {
        if (!tblAllFoodCategories.isSelectionEmpty()) {
            TableCategoryRow category = tblAllFoodCategories.getSelectedValue();
            try {
                Future<Boolean> task = TaskLauncher.submit(new DeleteCategoryTask(category.categoryId()));
                Boolean completed = task.get();
                if (!completed) {
                    return;
                }
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            try {
                Future<List<Map<String, Object>>> task = TaskLauncher.submit(new FoodsAndCategoriesTask());
                List<Map<String, Object>> treeFoods = task.get();
                treeModel.reload(treeFoods);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            try {
                Future<List<TableCategoryRow>> task = TaskLauncher.submit(new FoodCategoriesTaskUsingRecords());
                List<TableCategoryRow> categories = task.get();
                tblAllFoodCategories.reload(categories);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            tblFoodsInCategory.clear();
        }
    }

    private void renameCategory() {
        if (!tblAllFoodCategories.isSelectionEmpty()) {
            JTextField input = new JTextField();
            JComponent[] inputs = {new JLabel("What is your new category name?"), input};
            int optionValue = Message.showOptionDialogOkCancel(inputs, "Update Category");
            if (optionValue == 0) {
                String categoryname = input.getText();
                if (categoryname != null && categoryname.length() > 0) {
                    TableCategoryRow category = tblAllFoodCategories.getSelectedValue();
                    try {
                        Future<Boolean> task
                                = TaskLauncher.submit(new UpdateCategoryTask(category.categoryId(), categoryname));
                        Boolean completed = task.get();
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                    try {
                        Future<List<TableCategoryRow>> task = TaskLauncher.submit(new FoodCategoriesTaskUsingRecords());
                        List<TableCategoryRow> categories = task.get();
                        tblAllFoodCategories.reload(categories);
                        int rowIndex = tblAllFoodCategories.find(category.categoryId());
                        tblAllFoodCategories.selectRow(rowIndex);
                        tblAllFoodCategories.showRow(rowIndex);
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                    try {
                        Future<List<Map<String, Object>>> task = TaskLauncher.submit(new FoodsAndCategoriesTask());
                        List<Map<String, Object>> treeFoods = task.get();
                        treeModel.reload(treeFoods);
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            }
        }
    }

    public void exportCategory() {
        if (tblAllFoodCategories.isSelectionEmpty()) {
            return;
        }
        int returnVal = fch_Foods.showSaveDialog(frm);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            File file = fch_Foods.getSelectedFile();
            fch_Foods.setCurrentDirectory(file);
            String path = file.getAbsolutePath();
            BufferedWriter writer = null;
            try {
                TableCategoryRow selectedValue = tblAllFoodCategories.getSelectedValue();
                BufferedWriter touch = new BufferedWriter(new FileWriter(path));
                touch.write("<foods xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
                touch.write("\n");
                touch.close();
                writer = new BufferedWriter(new FileWriter(path, true));
                Future<List<FoodListRecord>> getFoodList = TaskLauncher.submit(new GetFoodListForCategoryTask(selectedValue.categoryId()));
                List<FoodListRecord> list = getFoodList.get();
                for (FoodListRecord record : list) {
                    Future<String> getXml = TaskLauncher.submit(new GetFoodXmlFixedCategoryTask(record.foodId(), selectedValue.categoryId()));
                    String xml = getXml.get();
                    String fdoc = U.formatXmlDoc(xml);
                    writer.write(fdoc);
                }
                writer.write("</foods>");
                writer.write("\n");
                writer.close();
                frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                StringBuilder sb = new StringBuilder();
                sb.append("Document saved to ");
                sb.append(path);
                Message.showMessage(sb.toString());
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    public void exportAllCategories() {
        int returnVal = fch_Foods.showSaveDialog(frm);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            File file = fch_Foods.getSelectedFile();
            fch_Foods.setCurrentDirectory(file);
            String path = file.getAbsolutePath();
            BufferedWriter writer = null;
            try {
                BufferedWriter touch = new BufferedWriter(new FileWriter(path));
                touch.write("<foods xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
                touch.write("\n");
                touch.close();
                writer = new BufferedWriter(new FileWriter(path, true));
                Future<List<FoodListRecord>> getFoodList = TaskLauncher.submit(new GetFoodListTask());
                List<FoodListRecord> list = getFoodList.get();
                for (FoodListRecord record : list) {
                    Future<String> getXml = TaskLauncher.submit(new GetFoodXmlTask(record.foodId()));
                    String xml = getXml.get();
                    String fdoc = U.formatXmlDoc(xml);
                    writer.write(fdoc);
                }
                writer.write("</foods>");
                writer.write("\n");
                writer.close();
                frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                StringBuilder sb = new StringBuilder();
                sb.append("Document saved to ");
                sb.append(path);
                Message.showMessage(sb.toString());
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void addFoodToCategory() {
        if (!tblAllFoodCategories.isSelectionEmpty()) {
            if (!tblAllFoods.isSelectionEmpty()) {
                TableCategoryRow category = tblAllFoodCategories.getSelectedValue();
                TableFood.Row food = tblAllFoods.getSelectedValue();
                try {
                    Future<Integer> task0 = TaskLauncher.submit(
                            new FoodCategoryCountTask(category.categoryId(), food.getFoodid()));
                    Integer count = task0.get();
                    if (count == 0) {
                        Future<Boolean> task1 = TaskLauncher.submit(
                                new InsertFoodCategoryLinkTask(category.categoryId(), food.getFoodid()));
                        Boolean task1Completed = task1.get();
                        if (!task1Completed) {
                            return;
                        }
                        executeFoodsInCategoryTasks(category);
                        int rowIndex = tblFoodsInCategory.find(food.getFoodid());
                        tblFoodsInCategory.selectRow(rowIndex);
                        tblFoodsInCategory.showRow(rowIndex);
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            }
        }
    }

    private void executeFoodsInCategoryTasks(TableCategoryRow category) {
        try {
            Future<List<List>> task3 = TaskLauncher.submit(new FoodsInCategoryTask((category.categoryId())));
            List<List> categoryFoods = task3.get();
            tblFoodsInCategory.reload(categoryFoods);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        try {
            Future<List<Map<String, Object>>> task = TaskLauncher.submit(new FoodsAndCategoriesTask());
            List<Map<String, Object>> treeFoods = task.get();
            treeModel.reload(treeFoods);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void removeFoodFromCategory() {
        if (!tblAllFoodCategories.isSelectionEmpty()) {
            TableCategoryRow category = tblAllFoodCategories.getSelectedValue();
            TableFood.Row food = tblFoodsInCategory.getSelectedValue();
            try {
                Future<Boolean> task0
                        = TaskLauncher.submit(new DeleteCategoryLinkTask(category.categoryId(), food.getFoodid()));
                Boolean complete = task0.get();
                if (!complete) {
                    return;
                }
                executeFoodsInCategoryTasks(category);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void addFoodToDatabase() {
        TableFoodFactInput tbl = new TableFoodFactInput();
        try {
            Future<List<List>> task = TaskLauncher.submit(new NewItemFoodFactsTask());
            List<List> foodfacts = task.get();
            tbl.reload(foodfacts);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        FoodFactInputPanel pnlFoodFactsInput = new FoodFactInputPanel(tbl);
        JPanel pnl = pnlFoodFactsInput.getPanel();
        JComponent[] inputs = {pnl};
        showCreateNewFoodItemDialog(inputs, pnlFoodFactsInput);
    }

    private void showCreateNewFoodItemDialog(JComponent[] inputs, FoodFactInputPanel pnlFoodFactsInput) {
        int firstCheck = Message.showOptionDialogOkCancel(inputs, "Create a new food item");
        switch (firstCheck) {
            case 0 -> {
                JLabel label = new JLabel();
                label.setText("Are you sure?");
                label.setHorizontalAlignment(SwingConstants.CENTER);
                int secondCheck = Message.showOptionDialogYesNo(new JComponent[]{label}, "Create a new food item");
                switch (secondCheck) {
                    case 0 -> {
                        Food food = pnlFoodFactsInput.getFood();
                        Boolean completed = new FoodCreator(food).create();
                        if (completed) {
                            reloadFoods();
                            try {
                                Future<List<List>> task = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(getSelectedMix().getMixid()));
                                List<List> foods = task.get();
                                tblMixFood.reload(foods);
                                tblSelectedFoods.reload(foods);
                            } catch (Exception e) {
                                LoggerImpl.INSTANCE.logProblem(e);
                            }
                            setQuantityScale();
                            int rowIndex = tblFoodFacts.find(food.getFoodId());
                            tblFoodFacts.showRow(rowIndex);
                            tblFoodFacts.selectRow(rowIndex);
                        }
                    }
                    case 1 -> {
                        showCreateNewFoodItemDialog(inputs, pnlFoodFactsInput);
                    }

                }
            }
            case 1 -> {
                //
            }
            case 2 -> {
                //
            }
        }
    }

    private void addDerivedFoodToDatabase() {
        if (!tblFoodFacts.isSelectionEmpty()) {
            TableFoodFacts.Row foodfact = tblFoodFacts.getSelectedValue();
            TableFoodFactInput tbl = new TableFoodFactInput();
            try {
                Future<List<List>> task = TaskLauncher.submit(new DerivedFoodFactsTask(foodfact.getId_food_id()));
                List<List> foodfacts = task.get();
                tbl.reload(foodfacts);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            FoodFactInputPanel foodFactsInputPanel = new FoodFactInputPanel(tbl);
            foodFactsInputPanel.setFoodName(foodfact.getId_food_name());
            JPanel panel = foodFactsInputPanel.getPanel();
            JComponent[] inputs = {panel};
            showDeriveNewFoodItemDialog(inputs, foodFactsInputPanel);
        }
    }

    private void showDeriveNewFoodItemDialog(JComponent[] inputs, FoodFactInputPanel pnlFoodFactsInput) {
        int firstCheck = Message.showOptionDialogOkCancel(inputs, "Derive a new food item");
        switch (firstCheck) {
            case 0 -> {
                JLabel label = new JLabel();
                label.setText("Are you sure?");
                label.setHorizontalAlignment(SwingConstants.CENTER);
                int secondCheck = Message.showOptionDialogYesNo(new JComponent[]{label}, "Derive a new food item");
                switch (secondCheck) {
                    case 0 -> {
                        Food food = pnlFoodFactsInput.getFood();
                        Boolean completed = new FoodCreator(food).create();
                        if (completed) {
                            reloadFoods();
                            setQuantityScale();
                            int rowIndex = tblFoodFacts.find(food.getCheckSum());
                            tblFoodFacts.showRow(rowIndex);
                            tblFoodFacts.selectRow(rowIndex);
                        }
                    }
                    case 1 -> {
                        showDeriveNewFoodItemDialog(inputs, pnlFoodFactsInput);
                    }

                }
            }
            case 1 -> {
                //
            }
            case 2 -> {
                //
            }
        }
    }

    private void removeFoodFromDatabase() {
        if (!tblFoodFacts.isSelectionEmpty()) {
            TableFoodFacts.Row food = tblFoodFacts.getSelectedValue();
            deleteFoodItem(food.getId_food_id());
            reloadFoodComboBoxes(getSelectedMix().getMixid());
            reloadMixConstraints(getSelectedMix().getMixid());
            mixFoodLoader.reload(getSelectedMix().getMixid());
            cmbPortionFood.reload(mixFoodLoader.get());
            setConstraintCounts();
        }
    }

    private void renameFood() {
        if (!tblFoodFacts.isSelectionEmpty()) {
            TableFoodFacts.Row food = tblFoodFacts.getSelectedValue();
            String foodid = food.getId_food_id();
            JTextField input = new JTextField();
            JPanel input_panel = new JPanel();
            input.setPreferredSize(new Dimension(600, 25));
            input_panel.add(new JLabel("What is the food item name?"));
            input_panel.add(input);
            JComponent[] inputs = {input_panel};
            input.setText(food.getId_food_name());
            int optionValue = Message.showOptionDialogOkCancel(inputs, "Rename Food Item");
            if (optionValue == 0) {
                food.setId_food_name(input.getText());
                try {
                    Future<Boolean> task
                            = TaskLauncher.submit(new UpdateFoodTask(food.getId_food_id(), food.getId_food_name()));
                    Boolean completed = task.get();
                    if (!completed) {
                        return;
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                try {
                    Future<Boolean> task = TaskLauncher.submit(new DenormalizeFoodFactsTask(food.getId_food_id()));
                    Boolean completed = task.get();
                    if (!completed) {
                        return;
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                reloadFoods();
                String mixid = getSelectedMix().getMixid();
                reloadFoodComboBoxes(mixid);
                reloadMixResults(getSelectedMix());
                try {
                    Future<List<List>> task1 = TaskLauncher.submit(new FoodConstraintsTask(mixid));
                    List<List> constraints = task1.get();
                    tblFoodQuantityConstraint.reload(constraints);
                    Future<List<List>> task2 = TaskLauncher.submit(new FoodRatioConstraintsTask(mixid));
                    List<List> constraints2 = task2.get();
                    tblFoodRatioConstraint.reload(constraints2);
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                try {
                    Future<List<List>> task = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(getSelectedMix().getMixid()));
                    List<List> foods = task.get();
                    tblMixFood.reload(foods);
                    tblSelectedFoods.reload(foods);
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                setQuantityScale();
                int rowIndex = tblFoodFacts.find(foodid);
                tblFoodFacts.showRow(rowIndex);
            }
        }
    }

    private void addFoodQuantityConstraint() {
        if (checkFoodConstraint()) {
            NumberCheck numberCheck = new NumberCheck();
            numberCheck.addToUncheckedList(txtFoodQuantityValue.getText());
            if (numberCheck.pass()) {
                MixFoodDO foodDO = cmbFoodQuantityFood.getSelectedItem();
                NutrientDO nutrientDO = cmbFoodQuantityNutrient.getSelectedItem();
                RelationshipDO relationshipDO = cmbFoodQuantityRelationship.getSelectedItem();
                BigDecimal b = new BigDecimal(txtFoodQuantityValue.getText());
                executeMergeFoodQuantityConstraintTasks(getSelectedMix(), foodDO, nutrientDO, relationshipDO, b);
            } else {
                Message.showMessage("Value must be a number greater than or equal to zero");
            }
        }
    }

    private void executeMergeFoodQuantityConstraintTasks(
            MixDO mix, MixFoodDO foodDO, NutrientDO nutrientDO, RelationshipDO relationshipDO, BigDecimal b) {
        try {
            Future<Boolean> task0 = TaskLauncher.submit(new MergeFoodConstraintTask(
                    mix.getMixid(),
                    foodDO.getFoodId(),
                    nutrientDO.getNutr_no(),
                    relationshipDO.getRelationshipid(),
                    b));
            Boolean completed = task0.get();
            if (!completed) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(foodDO.getFoodName());
            sb.append(" using ");
            sb.append(nutrientDO.getNutrdesc());
            sb.append(" ");
            sb.append(relationshipDO.getName());
            sb.append(" ");
            sb.append((new DecimalFormat("######0.0#################")).format(b));
            addLogEntry(
                    getSelectedMix().getName(),
                    "Add",
                    "Food Quantity Constraint",
                    sb.toString(),
                    getSelectedMix().getMixid(),
                    foodDO.getFoodId(),
                    nutrientDO.getNutr_no(),
                    "",
                    "",
                    relationshipDO.getRelationshipid(),
                    b,
                    null);
            Future<List<List>> task1 = TaskLauncher.submit(new FoodConstraintsTask(mix.getMixid()));
            List<List> constraints = task1.get();
            tblFoodQuantityConstraint.reload(constraints);
            setConstraintCounts();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void deleteFoodQuantityConstraint() {
        if (!tblFoodQuantityConstraint.isSelectionEmpty()) {
            TableFoodQuantityConstraint.Row row = tblFoodQuantityConstraint.getSelectedValue();
            String mixid = row.getMixid();
            String foodid = row.getFoodid();
            String nutrientid = row.getNutrientid();
            Integer relationshipid = row.getRelationshipid();
            try {
                Future<Boolean> task0 = TaskLauncher.submit(new DeleteFoodConstraintTask(mixid, foodid, nutrientid, relationshipid));
                Boolean completed = task0.get();
                if (!completed) {
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(row.getFood());
                sb.append(" using ");
                sb.append(row.getNutrient());
                sb.append(" ");
                sb.append(row.getRelationship());
                sb.append(" ");
                sb.append((new DecimalFormat("######0.0#################")).format(row.getB()));
                addLogEntry(
                        getSelectedMix().getName(),
                        "Delete",
                        "Food Quantity Constraint",
                        sb.toString(),
                        getSelectedMix().getMixid(),
                        row.getFoodid(),
                        row.getNutrientid(),
                        "",
                        "",
                        row.getRelationshipid(),
                        row.getB(),
                        null);
                Future<List<List>> task1 = TaskLauncher.submit(new FoodConstraintsTask(mixid));
                List<List> constraints = task1.get();
                tblFoodQuantityConstraint.reload(constraints);
                setConstraintCounts();
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void blockFood() {
        MixFoodDO foodDO = cmbFoodQuantityFood.getSelectedItem();
        NutrientDO nutrientDO = new NutrientDO("10000", "Other, Weight (g)", new BigDecimal("-1"));
        RelationshipDO relationshipDO = new RelationshipDO(3, "=");
        BigDecimal b = new BigDecimal("0.0");
        executeMergeFoodQuantityConstraintTasks(getSelectedMix(), foodDO, nutrientDO, relationshipDO, b);
    }

    private void blockGroup() {
        GroupDO groupDO = cmbFoodGroup.getSelectedItem();
        NutrientDO nutrientDO = new NutrientDO("10000", "Other, Weight (g)", new BigDecimal("-1"));
        RelationshipDO relationshipDO = new RelationshipDO(3, "=");
        BigDecimal b = new BigDecimal("0.0");
        executeMergeGroupQuantityConstraintTasks(getSelectedMix(), groupDO, nutrientDO, relationshipDO, b);
    }

    private void addFoodRatioConstraint() {
        if (checkFoodRatioConstraint()) {
            NumberCheck numberCheck = new NumberCheck();
            numberCheck.addToUncheckedList(txtFoodNutrientRatioQuantityA.getText());
            numberCheck.addToUncheckedList(txtFoodNutrientRatioQuantityB.getText());
            if (numberCheck.pass()) {
                MixFoodDO foodDOA = cmbFoodRatioFoodA.getSelectedItem();
                NutrientDO nutrientDOA = cmbFoodRatioNutrientA.getSelectedItem();
                MixFoodDO foodDOB = cmbFoodRatioFoodB.getSelectedItem();
                NutrientDO nutrientDOB = cmbFoodRatioNutrientB.getSelectedItem();
                BigDecimal a = new BigDecimal(txtFoodNutrientRatioQuantityA.getText());
                BigDecimal b = new BigDecimal(txtFoodNutrientRatioQuantityB.getText());
                RelationshipDO relationshipDO = (RelationshipDO) cmbFoodRatioRelationship.getSelectedItem();
                try {
                    Future<Boolean> task0 = TaskLauncher.submit(new MergeFoodRatioConstraintTask(
                            getSelectedMix().getMixid(),
                            foodDOA.getFoodId(),
                            nutrientDOA.getNutr_no(),
                            foodDOB.getFoodId(),
                            nutrientDOB.getNutr_no(),
                            relationshipDO.getRelationshipid(),
                            a,
                            b));
                    Boolean completed = task0.get();
                    if (!completed) {
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(foodDOA.getFoodName());
                    sb.append(" using ");
                    sb.append(nutrientDOA.getNutrdesc());
                    sb.append(" / ");
                    sb.append(foodDOB.getFoodName());
                    sb.append(" using ");
                    sb.append(nutrientDOB.getNutrdesc());
                    sb.append(" ");
                    sb.append(relationshipDO.getName());
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(a));
                    sb.append(" / ");
                    sb.append((new DecimalFormat("######0.0#################")).format(b));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Add",
                            "Nutrient Ratio Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            foodDOA.getFoodId(),
                            nutrientDOA.getNutr_no(),
                            foodDOB.getFoodId(),
                            nutrientDOB.getNutr_no(),
                            relationshipDO.getRelationshipid(),
                            a,
                            b);
                    Future<List<List>> task1 = TaskLauncher.submit(new FoodRatioConstraintsTask(getSelectedMix().getMixid()));
                    List<List> constraints = task1.get();
                    tblFoodRatioConstraint.reload(constraints);
                    setConstraintCounts();
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            } else {
                Message.showMessage("Value must be number greater than zero");
            }
        }
    }

    private void deleteFoodRatioConstraint() {
        if (!tblFoodRatioConstraint.isSelectionEmpty()) {
            TableFoodRatioConstraint.Row row = tblFoodRatioConstraint.getSelectedValue();
            String mixid = row.getMixid();
            String foodidA = row.getFoodida();
            String nutrientidA = row.getNutrientida();
            String foodidB = row.getFoodidb();
            String nutrientidB = row.getNutrientidb();
            Integer relationshipid = row.getRelationshipid();
            try {
                Future<Boolean> task0 = TaskLauncher.submit(new DeleteFoodRatioConstraintTask(
                        mixid, foodidA, nutrientidA, foodidB, nutrientidB, relationshipid));
                Boolean completed = task0.get();
                if (!completed) {
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(row.getFooda());
                sb.append(" using ");
                sb.append(row.getNutrienta());
                sb.append(" / ");
                sb.append(row.getFoodb());
                sb.append(" using ");
                sb.append(row.getNutrientb());
                sb.append(" ");
                sb.append(row.getRelationship());
                sb.append(" ");
                sb.append((new DecimalFormat("######0.0#################")).format(row.getA()));
                sb.append(" / ");
                sb.append((new DecimalFormat("######0.0#################")).format(row.getB()));
                addLogEntry(
                        getSelectedMix().getName(),
                        "Delete",
                        "Food Ratio Constraint",
                        sb.toString(),
                        getSelectedMix().getMixid(),
                        row.getFoodida(),
                        row.getNutrientida(),
                        row.getFoodidb(),
                        row.getNutrientidb(),
                        row.getRelationshipid(),
                        row.getA(),
                        row.getB());
                Future<List<List>> task1 = TaskLauncher.submit(new FoodRatioConstraintsTask(mixid));
                List<List> constraints = task1.get();
                tblFoodRatioConstraint.reload(constraints);
                setConstraintCounts();
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void addFoodPortion() {
        NumberCheck checkNumber = new NumberCheck();
        Double pcti = Double.NaN;
        checkNumber.addToUncheckedList(txtPortionPct.getText());
        if (checkNumber.pass()) {
            String mixid = getSelectedMix().getMixid();
            String foodid = cmbPortionFood.getSelectedItem().getFoodId();
            List<TablePortionMeals.Row> rows = tblMeals.getSelectedValues();
            double pct = Double.parseDouble(txtPortionPct.getText());
            int n = rows.size();
            pcti = pct / n;
            for (Row row : rows) {
                try {
                    Future<Boolean> task0 = TaskLauncher.submit(
                            new InsertAndCalculateFoodPortionTask(mixid, row.getMealid(), foodid, pcti));
                    Boolean complete = task0.get();
                    if (complete) {
                        reloadMealResults(getSelectedMix());
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            }
        } else {
            Message.showMessage("Add One Or More Food Portions", "Please specify a portion percentage and select one or more meals.");
        }
    }

    private void deleteFoodPortion() {
        if (!tblMealPortions.isSelectionEmpty()) {
            try {
                List<TablePortion.Row> rows = tblMealPortions.getSelectedValues();
                for (TablePortion.Row row : rows) {
                    try {
                        Future<Boolean> task0 = TaskLauncher.submit(
                                new DeleteFoodPortionTask(row.getMixid(), row.getMealid(), row.getFoodid()));
                        Boolean complete = task0.get();
                        if (complete) {
                            reloadMealResults(new MixDO(row.getMixid()));
                        }
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        } else {
            Message.showMessage("Delete One Or More Food Portions", "Please select one or more food portions.");
        }
    }

    private void updateFoodPortionWeight() {
        JTextField txtInput = new JTextField();
        txtInput.setPreferredSize(new Dimension(50, 25));
        if (!tblMealPortions.isSelectionEmpty()) {
            TablePortion.Row row = tblMealPortions.getSelectedValue();
            BigDecimal actualwt = row.getActual();
            txtInput.setText(actualwt.toPlainString());
            JPanel pnlInput = new JPanel();
            pnlInput.add(new JLabel("Actual Weight: "));
            pnlInput.add(txtInput);
            JComponent[] inputs = {pnlInput};
            int optionValue = Message.showOptionDialogOkCancel(inputs, "Update Actual Weight");
            if (optionValue == 0) {
                try {
                    String mixid = row.getMixid();
                    Integer mealid = row.getMealid();
                    String foodid = row.getFoodid();
                    Future<Boolean> task0 = TaskLauncher.submit(new UpdateFoodPortionActualWeightTask(
                            mixid, mealid, foodid, new BigDecimal(txtInput.getText())));
                    Boolean complete = task0.get();
                    if (complete) {
                        reloadMealResults(new MixDO(mixid));
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            }
        }
    }

    private void addMeal() {
        JTextField txtMealName = new JTextField();
        JTextField txtMealOrder = new JTextField();
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "28dlu,34dlu,100dlu", // columns
                "FILL:28px,4dlu,FILL:28px" // rows
        );
        pnl.setLayout(lyo);
        JLabel lblMealName = new JLabel("Name: ");
        lblMealName.setHorizontalAlignment(SwingConstants.RIGHT);
        pnl.add(lblMealName, cc.xy(1, 1));
        pnl.add(txtMealName, cc.xyw(2, 1, 2));
        JLabel lblMealOrder = new JLabel("Order: ");
        lblMealOrder.setHorizontalAlignment(SwingConstants.RIGHT);
        pnl.add(lblMealOrder, cc.xy(1, 3));
        pnl.add(txtMealOrder, cc.xy(2, 3));
        JComponent[] inputs = {pnl};
        if (!getSelectedMix().getMixid().isEmpty()) {
            int optionValue = Message.showOptionDialogOkCancel(inputs, "Add Meal");
            if (optionValue == 0) {
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(txtMealOrder.getText());
                if (checkNumber.pass()) {
                    String mealname = txtMealName.getText();
                    Integer mealorder = Integer.valueOf(txtMealOrder.getText());
                    try {
                        Future<Integer> task
                                = TaskLauncher.submit(new CreateMealTask(getSelectedMix().getMixid(), mealname, mealorder));
                        Integer mealid = task.get();
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                    try {
                        Future<List<List>> task = TaskLauncher.submit(new MealPlanMealsTask(getSelectedMix().getMixid()));
                        List<List> meals = task.get();
                        tblMeals.reload(meals);
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            }
        } else {
            Message.showMessage("Create or import mix");
        }
    }

    private void deleteMeal() {
        if (!tblMeals.isSelectionEmpty()) {
            Row meal = tblMeals.getSelectedValue();
            try {
                Future<Boolean> task = TaskLauncher.submit(new DeleteMealTask(meal.getMixid(), meal.getMealid()));
                Boolean completed = task.get();
                if (!completed) {
                    return;
                }
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            try {
                Future<List<List>> task = TaskLauncher.submit(new MealPlanMealsTask(getSelectedMix().getMixid()));
                List<List> meals = task.get();
                tblMeals.reload(meals);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            reloadMealResults(getSelectedMix());
        }
    }

    private void updateMeal() {
        JTextField txtMealName = new JTextField();
        JTextField txtMealOrder = new JTextField();
        if (!tblMeals.isSelectionEmpty()) {
            Row row = tblMeals.getSelectedValue();
            // String mixid = row.getMixid();
            Integer mealid = row.getMealid();
            String mealname = row.getMealname();
            Integer mealorder = row.getMealorder();
            txtMealName.setText(mealname);
            txtMealOrder.setText(String.valueOf(mealorder));
            JPanel pnl = new JPanel();
            FormLayout lyo = new FormLayout(
                    "28dlu,34dlu,100dlu", // columns
                    "FILL:28px,4dlu,FILL:28px" // rows
            );
            pnl.setLayout(lyo);
            JLabel lblMealName = new JLabel("Name: ");
            lblMealName.setHorizontalAlignment(SwingConstants.RIGHT);
            pnl.add(lblMealName, cc.xy(1, 1));
            pnl.add(txtMealName, cc.xyw(2, 1, 2));
            JLabel lblMealOrder = new JLabel("Order: ");
            lblMealOrder.setHorizontalAlignment(SwingConstants.RIGHT);
            pnl.add(lblMealOrder, cc.xy(1, 3));
            pnl.add(txtMealOrder, cc.xy(2, 3));
            JComponent[] inputs = {pnl};
            int optionValue = Message.showOptionDialogOkCancel(inputs, "Update Meal");
            if (optionValue == 0) {
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(txtMealOrder.getText());
                if (checkNumber.pass()) {
                    mealname = txtMealName.getText();
                    mealorder = Integer.valueOf(txtMealOrder.getText());
                    try {
                        Future<Boolean> task
                                = TaskLauncher.submit(new UpdateMealTask(getSelectedMix().getMixid(), mealid, mealname, mealorder));
                        Boolean completed = task.get();
                        if (!completed) {
                            return;
                        }
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                    try {
                        Future<List<List>> task = TaskLauncher.submit(new MealPlanMealsTask(getSelectedMix().getMixid()));
                        List<List> meals = task.get();
                        tblMeals.reload(meals);
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                    reloadMealResults(getSelectedMix());
                }
            }
        }
    }

    private void addMixFood() {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
        if (node == null) {
            return;
        }
        if (node.isLeaf()) {
            try {
                MixFoodDO food = (MixFoodDO) node.getUserObject();
                String foodId = food.getFoodId();
                String foodName = food.getFoodName();
                Future<Boolean> task0 = TaskLauncher.submit(new InsertMixFoodTask(getSelectedMix().getMixid(), foodId));
                Boolean completed = task0.get();
                if (!completed) {
                    return;
                }
                addLogEntry(
                        getSelectedMix().getName(), "Add", "Food", foodName, getSelectedMix().getMixid(), foodId, "", "", "", null, null, null);
                try {
                    Future<List<List>> task1 = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(getSelectedMix().getMixid()));
                    List<List> foods = task1.get();
                    tblMixFood.reload(foods);
                    tblSelectedFoods.reload(foods);
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                reloadFoodComboBoxes(getSelectedMix().getMixid());
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void collapseFoods() {
        int rowCount = tree.getRowCount();
        for (int i = 1; i < rowCount; i++) {
            tree.collapseRow(i);
        }
    }

    private void deleteMixFood() {
        TableFood.Row food = tblMixFood.getSelectedValue();
        if (food.isNull()) {
            return;
        }
        String selectedFoodId = food.getFoodid();
        String selectedFoodName = food.getFoodname();
        try {
            Future<Boolean> task = TaskLauncher.submit(new DeleteMixFoodTask(getSelectedMix().getMixid(), selectedFoodId));
            Boolean completed = task.get();
            if (!completed) {
                return;
            }
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        addLogEntry(
                getSelectedMix().getName(),
                "Delete",
                "Food",
                selectedFoodName,
                getSelectedMix().getMixid(),
                selectedFoodId,
                "",
                "",
                "",
                null,
                null,
                null);
        try {
            Future<List<List>> task = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(getSelectedMix().getMixid()));
            List<List> foods = task.get();
            tblMixFood.reload(foods);
            tblSelectedFoods.reload(foods);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        reloadFoodComboBoxes(getSelectedMix().getMixid());
        reloadMixConstraints(getSelectedMix().getMixid());
        try {
            Future<List<List>> task = TaskLauncher.submit(new MixResultsTask(getSelectedMix().getMixid()));
            List<List> results = task.get();
            if (results.isEmpty()) {
                return;
            }
            tblMixResults.reload(results);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        reloadMealResults(getSelectedMix());
        LifeStageDO lifestage = (LifeStageDO) cmbLifestage.getSelectedItem();
        try {
            Future<List<List>> task = TaskLauncher.submit(new DriDiffTask(getSelectedMix().getMixid(), lifestage.getLifeStageId()));
            List<List> diff = task.get();
            tblDri.reload(diff);
            setQuantityScale();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void expandFoods() {
        int rowCount = tree.getRowCount();
        expandTree(tree, 0, rowCount);
    }

    private void addNutrientQuantityConstraint() {
        if (checkNutrientQuantityConstraint()) {
            NumberCheck numberCheck = new NumberCheck();
            numberCheck.addToUncheckedList(txtNutrientQuantityValue.getText());
            if (numberCheck.pass()) {
                NutrientDO nutrientDO = cmbNutrientQuantityNutrient.getSelectedItem();
                RelationshipDO relationshipDO = (RelationshipDO) cmbNutrientQuantityRelationship.getSelectedItem();
                BigDecimal b = new BigDecimal(txtNutrientQuantityValue.getText());
                try {
                    Future<Boolean> task0 = TaskLauncher.submit(new MergeNutrientConstraintTask(
                            getSelectedMix().getMixid(), nutrientDO.getNutr_no(), relationshipDO.getRelationshipid(), b));
                    Boolean completed = task0.get();
                    if (!completed) {
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(nutrientDO.getNutrdesc());
                    sb.append(" ");
                    sb.append(relationshipDO.getName());
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(b));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Add",
                            "Nutrient Quantity Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            "",
                            nutrientDO.getNutr_no(),
                            "",
                            "",
                            relationshipDO.getRelationshipid(),
                            b,
                            null);
                    Future<List<List>> task1
                            = TaskLauncher.submit(new NutrientConstraintsTask(getSelectedMix().getMixid()));
                    List<List> constraints = task1.get();
                    tblNutrientQuantityConstraint.reload(constraints);
                    setConstraintCounts();
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            } else {
                Message.showMessage("Value must be a number greater than or equal to zero");
            }
        }
    }

    private void deleteNutrientQuantityConstraint() {
        TableNutrientQuantity.Row row = tblNutrientQuantityConstraint.getSelectedValue();
        String mixid = String.valueOf(row.getMixid());
        String nutrientid = row.getNutrientid();
        Integer relationshipid = row.getRelationshipid();
        try {
            Future<Boolean> task0
                    = TaskLauncher.submit(new DeleteNutrientConstraintTask(mixid, nutrientid, relationshipid));
            Boolean completed = task0.get();
            if (!completed) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(row.getNutrient());
            sb.append(" ");
            sb.append(row.getRelationship());
            sb.append(" ");
            sb.append((new DecimalFormat("######0.0#################")).format(row.getB()));
            addLogEntry(
                    getSelectedMix().getName(),
                    "Delete",
                    "Nutrient Quantity Constraint",
                    sb.toString(),
                    getSelectedMix().getMixid(),
                    "",
                    row.getNutrientid(),
                    "",
                    "",
                    row.getRelationshipid(),
                    row.getB(),
                    null);
            Future<List<List>> task1 = TaskLauncher.submit(new NutrientConstraintsTask(mixid));
            List<List> constraints = task1.get();
            tblNutrientQuantityConstraint.reload(constraints);
            setConstraintCounts();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void addNutrientRatioConstraint() {
        if (checkNutrientRatioConstraint()) {
            NumberCheck numberCheck = new NumberCheck();
            numberCheck.addToUncheckedList(txtNutrientRatioNutrientA.getText());
            numberCheck.addToUncheckedList(txtNutrientRatioNutrientB.getText());
            if (numberCheck.pass()) {
                NutrientDO nutrientDOA = cmbNutrientRatioNutrientA.getSelectedItem();
                NutrientDO nutrientDOB = cmbNutrientRatioNutrientB.getSelectedItem();
                RelationshipDO relationshipDO = (RelationshipDO) cmbNutrientRatioRelationship.getSelectedItem();
                BigDecimal A = new BigDecimal(txtNutrientRatioNutrientA.getText());
                BigDecimal B = new BigDecimal(txtNutrientRatioNutrientB.getText());
                try {
                    Future<Boolean> task0 = TaskLauncher.submit(new MergeNutrientRatioConstraintTask(
                            getSelectedMix().getMixid(),
                            nutrientDOA.getNutr_no(),
                            nutrientDOB.getNutr_no(),
                            relationshipDO.getRelationshipid(),
                            A,
                            B));
                    Boolean completed = task0.get();
                    if (!completed) {
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(nutrientDOA.getNutrdesc());
                    sb.append(" / ");
                    sb.append(nutrientDOB.getNutrdesc());
                    sb.append(" ");
                    sb.append(relationshipDO.getName());
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(A));
                    sb.append(" / ");
                    sb.append((new DecimalFormat("######0.0#################")).format(B));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Add",
                            "Nutrient Ratio Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            "",
                            nutrientDOA.getNutr_no(),
                            "",
                            nutrientDOB.getNutr_no(),
                            relationshipDO.getRelationshipid(),
                            A,
                            B);
                    Future<List<List>> task1 = TaskLauncher.submit(new NutrientRatioConstraintsTask(getSelectedMix().getMixid()));
                    List<List> constraints = task1.get();
                    tblNutrientRatio.reload(constraints);
                    setConstraintCounts();
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            } else {
                Message.showMessage("Value must be a number greater than zero");
            }
        }
    }

    private void deleteNutrientRatioConstraint() {
        TableNutrientRatioConstraint.Row row = tblNutrientRatio.getSelectedValue();
        String mixid = row.getMixid();
        String nutrientaid = row.getNutrientaid();
        String nutrientbid = row.getNutrientbid();
        Integer relationshipid = row.getRelationshipid();
        try {
            Future<Boolean> task0 = TaskLauncher.submit(
                    new DeleteNutrientRatioConstraintTask(mixid, nutrientaid, nutrientbid, relationshipid));
            Boolean completed = task0.get();
            if (!completed) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(row.getNutrienta());
            sb.append(" / ");
            sb.append(row.getNutrientb());
            sb.append(" ");
            sb.append(row.getRelationship());
            sb.append(" ");
            sb.append((new DecimalFormat("######0.0#################")).format(row.getA()));
            sb.append(" / ");
            sb.append((new DecimalFormat("######0.0#################")).format(row.getB()));
            addLogEntry(
                    getSelectedMix().getName(),
                    "Delete",
                    "Nutrient Ratio Constraint",
                    sb.toString(),
                    getSelectedMix().getMixid(),
                    "",
                    row.getNutrientaid(),
                    "",
                    row.getNutrientbid(),
                    row.getRelationshipid(),
                    row.getA(),
                    row.getB());
            Future<List<List>> task1 = TaskLauncher.submit(new NutrientRatioConstraintsTask(mixid));
            List<List> constraints = task1.get();
            tblNutrientRatio.reload(constraints);
            setConstraintCounts();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void addLogEntries(MixDO mix, String lifestage, Double score, String minimizationDescription) {
        addLogEntry(mix.getName(), "Add", "Lifestage", lifestage, mix.getMixid(), "", "", "", "", null, null, null);
        addLogEntry(mix.getName(),
                "Add",
                "Minimization Option",
                minimizationDescription.strip(),
                mix.getMixid(),
                "",
                "",
                "",
                "",
                null,
                null,
                null);
        addLogEntry(
                mix.getName(),
                "Solve",
                "Total Nutrient Index Score",
                String.valueOf(score),
                mix.getMixid(),
                "",
                "",
                "",
                "",
                null,
                null,
                null);
    }

    public void setTNI(BigDecimal tni) {
        lstmdl_Tni.addElement((new DecimalFormat("######0.0####")).format(tni.doubleValue()));
        lst_Tni.ensureIndexIsVisible(lstmdl_Tni.getSize() - 1);
        lst_Tni.setSelectedIndex(lst_Tni.getLastVisibleIndex());
    }

    public void setCost(BigDecimal cost) {
        lstmdl_Cost.addElement((new DecimalFormat("######0.0####")).format(cost.doubleValue()));
        lst_Cost.ensureIndexIsVisible(lstmdl_Cost.getSize() - 1);
        lst_Cost.setSelectedIndex(lst_Cost.getLastVisibleIndex());
    }

    private String createFoodLegend(String mixid) {
        StringBuilder sb = new StringBuilder();
        try {
            Future<List<Map<String, String>>> task = TaskLauncher.submit(new NamedMixFoodSortedByIdTask(mixid));
            List<Map<String, String>> source = task.get();
            if (source.isEmpty()) {
                return "";
            }
            List<MixFoodDO> foodsInMix = new ArrayList();
            source.forEach(row -> {
                String foodid = row.get("FOODID");
                String name = row.get("NAME");
                foodsInMix.add(new MixFoodDO(foodid, name));
            });
            for (int i = 0; i < foodsInMix.size(); i++) {
                sb.append(String.format("%1$2d) %2$s", i + 1, foodsInMix.get(i).getFoodName()));
                sb.append("\n");
            }
            //Add extra variables
            int size = foodsInMix.size();
            //Add deficiencies
            sb.append(String.format("%1$2d) %2$s", size + 1, "Deficiency - Minerals, Calcium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 2, "Deficiency - Minerals, Magnesium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 3, "Deficiency - Minerals, Potassium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 4, "Deficiency - Minerals, Sodium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 5, "Deficiency - Vitamins, A, RAE (mcg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 6, "Deficiency - Vitamins, E (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 7, "Deficiency - Vitamins, D (mcg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 8, "Deficiency - Vitamins, C (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 9, "Deficiency - Vitamins, Choline (mg)"));
            sb.append("\n");
            //Add excesses
            sb.append(String.format("%1$2d) %2$s", size + 10, "Excess - Minerals, Calcium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 11, "Excess - Minerals, Magnesium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 12, "Excess - Minerals, Potassium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 13, "Excess - Minerals, Sodium (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 14, "Excess - Vitamins, A, RAE (mcg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 15, "Excess - Vitamins, E (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 16, "Excess - Vitamins, D (mcg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 17, "Excess - Vitamins, C (mg)"));
            sb.append("\n");
            sb.append(String.format("%1$2d) %2$s", size + 18, "Excess - Vitamins, Choline (mg)"));
            sb.append("\n");
            //Add average deficiency
            sb.append(String.format("%1$2d) %2$s", size + 19, "Average Deficiency"));
            sb.append("\n");
            //Add average excess
            sb.append(String.format("%1$2d) %2$s", size + 20, "Average Excess"));
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        return sb.toString();
    }

    private void calculateRemainingFoodAllocationPercentage() {
        if (!cmbPortionFood.isSelectionEmpty()) {
            try {
                MixFoodDO food = cmbPortionFood.getSelectedItem();
                String mixid = getSelectedMix().getMixid();
                String foodid = food.getFoodId();
                Future<BigDecimal> task = TaskLauncher.submit(new UnallocatedFoodPercentageTask(mixid, foodid));
                BigDecimal remaining = task.get();
                String fRemaining = (new DecimalFormat("######0.0#################")).format(remaining);
                txtTotalPct.setText(fRemaining);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void clearHighscore() {
        lstmdl_Tni.clear();
    }

    private void clearCost() {
        lstmdl_Cost.clear();
    }

    private void showPopup(MouseEvent e, JPopupMenu pmn) {
        if (SwingUtilities.isRightMouseButton(e)) {
            Component component = e.getComponent();
            pmn.show(component, e.getX(), e.getY());
        }
    }

    private void showAbout() {
        JTextPane txp = new JTextPane();
        txp.setEditorKit(JEditorPane.createEditorKitForContentType("text/html"));
        txp.setText(U.getResourceAsString("/resources/html/about.html"));
        txp.setEditable(false);
        txp.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, true);
        txp.setCaretPosition(0);
        txp.addHyperlinkListener((HyperlinkEvent e) -> {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                if (Desktop.isDesktopSupported()) {
                    try {
                        Desktop.getDesktop().browse(new URI(e.getURL().toString()));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        JScrollPane scr = new JScrollPane(txp);
        scr.setPreferredSize(new Dimension(800, 400));
        scr.getVerticalScrollBar().setValue(0);
        JComponent[] inputs = {scr};
        Message.showOptionDialog(inputs, "About");
    }

    private void moveFoodPortion() {
        if (!tblMealPortions.isSelectionEmpty()) {
            List<TablePortion.Row> rows = tblMealPortions.getSelectedValues();
            if (!tblMeals.getSelectedValues().isEmpty()) {
                List<Row> selectedMeals = tblMeals.getSelectedValues();
                for (TablePortion.Row row : rows) {
                    String mixid = row.getMixid();
                    Integer mealid = row.getMealid();
                    String foodid = row.getFoodid();
                    Double pct = row.getPct().doubleValue();
                    Double pcti = pct / selectedMeals.size();
                    try {
                        Future<Boolean> task0 = TaskLauncher.submit(new DeleteFoodPortionTask(mixid, mealid, foodid));
                        Boolean task0Complete = task0.get();
                        for (Row meal : selectedMeals) {
                            Future<Boolean> task1 = TaskLauncher.submit(new InsertAndCalculateFoodPortionTask(
                                    getSelectedMix().getMixid(), meal.getMealid(), foodid, pcti));
                            Boolean task1Complete = task1.get();
                        }
                        reloadMealResults(getSelectedMix());
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            } else {
                Message.showMessage("Please select one or more meals.");
            }
        }
    }

    private void calculateBmr() {
        JTextField txtInput = new JTextField();
        JPanel pnl = new JPanel();
        txtInput.setPreferredSize(new Dimension(50, 25));
        pnl.add(new JLabel("What is your lean body mass in pounds?"));
        pnl.add(txtInput);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Basal Metabolic Rate");
        if (optionValue == 0) {
            String s = txtInput.getText();
            if (s != null && s.length() > 0) {
                StringBuilder sb = new StringBuilder();
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(s);
                if (checkNumber.pass()) {
                    Double weightinlbs = Double.valueOf(s);
                    double rdee = new KatchMcArdleFormula(weightinlbs).getCalories();
                    sb.append("Katch-McArdle Formula (Resting Daily Energy Expenditure): ");
                    sb.append(Math.round(rdee));
                    sb.append(" Kcals");
                    sb.append("\n");
                    double rdee2 = new CunninghamFormula(weightinlbs).getCalories();
                    sb.append("Cunningham Formula (Resting Metabolic Rate): ");
                    sb.append(Math.round(rdee2));
                    sb.append(" Kcals");
                    sb.append("\n");
                    Message.showMessage(sb.toString());
                } else {
                    Message.showMessage("Numbers only");
                }
            }
        }
    }

    private void convertMicronutrient() {
        FormLayout lyo = new FormLayout(
                "min:GROW,min,30dlu", // columns
                "28px,FILL:28px" // rows
        );
        JPanel pnl = new JPanel();
        pnl.setLayout(lyo);
        ComboBox<LifeStageDO> cmbLifeStage = new ComboBox();
        ComboBox<NutrientDO> cmbNutrients = new ComboBox();
        JLabel lblDV = new JLabel(StringUtils.center("%DRI", 6));
        try {
            Future<List<LifeStageDO>> task = TaskLauncher.submit(new LifestagesTask());
            List<LifeStageDO> lifestages = task.get();
            cmbLifeStage.reload(lifestages);
            cmbLifeStage.setSelectedIndex(8);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        try {
            Future<List<NutrientDO>> task = TaskLauncher.submit(new DriNutrientsTask());
            List<NutrientDO> list = task.get();
            if (list.isEmpty()) {
                return;
            }
            cmbNutrients.reload(list);
            cmbNutrients.setSelectedIndex(13);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        JTextField txtDailyValuePct = new JTextField();
        txtDailyValuePct.setMinimumSize(new Dimension(50, 20));
        pnl.add(cmbLifeStage, cc.xyw(1, 1, 3));
        pnl.add(cmbNutrients, cc.xy(1, 2));
        pnl.add(lblDV, cc.xy(2, 2));
        pnl.add(txtDailyValuePct, cc.xy(3, 2));
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Percent of Daily Reference Intake (DRI) to Grams");
        if (optionValue == 0) {
            String s = txtDailyValuePct.getText();
            if (s != null && s.length() > 0) {
                try {
                    Future<List<DriDO>> task = TaskLauncher.submit(new LifestageDriTask(
                            cmbNutrients.getSelectedItem().getNutr_no(),
                            cmbLifeStage.getSelectedItem().getLifeStageId()));
                    List<DriDO> driDOlist = task.get();
                    DriDO driDO = driDOlist.get(0);
                    NutrientDO nutrientDO = cmbNutrients.getSelectedItem();
                    StringBuilder sb = new StringBuilder();
                    NumberCheck checkNumber = new NumberCheck();
                    checkNumber.addToUncheckedList(s);
                    if (checkNumber.pass()) {
                        double dvpct = Double.parseDouble(s);
                        sb.append(String.format("%.0f", dvpct));
                        sb.append("% of ");
                        sb.append("DRI recommendation on ");
                        sb.append(driDO.getNutrientName()
                                .substring(0, driDO.getNutrientName().length() - 5));
                        sb.append(" for ");
                        sb.append(driDO.getLifestageLabel());
                        sb.append(" is ");
                        sb.append(String.format(
                                "%.1f", dvpct * (driDO.getNutrientQ().doubleValue() / 100)));
                        sb.append(" ");
                        sb.append(driDO.getNutrientUnits());
                        sb.append("\n");
                        Message.showMessage(sb.toString());
                    } else {
                        Message.showMessage("Numbers only");
                    }
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            }
        }
    }

    private void calculateDigestibleCarbs() {
        FormLayout lyo = new FormLayout(
                "min,30dlu", // columns
                "min,28px" // rows
        );
        JPanel pnl = new JPanel();
        pnl.setLayout(lyo);
        JTextField txtTotalCarbs = new JTextField();
        JTextField txtTotalFiber = new JTextField();
        JLabel lblTotalCarbs = new JLabel("What is total carbohydrate (g) of food item? ");
        JLabel lblTotalFiber = new JLabel("What is total fiber (g) in food item? ");
        lblTotalCarbs.setHorizontalAlignment(SwingConstants.RIGHT);
        lblTotalFiber.setHorizontalAlignment(SwingConstants.RIGHT);
        pnl.add(lblTotalCarbs, cc.xy(1, 1));
        pnl.add(txtTotalCarbs, cc.xy(2, 1));
        pnl.add(lblTotalFiber, cc.xy(1, 2));
        pnl.add(txtTotalFiber, cc.xy(2, 2));
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Digestible Carbohydrate");
        if (optionValue == 0) {
            String totalCarbs = txtTotalCarbs.getText();
            String totalFiber = txtTotalFiber.getText();
            if (totalCarbs != null && totalCarbs.length() > 0) {
                if (totalFiber != null && totalFiber.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    NumberCheck checkNumber = new NumberCheck();
                    checkNumber.addToUncheckedList(totalCarbs);
                    checkNumber.addToUncheckedList(totalFiber);
                    if (checkNumber.pass()) {
                        Double totalCarbsNumber = Double.valueOf(totalCarbs);
                        Double totalFiberNumber = Double.valueOf(totalFiber);
                        double digestibleCarbsNumber = new DigestibleCarbohydrate(totalCarbsNumber, totalFiberNumber)
                                .getDigestibleCarbohydrate();
                        sb.append("There are ");
                        sb.append(digestibleCarbsNumber);
                        sb.append(" grams of digestible carbohydrates.");
                        Message.showMessage(sb.toString());
                    }
                }
            }
        }
    }

    private void createFoodComparisonReport() {
        FoodComparisonReport csv = new FoodComparisonReport();
        csv.create(tblFoodDiff, tblFoodDiffA, tblFoodDiffB);
    }

    private void createAllFoodsReport() {
        frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        TaskLauncher.execute(new CreateAllFoodsReportTask(frm));
    }

    private void createAllFoodsReportDn() {
        frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        TaskLauncher.execute(new CreateAllFoodsReportDnTask(frm));
    }

    private void createMealPlanCaloriesReport() {
        (new MealPlanCaloriesReport()).create(getSelectedMix());
    }

    private void createMealPlanMacronutrientsReport() {
        (new MealPlanMacronutrientsReport()).create(getSelectedMix());
    }

    private void createMealPlanPortionsReport() {
        (new MealPlanPortionsReport()).create(getSelectedMix());
    }

    private void createMealPlanUsageReport() {
        (new MealPlanUsageReport()).create();
    }

    private void createMixComparisonReport() {
        (new MixComparisonReport()).create(tblMixDiff, tblMixDiffA, tblMixDiffB);
    }

    private void createMixTotalsReport() {
        (new MixTotalsReport()).create(getSelectedMix());
    }

    private void createMixResultsReportDn() {
        (new MixResultsReportDn()).create(getSelectedMix());
    }

    private void createMixResultsReport() {
        (new MixResultsReport()).create(getSelectedMix());
    }

    private void createMD5MixResultsReport() {
        (new MD5MixResults()).create(tblMixResults);
    }

    private void exportMix() {
        int returnVal = fch_Mix.showSaveDialog(frm);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            File file = fch_Mix.getSelectedFile();
            String path = file.getAbsolutePath();
            fch_Mix.setCurrentDirectory(new File(path));
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
                try {
                    Future<String> task = TaskLauncher.submit(new ExportMixTask(getSelectedMix().getMixid()));
                    String doc = task.get();
                    if (doc == null) {
                        frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                        return;
                    }
                    writer.write(U.formatXmlDoc(doc));
                    frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                    StringBuilder sb = new StringBuilder();
                    sb.append("Document saved to ");
                    sb.append(path);
                    Message.showMessage(sb.toString());
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            } catch (IOException e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void createNutrientContentReport() {
        (new NutrientContentReport()).create(txtNutrientSearchQuantity, cmbNutrientContentNutrient);
    }

    private void createDriReport() {
        LifeStageDO lifestage = (LifeStageDO) cmbLifestage.getSelectedItem();
        (new DriReport()).create(getSelectedMix(), lifestage);
    }

    private void calculateGlycemicIndexRange() {
        JTextField txtInput = new JTextField();
        JPanel pnl = new JPanel();
        txtInput.setPreferredSize(new Dimension(50, 25));
        pnl.add(new JLabel("What is glycemic index of food item?"));
        pnl.add(txtInput);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Glycemic Index Range");
        if (optionValue == 0) {
            String strGI = txtInput.getText();
            if (strGI != null && strGI.length() > 0) {
                StringBuilder sb = new StringBuilder();
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(strGI);
                if (checkNumber.pass()) {
                    Integer gi = Integer.valueOf(strGI);
                    String range = new GlycemicIndexRange(gi).getGlycemicIndexRange();
                    sb.append("The glycemic index is in ");
                    sb.append(range.toLowerCase());
                    sb.append(" range.");
                    Message.showMessage(sb.toString());
                }
            }
        }
    }

    private void calculateGlycemicLoad() {
        FormLayout lyo = new FormLayout(
                "min,30dlu", // columns
                "min,28px" // rows
        );
        JPanel pnl = new JPanel();
        pnl.setLayout(lyo);
        JTextField txtGi = new JTextField();
        JTextField txtDigestibleCarbs = new JTextField();
        JLabel lblDigestibleCarbs = new JLabel("How many digestible carbs (g) in food item? ");
        JLabel lblGi = new JLabel("What is glycemic index of food item? ");
        lblDigestibleCarbs.setHorizontalAlignment(SwingConstants.RIGHT);
        lblGi.setHorizontalAlignment(SwingConstants.RIGHT);
        pnl.add(lblDigestibleCarbs, cc.xy(1, 1));
        pnl.add(txtDigestibleCarbs, cc.xy(2, 1));
        pnl.add(lblGi, cc.xy(1, 2));
        pnl.add(txtGi, cc.xy(2, 2));
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Glycemic Load");
        if (optionValue == 0) {
            String gi = txtGi.getText();
            String carbs = txtDigestibleCarbs.getText();
            if (gi != null && gi.length() > 0) {
                if (carbs != null && carbs.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    NumberCheck checkNumber = new NumberCheck();
                    checkNumber.addToUncheckedList(gi);
                    checkNumber.addToUncheckedList(carbs);
                    if (checkNumber.pass()) {
                        Double giq = Double.valueOf(gi);
                        Double carbsq = Double.valueOf(carbs);
                        double gl = new GlycemicLoad(giq, carbsq).getGlycemicLoad();
                        sb.append("The glycemic load is ");
                        sb.append(gl);
                        sb.append(" grams.");
                        Message.showMessage(sb.toString());
                    }
                }
            }
        }
    }

    private void showKetosis() {
        // If you want the bibliography for these facts, ask.
        StringBuilder sb = new StringBuilder();
        double carbohydrateLow = new MinimumNutrientRequirements(0.0).getCarbohydrateLow();
        double carbohydrateMedium = new MinimumNutrientRequirements(0.0).getCarbohydrateMedium();
        double carbohydrateHigh = new MinimumNutrientRequirements(0.0).getCarbohydrateHigh();
        sb.append(carbohydrateMedium);
        sb.append(" to ");
        sb.append(carbohydrateHigh);
        sb.append(" grams of carbohydrates will inhibit ketosis.");
        sb.append("\n");
        sb.append(carbohydrateLow);
        sb.append(" to ");
        sb.append(carbohydrateMedium);
        sb.append(" grams of carbohydrates will appreciably reduce ketosis.");
        sb.append("\n");
        Message.showMessage(sb.toString());
    }

    private void deleteMix() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        JComponent[] inputs = {new JLabel("Would you like to delete mix?")};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Delete Mix");
        if (optionValue == 0) {
            Boolean completed = false;
            try {
                Future<Boolean> task = TaskLauncher.submit(new DeleteMixTask(getSelectedMix().getMixid()));
                completed = task.get();
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            if (!completed) {
                return;
            }
            clearMixesView();
            setConstraintCounts();
            reloadMixesTask();
            cmbMixes.setSelectedIndex(0);
        }
    }

    private void createMix() {
        JTextField txtInput = new JTextField();
        JComponent[] inputs = {new JLabel("What would you like to call it?"), txtInput};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Create Mix");
        if (optionValue == 0) {
            String mixName = txtInput.getText();
            StringCheck sc = new StringCheck();
            sc.addUncheckedList(mixName);
            if (sc.pass()) {
                try {
                    Future<MixDO> task = TaskLauncher.submit(new CreateMixTask(mixName));
                    MixDO mix = task.get();
                    reloadMixesTask();
                    cmbMixes.setSelectedItem(mix);
                    clearResultTables();
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            } else {
                Message.showMessage("These characters are not allowed: < & > ' \"");
            }
        }
    }

    private void duplicateMix() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        JComponent[] inputs = {new JLabel("Would you like to duplicate mix?")};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Duplicate Mix");
        if (optionValue == 0) {
            try {
                String mixId = getSelectedMix().getMixid();
                Future<MixDO> task = TaskLauncher.submit(new DuplicateMixTask(mixId));
                MixDO mix = task.get();
                reloadMixesTask();
                cmbMixes.setSelectedItem(mix);
                setQuantityScale();
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void pinAndDelete() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        try {
            Future<Boolean> task = TaskLauncher.submit(new PinAndDeleteTask(getSelectedMix().getMixid()));
            Boolean completed = task.get();
            if (completed) {
                tblNutrientQuantityConstraint.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(3));
                    sb.append(" ");
                    sb.append(row.get(4));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(5)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Delete",
                            "Nutrient Quantity Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            "",
                            (String) row.get(1),
                            "",
                            "",
                            (Integer) row.get(2),
                            (BigDecimal) row.get(5),
                            null);
                });
                tblNutrientRatio.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(4));
                    sb.append(" / ");
                    sb.append(row.get(7));
                    sb.append(" ");
                    sb.append(row.get(6));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(5)));
                    sb.append(" / ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(8)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Delete",
                            "Nutrient Ratio Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            "",
                            (String) row.get(1),
                            "",
                            (String) row.get(2),
                            (Integer) row.get(3),
                            (BigDecimal) row.get(5),
                            (BigDecimal) row.get(8));
                });
                tblFoodQuantityConstraint.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(4));
                    sb.append(" using ");
                    sb.append(row.get(5));
                    sb.append(" ");
                    sb.append(row.get(6));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(7)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Delete",
                            "Food Quantity Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            (String) row.get(1),
                            (String) row.get(2),
                            "",
                            "",
                            (Integer) row.get(3),
                            (BigDecimal) row.get(7),
                            null);
                });
                tblFoodRatioConstraint.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(6));
                    sb.append(" using ");
                    sb.append(row.get(7));
                    sb.append(" / ");
                    sb.append(row.get(10));
                    sb.append(" using ");
                    sb.append(row.get(11));
                    sb.append(" ");
                    sb.append(row.get(9));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(8)));
                    sb.append(" / ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(12)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Delete",
                            "Food Ratio Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            (String) row.get(1),
                            (String) row.get(2),
                            (String) row.get(3),
                            (String) row.get(4),
                            (Integer) row.get(5),
                            (BigDecimal) row.get(8),
                            (BigDecimal) row.get(12));
                });
                reloadMixConstraints(getSelectedMix().getMixid());
                tblFoodQuantityConstraint.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(4));
                    sb.append(" using ");
                    sb.append(row.get(5));
                    sb.append(" ");
                    sb.append(row.get(6));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(7)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Add",
                            "Food Quantity Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            (String) row.get(1),
                            (String) row.get(2),
                            "",
                            "",
                            (Integer) row.get(3),
                            (BigDecimal) row.get(7),
                            null);
                });
            }
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void pinAndKeep() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        try {
            Future<Boolean> task = TaskLauncher.submit(new PinAndKeepTask(getSelectedMix().getMixid()));
            Boolean completed = task.get();
            if (completed) {
                tblFoodQuantityConstraint.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(4));
                    sb.append(" using ");
                    sb.append(row.get(5));
                    sb.append(" ");
                    sb.append(row.get(6));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(7)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Delete",
                            "Food Quantity Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            (String) row.get(1),
                            (String) row.get(2),
                            "",
                            "",
                            (Integer) row.get(3),
                            (BigDecimal) row.get(7),
                            null);
                });
                reloadMixConstraints(getSelectedMix().getMixid());
                tblFoodQuantityConstraint.getStream().forEach(o -> {
                    List row = (List) o;
                    StringBuilder sb = new StringBuilder();
                    sb.append(row.get(4));
                    sb.append(" using ");
                    sb.append(row.get(5));
                    sb.append(" ");
                    sb.append(row.get(6));
                    sb.append(" ");
                    sb.append((new DecimalFormat("######0.0#################")).format(row.get(7)));
                    addLogEntry(
                            getSelectedMix().getName(),
                            "Add",
                            "Food Quantity Constraint",
                            sb.toString(),
                            getSelectedMix().getMixid(),
                            (String) row.get(1),
                            (String) row.get(2),
                            "",
                            "",
                            (Integer) row.get(3),
                            (BigDecimal) row.get(7),
                            null);
                });
            }
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void renameMix() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        JTextField txtInput = new JTextField();
        JComponent[] inputs = {new JLabel("What is your new mix name?"), txtInput};
        txtInput.setText(getSelectedMix().getName());
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Update Mix");
        if (optionValue == 0) {
            String mixnom = txtInput.getText();
            StringCheck sc = new StringCheck();
            sc.addUncheckedList(mixnom);
            if (sc.pass()) {
                Boolean completed = false;
                try {
                    Future<Boolean> task = TaskLauncher.submit(new UpdateNameOnMixTask(getSelectedMix().getMixid(), mixnom));
                    completed = task.get();
                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
                if (!completed) {
                    return;
                }
                reloadMixesTask();
                cmbMixes.setSelectedItem(getSelectedMix());
            } else {
                Message.showMessage("These characters are not allowed: < & > ' \"");
            }
        }
    }

    private void calculateN3FattyAcidRequired() {
        JTextField txtInput = new JTextField();
        JPanel pnl = new JPanel();
        txtInput.setPreferredSize(new Dimension(50, 25));
        pnl.add(new JLabel("What is your optimal calorie intake?"));
        pnl.add(txtInput);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Alpha-linolenic Acid, ALA, 18:3 n-3");
        if (optionValue == 0) {
            String s = txtInput.getText();
            if (s != null && s.length() > 0) {
                StringBuilder sb = new StringBuilder();
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(s);
                if (checkNumber.pass()) {
                    Double energyKcal = Double.valueOf(s);
                    final AlphaLinolenicRequired n3_fatty_acid_recommendation = new AlphaLinolenicRequired(energyKcal);
                    BigDecimal alaLow = n3_fatty_acid_recommendation.get_low_in_grams();
                    BigDecimal alaHigh = n3_fatty_acid_recommendation.get_high_in_grams();
                    sb.append("Alpha-linolenic Acid required is between ");
                    sb.append(alaLow.setScale(1, RoundingMode.HALF_EVEN));
                    sb.append(" and ");
                    sb.append(alaHigh.setScale(1, RoundingMode.HALF_EVEN));
                    sb.append(" grams.");
                    Message.showMessage(sb.toString());
                } else {
                    Message.showMessage("Numbers only");
                }
            }
        }
    }

    private void calculateProteinNeededForNitrogenBalance() {
        JTextField textFieldLbs = new JTextField();
        textFieldLbs.setPreferredSize(new Dimension(50, 25));
        JPanel pnl = new JPanel();
        pnl.add(new JLabel("What is your lean body mass in pounds?"));
        pnl.add(textFieldLbs);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Complete Protein Required");
        if (optionValue == 0) {
            String s = textFieldLbs.getText();
            if (s != null && s.length() > 0) {
                StringBuilder sb = new StringBuilder();
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(s);
                if (checkNumber.pass()) {
                    Double weightinlbs = Double.valueOf(s);
                    double protein = new MinimumNutrientRequirements(weightinlbs).getProtein();
                    sb.append("The amount of complete protein required in a no fat, no carbs regimen to maintain"
                            + " nitrogen balance is ");
                    sb.append(Math.round(protein));
                    sb.append(" grams.");
                    sb.append("\n");
                    Message.showMessage(sb.toString());
                } else {
                    Message.showMessage("Numbers only");
                }
            }
        }
    }

    private void calculateNutrientContent() {
        TableDri.Row row = tblDri.getSelectedValue();
        String nutrientid = row.getNutrientid();
        String nutrient = row.getNutrient();
        BigDecimal dri = row.getDri();
        txtNutrientSearchQuantity.setText((new DecimalFormat("######0.0#################")).format(dri));
        NutrientDO nutrientDO = new NutrientDO(nutrientid, nutrient, null);
        cmbNutrientContentNutrient.setSelectedItem(nutrientDO);
        try {
            Future<List<List>> task = TaskLauncher.submit(new NutrientContainingFoodsTask(nutrientid, dri));
            List<List> results = task.get();
            tblNutrientLookup.reload(results);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        tabMain.setSelectedIndex(4);
    }

    private void setFoodQuantityConstraintGuiValues() {
        TableFoodQuantityConstraint.Row row = tblFoodQuantityConstraint.getSelectedValue();
        String foodid = row.getFoodid();
        String nutrientid = row.getNutrientid();
        Integer relationshipid = row.getRelationshipid();
        BigDecimal q = row.getB();
        int foodIndex = cmbFoodQuantityFood.index(new MixFoodDO(foodid, ""));
        int nutrientIndex = cmbFoodQuantityNutrient.index(new NutrientDO(nutrientid, "", new BigDecimal("-1")));
        int relationshipIndex = cmbFoodQuantityRelationship.index(new RelationshipDO(relationshipid, ""));
        cmbFoodQuantityFood.setSelectedIndex(foodIndex);
        cmbFoodQuantityNutrient.setSelectedIndex(nutrientIndex);
        cmbFoodQuantityRelationship.setSelectedIndex(relationshipIndex);
        txtFoodQuantityValue.setText((new DecimalFormat("######0.0#################")).format(q));
        txtFoodQuantityValue.setCaretPosition(0);
    }

    private void setFoodRatioConstraintGuiValues() {
        TableFoodRatioConstraint.Row row = tblFoodRatioConstraint.getSelectedValue();
        String foodAid = row.getFoodida();
        String foodBid = row.getFoodidb();
        String nutrientAid = row.getNutrientida();
        String nutrientBid = row.getNutrientidb();
        Integer relationshipid = row.getRelationshipid();
        BigDecimal qA = row.getA();
        BigDecimal qB = row.getB();
        int foodAIndex = cmbFoodRatioFoodA.index(new MixFoodDO(foodAid, ""));
        int foodBIndex = cmbFoodRatioFoodB.index(new MixFoodDO(foodBid, ""));
        int nutrientAindex = cmbFoodRatioNutrientA.index(new NutrientDO(nutrientAid, "", new BigDecimal("-1")));
        int nutrientBindex = cmbFoodRatioNutrientB.index(new NutrientDO(nutrientBid, "", new BigDecimal("-1")));
        int relationshipindex = cmbFoodRatioRelationship.index(new RelationshipDO(relationshipid, ""));
        cmbFoodRatioFoodA.setSelectedIndex(foodAIndex);
        cmbFoodRatioFoodB.setSelectedIndex(foodBIndex);
        cmbFoodRatioNutrientA.setSelectedIndex(nutrientAindex);
        txtFoodNutrientRatioQuantityA.setText((new DecimalFormat("######0.0#################")).format(qA));
        txtFoodNutrientRatioQuantityA.setCaretPosition(0);
        cmbFoodRatioNutrientB.setSelectedIndex(nutrientBindex);
        txtFoodNutrientRatioQuantityB.setText((new DecimalFormat("######0.0#################")).format(qB));
        txtFoodNutrientRatioQuantityB.setCaretPosition(0);
        cmbFoodRatioRelationship.setSelectedIndex(relationshipindex);
    }

    private void setNutrientQuantityConstraintGuiValues() {
        TableNutrientQuantity.Row row = tblNutrientQuantityConstraint.getSelectedValue();
        String nutrientid = row.getNutrientid();
        Integer relationshipid = row.getRelationshipid();
        BigDecimal q = row.getB();
        int nutrientindex = cmbNutrientQuantityNutrient.index(new NutrientDO(nutrientid, "", new BigDecimal("-1")));
        int relationshipindex = cmbNutrientQuantityRelationship.index(new RelationshipDO(relationshipid, ""));
        cmbNutrientQuantityNutrient.setSelectedIndex(nutrientindex);
        cmbNutrientQuantityRelationship.setSelectedIndex(relationshipindex);
        txtNutrientQuantityValue.setText((new DecimalFormat("######0.0#################")).format(q));
        txtNutrientQuantityValue.setCaretPosition(0);
    }

    private void setNutrientRatioConstraintGuiValues() {
        TableNutrientRatioConstraint.Row row = tblNutrientRatio.getSelectedValue();
        String nutrientida = row.getNutrientaid();
        String nutrientidb = row.getNutrientbid();
        BigDecimal qA = row.getA();
        BigDecimal qB = row.getB();
        Integer relationshipid = row.getRelationshipid();
        int nutrientAindex = cmbNutrientRatioNutrientA.index(new NutrientDO(nutrientida, "", new BigDecimal("-1")));
        int nutrientBindex = cmbNutrientRatioNutrientB.index(new NutrientDO(nutrientidb, "", new BigDecimal("-1")));
        int relationshipindex = cmbNutrientRatioRelationship.index(new RelationshipDO(relationshipid, ""));
        cmbNutrientRatioNutrientA.setSelectedIndex(nutrientAindex);
        txtNutrientRatioNutrientA.setText((new DecimalFormat("######0.0#################")).format(qA));
        txtNutrientRatioNutrientA.setCaretPosition(0);
        cmbNutrientRatioNutrientB.setSelectedIndex(nutrientBindex);
        txtNutrientRatioNutrientB.setText((new DecimalFormat("######0.0#################")).format(qB));
        txtNutrientRatioNutrientB.setCaretPosition(0);
        cmbNutrientRatioRelationship.setSelectedIndex(relationshipindex);
    }

    private void setFoodGroupQuantityConstraintGuiValues() {
        TableGroupQuantityConstraint.Row row = tblGroupQuantityConstraint.getSelectedValue();
        String groupid = row.getGroupid();
        String nutrientid = row.getNutrientid();
        Integer relationshipid = row.getRelationshipid();
        BigDecimal q = row.getB();
        int groupIndex = cmbFoodGroup.index(new GroupDO(groupid, ""));
        int nutrientIndex = cmbGroupNutrient.index(new NutrientDO(nutrientid, "", new BigDecimal("-1")));
        int relationshipIndex = cmbGroupRelationship.index(new RelationshipDO(relationshipid, ""));
        cmbFoodGroup.setSelectedIndex(groupIndex);
        cmbGroupNutrient.setSelectedIndex(nutrientIndex);
        cmbGroupRelationship.setSelectedIndex(relationshipIndex);
        txtGroupQuantityValue.setText((new DecimalFormat("######0.0#################")).format(q));
        txtGroupQuantityValue.setCaretPosition(0);
    }

    private void reloadFoodComboBoxes(String mixid) {
        mixFoodLoader.reload(mixid);
        if (!mixFoodLoader.get().isEmpty()) {
            cmbFoodRatioFoodA.reload(mixFoodLoader.get());
            cmbFoodRatioFoodB.reload(mixFoodLoader.get());
            cmbFoodQuantityFood.reload(mixFoodLoader.get());
            cmbPortionFood.reload(mixFoodLoader.get());
        }
    }

    private void reloadCbNutrientData() {
        nutrientLoader.reload();
        cmbNutrientQuantityNutrient.reload(nutrientLoader.getList());
        cmbNutrientRatioNutrientA.reload(nutrientLoader.getList());
        cmbNutrientRatioNutrientB.reload(nutrientLoader.getList());
        cmbFoodQuantityNutrient.reload(nutrientLoader.getList());
        cmbGroupNutrient.reload(nutrientLoader.getList());
        cmbFoodRatioNutrientA.reload(nutrientLoader.getList());
        cmbFoodRatioNutrientB.reload(nutrientLoader.getList());
        cmbNutrientContentNutrient.reload(nutrientLoader.getList());
    }

    private void reloadCbRelationshipData() {
        relationshipLoader.reload();
        cmbNutrientQuantityRelationship.reload(relationshipLoader.get());
        cmbNutrientRatioRelationship.reload(relationshipLoader.get());
        cmbFoodQuantityRelationship.reload(relationshipLoader.get());
        cmbGroupRelationship.reload(relationshipLoader.get());
        cmbFoodRatioRelationship.reload(relationshipLoader.get());
        cmbNutrientQuantityRelationship.setSelectedIndex(2);
        cmbNutrientRatioRelationship.setSelectedIndex(2);
        cmbFoodQuantityRelationship.setSelectedIndex(2);
        cmbGroupRelationship.setSelectedIndex(2);
        cmbFoodRatioRelationship.setSelectedIndex(2);
    }

    private void reloadMixConstraints(String mixid) {
        try {
            Future<List<List>> task0 = TaskLauncher.submit(new NutrientConstraintsTask(mixid));
            Future<List<List>> task1 = TaskLauncher.submit(new NutrientRatioConstraintsTask(mixid));
            Future<List<List>> task2 = TaskLauncher.submit(new FoodConstraintsTask(mixid));
            Future<List<List>> task3 = TaskLauncher.submit(new FoodRatioConstraintsTask(mixid));
            Future<List<List>> task4 = TaskLauncher.submit(new GroupConstraintsTask(mixid));
            List<List> constraints0 = task0.get();
            List<List> constraints1 = task1.get();
            List<List> constraints2 = task2.get();
            List<List> constraints3 = task3.get();
            List<List> constraints4 = task4.get();
            try {
                Future<List<List>> task6 = TaskLauncher.submit(new NamedMixFoodSortedByNameTask(mixid));
                List<List> foods = task6.get();
                tblMixFood.reload(foods);
                tblSelectedFoods.reload(foods);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            tblNutrientQuantityConstraint.reload(constraints0);
            tblNutrientRatio.reload(constraints1);
            tblFoodQuantityConstraint.reload(constraints2);
            tblFoodRatioConstraint.reload(constraints3);
            tblGroupQuantityConstraint.reload(constraints4);
            setConstraintCounts();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void reload_tblmdl_nutrient_lookup() {
        NutrientDO nutrientDO = (NutrientDO) cmbNutrientContentNutrient.getSelectedItem();
        if (nutrientDO == null) {
            return;
        }
        String text = txtNutrientSearchQuantity.getText();
        NumberCheck checkNumber = new NumberCheck();
        checkNumber.addToUncheckedList(text);
        if (checkNumber.pass()) {
            BigDecimal q = new BigDecimal(text);
            try {
                Future<List<List>> task
                        = TaskLauncher.submit(new NutrientContainingFoodsTask(nutrientDO.getNutr_no(), q));
                List<List> results = task.get();
                tblNutrientLookup.reload(results);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        } else if (!text.isEmpty()) {
            Message.showMessage("Character must be number.");
        }
    }

    private void roundDown() {
        // Mix Results
        tblMixResults.roundDown();
        // Dri
        tblDri.roundDown();
        // By Meal (Kcal)
        tblMealCalories.roundDown();
        // By Meal (grams)
        tblMealMacronutrients.roundDown();
        // Food list
        tblFoodFacts.roundDown();
        // Food comparison
        tblFoodDiff.roundDown();
        // Mix comparison
        tblMixDiff.roundDown();
        // Nutrient lookup
        tblNutrientLookup.roundDown();
        // Inventory Days
        tblMealPlanUsage.roundDown();
        // Inventory Sum
        tblMealPlanUsageResults.roundDown();
        // Nutrient Constraints
        tblNutrientQuantityConstraint.roundDown();
        // Nutrient Ratio Constraints
        tblNutrientRatio.roundDown();
        // Food Constraints
        tblFoodQuantityConstraint.roundDown();
        // Food Ratio Constraints
        tblFoodRatioConstraint.roundDown();
        // Group Constraints
        tblGroupQuantityConstraint.roundDown();
        // Meal Portions
        tblMealPortions.roundDown();
    }

    private void roundUp() {
        // Mix Results
        tblMixResults.roundUp();
        // Dri
        tblDri.roundUp();
        // By Meal (Kcal)
        tblMealCalories.roundUp();
        // By Meal (grams)
        tblMealMacronutrients.roundUp();
        // Food list
        tblFoodFacts.roundUp();
        // Food comparison
        tblFoodDiff.roundUp();
        // Mix comparison
        tblMixDiff.roundUp();
        // Nutrient lookup
        tblNutrientLookup.roundUp();
        // Inventory Days
        tblMealPlanUsage.roundUp();
        // Inventory Sum
        tblMealPlanUsageResults.roundUp();
        // Nutrient Constraints
        tblNutrientQuantityConstraint.roundUp();
        // Nutrient Ratio Constraints
        tblNutrientRatio.roundUp();
        // Food Constraints
        tblFoodQuantityConstraint.roundUp();
        // Food Ratio Constraints
        tblFoodRatioConstraint.roundUp();
        // Group Constraints
        tblGroupQuantityConstraint.roundUp();
        // Meal Portions
        tblMealPortions.roundUp();
    }

    private void loadSelectedMix() {

        setSelectedMix(cmbMixes.getSelectedItem());
        setHighScore(getSelectedMix());
        tblMixFood.clear();
        tblSelectedFoods.clear();
        tblFoodsInFoodGroup.clear();
        reloadFoodComboBoxes(getSelectedMix().getMixid());
        reloadMixConstraints(getSelectedMix().getMixid());
        mixFoodLoader.reload(getSelectedMix().getMixid());
        cmbPortionFood.reload(mixFoodLoader.get());
        setConstraintCounts();
        reloadMixResults(getSelectedMix());
        reloadGroups(getSelectedMix().getMixid());
        reloadMealResults(getSelectedMix());
    }

    private void solveMixAndUpdateResults() {

        clearMixDiffSelection();
        solveModel(getSelectedMix());
        reloadMixResults(getSelectedMix());
        setHighScore(getSelectedMix());
        reloadMealResults(getSelectedMix());
    }

    private void clearMixDiffSelection() {
        tblMixDiffA.clearSelection();
        tblMixDiffB.clearSelection();
        tblMixDiff.clear();
        tblMealPlanUsageMixes.clearSelection();

    }

    private Optional<MixDO> solveModel(MixDO mix) {

        Optional<MixDO> opt = Optional.empty();

        try {
            LpToCplexMeals lpToCplexMeals = new LpToCplexMeals();
            LpToCplexExp lpToCplexExp = new LpToCplexExp();
            LpToCplex lpToCplex = new LpToCplex();
            LpToR lpToR = new LpToR();
            LpToJava lpToJava = new LpToJava();
            LpToRust lpToRust = new LpToRust();
            LpToC lpToC = new LpToC();
            LP lpmodel = new LP();
            String mixid = mix.getMixid();
            Integer lifestageid = mix.getLifestageid();
            String mixName = mix.getName();
            String lifestage = spnLifestage.getSelectedItem().getLabel();
            /* MINIMIZATION OPTION */
            String optionDescription = "";

            /* OBJECTIVE FUNCTION */
            switch (minimizationOption) {
                case Objective.DRI -> {

                    /* Minimizes DRI Deficiency */
                    Future<LhsContainer> taskLhs = TaskLauncher.submit(new ObjectiveDeficiencyLhsTask(mixid));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addObjectiveFunction(coefficients);
                    lpToCplexMeals.addObjectiveFunction(coefficients, "Minimize");
                    lpToCplexExp.addObjectiveFunction(coefficients, "Minimize");
                    lpToCplex.addObjectiveFunction(coefficients, "Minimize");
                    lpToR.addObjectiveFunction(coefficients, "Minimize");
                    lpToJava.addObjectiveFunction(coefficients, "Minimize");
                    lpToRust.addObjectiveFunction(coefficients, "Minimize");
                    lpToC.addObjectiveFunction(coefficients, "Minimize");
                    optionDescription = String.format(" %1$11s %2$s", "OBJECTIVE:", "Minimize Dietary Reference Intake deficiency");

                }
                case Objective.DRIDRI -> {

                    /* Minimizes DRI Deficiency and DRI Excess */
                    Future<LhsContainer> taskLhs = TaskLauncher.submit(new ObjectiveExcessAndDeficiencyLhsTask(mixid));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addObjectiveFunction(coefficients);
                    lpToCplexMeals.addObjectiveFunction(coefficients, "Minimize");
                    lpToCplexExp.addObjectiveFunction(coefficients, "Minimize");
                    lpToCplex.addObjectiveFunction(coefficients, "Minimize");
                    lpToR.addObjectiveFunction(coefficients, "Minimize");
                    lpToJava.addObjectiveFunction(coefficients, "Minimize");
                    lpToRust.addObjectiveFunction(coefficients, "Minimize");
                    lpToC.addObjectiveFunction(coefficients, "Minimize");
                    optionDescription = String.format(" %1$11s %2$s", "OBJECTIVE:", "Minimize Dietary Reference Intake deficiency and Dietary Reference Intake excess");

                }
                case Objective.DRIUL -> {

                    /* Minimizes DRI Deficiency and UL Excess */
                    Future<LhsContainer> taskLhs = TaskLauncher.submit(new ObjectiveExcessAndDeficiencyLhsTask(mixid));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addObjectiveFunction(coefficients);
                    lpToCplexMeals.addObjectiveFunction(coefficients, "Minimize");
                    lpToCplexExp.addObjectiveFunction(coefficients, "Minimize");
                    lpToCplex.addObjectiveFunction(coefficients, "Minimize");
                    lpToR.addObjectiveFunction(coefficients, "Minimize");
                    lpToJava.addObjectiveFunction(coefficients, "Minimize");
                    lpToRust.addObjectiveFunction(coefficients, "Minimize");
                    lpToC.addObjectiveFunction(coefficients, "Minimize");
                    optionDescription = String.format(" %1$11s %2$s", "OBJECTIVE:", "Minimize Dietary Reference Intakes deficiency and Upper Limit excess");

                }

            }

            /*  NUTRIENT DEFICIENCY AND EXCESS CONSTRAINTS  */
            Future<List<Map<String, Object>>> taskRhs_NUTRIENT_DEFICIENCY_AND_EXCESS_CONSTRAINTS = TaskLauncher.submit(new DRIExcessAndDeficiencyRhsTask(mixid, lifestageid));
            List<Map<String, Object>> lst_NUTRIENT_DEFICIENCY_AND_EXCESS_CONSTRAINTS = taskRhs_NUTRIENT_DEFICIENCY_AND_EXCESS_CONSTRAINTS.get();
            lst_NUTRIENT_DEFICIENCY_AND_EXCESS_CONSTRAINTS.forEach((row) -> {
                try {

                    String nutrientid = (String) row.get("NUTRIENTID");
                    Integer relationshipid = (Integer) row.get("RELATIONSHIPID");
                    Double b = (Double) row.get("B");
                    String nutrient = (String) row.get("NUTRIENT");
                    Future<LhsContainer> taskLhs_NUTRIENT_DEFICIENCY_AND_EXCESS_CONSTRAINTS = TaskLauncher.submit(new DRIExcessAndDeficiencyLhsTask(mixid, nutrientid));
                    LhsContainer container = taskLhs_NUTRIENT_DEFICIENCY_AND_EXCESS_CONSTRAINTS.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addConstraint(coefficients, relationshipid, b);
                    StringBuilder constraintName = new StringBuilder();
                    constraintName.append("Deficiency And Excess - ").append(nutrient);
                    lpToCplexMeals.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplexExp.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplex.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToR.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToJava.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToRust.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToC.addNutrientDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());

                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            });
            /* NUTRIENT AVERAGE EXCESS CONSTRAINTS */
            switch (minimizationOption) {
                case Objective.DRIDRI -> {
                    /* DRI AVERAGE EXCESS CONSTRAINT */
                    try {

                        Future<LhsContainer> taskLhs = TaskLauncher.submit(new DRIAverageExcessLhsTask(mixid, lifestageid));
                        LhsContainer container = taskLhs.get();
                        double[] coefficients = container.getCoefficients();
                        int relationshipid = 3;
                        int b = 0;
                        lpmodel.addConstraint(coefficients, relationshipid, 0);
                        StringBuilder constraintName = new StringBuilder();
                        constraintName.append("Average Excess - DRI");
                        lpToCplexMeals.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToCplexExp.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToCplex.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToR.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToJava.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToRust.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToC.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());

                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
                case Objective.DRIUL -> {
                    /* UL AVERAGE EXCESS CONSTRAINT */
                    try {

                        StringBuilder sb = new StringBuilder();
                        Future<LhsContainer> taskLhs = TaskLauncher.submit(new ULAverageExcessLhsTask(mixid, lifestageid));
                        LhsContainer container = taskLhs.get();
                        double[] coefficients = container.getCoefficients();
                        int relationshipid = 3;
                        int b = 0;
                        lpmodel.addConstraint(coefficients, relationshipid, 0);
                        StringBuilder constraintName = new StringBuilder();
                        constraintName.append("Average Excess - UL");
                        lpToCplexMeals.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToCplexExp.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToCplex.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToR.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToJava.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToRust.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                        lpToC.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());

                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }

            }
            /* NUTRIENT AVERAGE DEFICIENCY CONSTRAINT */
            try {

                Future<LhsContainer> taskLhs = TaskLauncher.submit(new DRIAverageDeficiencyLhsTask(mixid, lifestageid));
                LhsContainer container = taskLhs.get();
                double[] coefficients = container.getCoefficients();
                int relationshipid = 3;
                int b = 0;
                lpmodel.addConstraint(coefficients, relationshipid, 0);
                StringBuilder constraintName = new StringBuilder();
                constraintName.append("Average Deficiency - DRI");
                lpToCplexMeals.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                lpToCplexExp.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                lpToCplex.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                lpToR.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                lpToJava.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                lpToRust.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());
                lpToC.addNutrientAverageDeficiencyAndExcessConstraint(coefficients, relationshipid, b, constraintName.toString());

            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
            /* NUTRIENT CONSTRAINTS */
            Future<List<Map<String, Object>>> taskRhs_NUTRIENT_CONSTRAINTS = TaskLauncher.submit(new NutrientRhsTask(mixid));
            List<Map<String, Object>> lst_NUTRIENT_CONSTRAINTS = taskRhs_NUTRIENT_CONSTRAINTS.get();
            lst_NUTRIENT_CONSTRAINTS.forEach((row) -> {
                try {

                    String nutrientid = (String) row.get("NUTRIENTID");
                    Integer relationshipid = (Integer) row.get("RELATIONSHIPID");
                    Double b = (Double) row.get("B");
                    String nutrient = (String) row.get("NUTRIENT");
                    String eq = (String) row.get("EQ");
                    Future<LhsContainer> taskLhs = TaskLauncher.submit(new NutrientLhsTask(mixid, nutrientid));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addConstraint(coefficients, relationshipid, b);
                    StringBuilder constraintName = new StringBuilder();
                    constraintName
                            .append(nutrient)
                            .append(" ")
                            .append(eq)
                            .append(" ")
                            .append(U.plain(b));
                    lpToCplexMeals.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplexExp.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplex.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToR.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToJava.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToRust.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToC.addNutrientConstraint(coefficients, relationshipid, b, constraintName.toString());

                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            });
            /* NUTRIENT RATIO CONSTRAINTS */
            Future<List<Map<String, Object>>> taskRhs_NUTRIENT_RATIO_CONSTRAINTS = TaskLauncher.submit(new NutrientRatioRhsTask(mixid));
            List<Map<String, Object>> lst_NUTRIENT_RATIO_CONSTRAINTS = taskRhs_NUTRIENT_RATIO_CONSTRAINTS.get();
            lst_NUTRIENT_RATIO_CONSTRAINTS.forEach((row) -> {
                try {

                    String nutrientid1 = (String) row.get("NUTRIENT_ID_1");
                    String nutrientid2 = (String) row.get("NUTRIENT_ID_2");
                    int relationshipid = (int) row.get("RELATIONSHIPID");
                    BigDecimal a = (BigDecimal) row.get("A");
                    BigDecimal b = (BigDecimal) row.get("B");
                    String nutrient1 = (String) row.get("NUTRIENT1");
                    String nutrient2 = (String) row.get("NUTRIENT2");
                    String eq = (String) row.get("EQ");
                    Future<LhsContainer> taskLhs = TaskLauncher.submit(new NutrientRatioLhsTask(mixid, nutrientid1, nutrientid2, a, b));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addConstraint(coefficients, relationshipid, 0.0);
                    StringBuilder constraintName = new StringBuilder();
                    constraintName
                            .append(nutrient1)
                            .append(" / ")
                            .append(nutrient2)
                            .append(" ")
                            .append(eq)
                            .append(" ")
                            .append(U.plain(a))
                            .append(" / ")
                            .append(U.plain(b));
                    lpToCplexMeals.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToCplexExp.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToCplex.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToR.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToJava.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToRust.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToC.addNutrientRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());

                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            });
            /* FOOD CONSTRAINTS */
            Future<List<Map<String, Object>>> taskRhs_FOOD_CONSTRAINTS = TaskLauncher.submit(new FoodRhsTask(mixid));
            List<Map<String, Object>> lst_FOOD_CONSTRAINTS = taskRhs_FOOD_CONSTRAINTS.get();
            lst_FOOD_CONSTRAINTS.forEach((row) -> {
                try {

                    String foodid = (String) row.get("FOODID");
                    String nutrientid = (String) row.get("NUTRIENTID");
                    Integer relationshipid = (Integer) row.get("RELATIONSHIPID");
                    Double b = (double) row.get("B");
                    String food = (String) row.get("FOOD");
                    String nutrient = (String) row.get("NUTRIENT");
                    String eq = (String) row.get("EQ");
                    Future<LhsContainer> taskLhs
                            = TaskLauncher.submit(new FoodLhsTask(mixid, foodid, nutrientid, relationshipid));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addConstraint(coefficients, relationshipid, b);
                    StringBuilder constraintName = new StringBuilder();
                    constraintName
                            .append(food)
                            .append(" AS ")
                            .append(nutrient)
                            .append(" ")
                            .append(eq)
                            .append(" ")
                            .append(U.plain(b));
                    lpToCplexMeals.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplexExp.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplex.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToR.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToJava.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToRust.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToC.addFoodConstraint(coefficients, relationshipid, b, constraintName.toString());

                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            });
            /* FOOD RATIO CONSTRAINTS */
            Future<List<Map<String, Object>>> taskRhs_FOOD_RATIO_CONSTRAINTS = TaskLauncher.submit(new FoodRatioRhsTask(mixid));
            List<Map<String, Object>> lst_FOOD_RATIO_CONSTRAINTS = taskRhs_FOOD_RATIO_CONSTRAINTS.get();
            lst_FOOD_RATIO_CONSTRAINTS.forEach((row) -> {
                try {

                    String foodidA = (String) row.get("FOOD_ID_1");
                    String nutrientidA = (String) row.get("NUTRIENT_ID_1");
                    BigDecimal A = (BigDecimal) row.get("A");
                    String foodidB = (String) row.get("FOOD_ID_2");
                    String nutrientidB = (String) row.get("NUTRIENT_ID_2");
                    BigDecimal B = (BigDecimal) row.get("B");
                    int relationshipid = (int) row.get("RELATIONSHIPID");
                    String food1 = (String) row.get("FOOD1");
                    String nutrient1 = (String) row.get("NUTRIENT1");
                    String food2 = (String) row.get("FOOD2");
                    String nutrient2 = (String) row.get("NUTRIENT2");
                    String eq = (String) row.get("EQ");
                    Future<LhsContainer> taskLhs
                            = TaskLauncher.submit(new FoodRatioLhsTask(mixid, foodidA, nutrientidA, A, foodidB, nutrientidB, B));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addConstraint(coefficients, relationshipid, 0.0);
                    StringBuilder constraintName = new StringBuilder();
                    constraintName
                            .append(food1)
                            .append(" AS ")
                            .append(nutrient1)
                            .append(" / ")
                            .append(food2)
                            .append(" AS ")
                            .append(nutrient2)
                            .append(" ")
                            .append(eq)
                            .append(" ")
                            .append(U.plain(A))
                            .append(" / ")
                            .append(U.plain(B));
                    lpToCplexMeals.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToCplexExp.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToCplex.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToR.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToJava.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToRust.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());
                    lpToC.addFoodRatioConstraint(coefficients, relationshipid, 0.0, constraintName.toString());

                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            /* GROUP CONSTRAINTS */
            Future<List<Map<String, Object>>> taskRhs_GROUP_CONSTRAINTS = TaskLauncher.submit(new GroupRhsTask(mixid));
            List<Map<String, Object>> lst_GROUP_CONSTRAINTS = taskRhs_GROUP_CONSTRAINTS.get();
            lst_GROUP_CONSTRAINTS.forEach((row) -> {
                try {

                    String groupid = (String) row.get("GROUPID");
                    String nutrientid = (String) row.get("NUTRIENTID");
                    Integer relationshipid = (Integer) row.get("RELATIONSHIPID");
                    Double b = (double) row.get("B");
                    String group = (String) row.get("GROUP");
                    String nutrient = (String) row.get("NUTRIENT");
                    String eq = (String) row.get("EQ");
                    Future<LhsContainer> taskLhs
                            = TaskLauncher.submit(new GroupLhsTask(mixid, groupid, nutrientid));
                    LhsContainer container = taskLhs.get();
                    double[] coefficients = container.getCoefficients();
                    lpmodel.addConstraint(coefficients, relationshipid, b);
                    StringBuilder constraintName = new StringBuilder();
                    constraintName
                            .append(group)
                            .append(" AS ")
                            .append(nutrient)
                            .append(" ")
                            .append(eq)
                            .append(" ")
                            .append(U.plain(b));
                    lpToCplexMeals.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplexExp.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToCplex.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToR.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToJava.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToRust.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());
                    lpToC.addGroupConstraint(coefficients, relationshipid, b, constraintName.toString());

                } catch (Exception e) {
                    LoggerImpl.INSTANCE.logProblem(e);
                }
            });

            // ----- LEGENDS -----
            lpToCplexMeals.addMixLegend(mixName, optionDescription);
            lpToCplexExp.addMixLegend(mixName, optionDescription);
            lpToCplexMeals.addFoodLegend(createFoodLegend(mixid));
            lpToCplexExp.addFoodLegend(createFoodLegend(mixid));
            lpToCplex.addMixLegend(mixName, optionDescription);
            lpToCplex.addFoodLegend(createFoodLegend(mixid));
            lpToR.addMixLegend(mixName, optionDescription);
            lpToR.addFoodLegend(createFoodLegend(mixid));
            lpToJava.addMixLegend(mixName, optionDescription);
            lpToJava.addFoodLegend(createFoodLegend(mixid));
            lpToRust.addMixLegend(mixName, optionDescription);
            lpToRust.addFoodLegend(createFoodLegend(mixid));
            lpToC.addMixLegend(mixName, optionDescription);
            lpToC.addFoodLegend(createFoodLegend(mixid));

            try {
                lpmodel.solve();
            } catch (Exception e) {
                final Runnable showNotFeasibleMessage = () -> {
                    JComponent[] inputs = {getNoSolutionPanel()};
                    Message.showMessage(inputs, "No Feasible Solution");
                };
                SwingUtilities.invokeLater(showNotFeasibleMessage);
            }

            // ----- SOLVE MODEL -----
            if (lpmodel.isSolved()) {

                double[] solutionPoint = lpmodel.getPoint();

                // ---- UPDATE DATABASE ----------------------------------------
                Runnable task_UpdateMixFood = () -> {

                    MixFoodsQuery q = new MixFoodsQuery(mixid);
                    List<Map> mixfoodlist = q.get();
                    for (int i = 0; i < mixfoodlist.size(); i++) {
                        Map row = mixfoodlist.get(i);
                        String foodid = (String) row.get("FOODID");
                        BigDecimal x = new BigDecimal(solutionPoint[i], MathContext.DECIMAL128);
                        (new UpdateMixFoodAction(mixid, foodid, x)).execute();
                    }
                };

                TaskLauncher.execute(task_UpdateMixFood);

                int fcount = solutionPoint.length - 20;
                String model = lpToCplex.toString();
                double deficiency_Ca = solutionPoint[fcount];
                double deficiency_Mg = solutionPoint[fcount + 1];
                double deficiency_K = solutionPoint[fcount + 2];
                double deficiency_Na = solutionPoint[fcount + 3];
                double deficiency_VitA = solutionPoint[fcount + 4];
                double deficiency_VitE = solutionPoint[fcount + 5];
                double deficiency_VitD = solutionPoint[fcount + 6];
                double deficiency_VitC = solutionPoint[fcount + 7];
                double deficiency_Choline = solutionPoint[fcount + 8];
                double excess_Ca = solutionPoint[fcount + 9];
                double excess_Mg = solutionPoint[fcount + 10];
                double excess_K = solutionPoint[fcount + 11];
                double excess_Na = solutionPoint[fcount + 12];
                double excess_VitA = solutionPoint[fcount + 13];
                double excess_VitE = solutionPoint[fcount + 14];
                double excess_VitD = solutionPoint[fcount + 15];
                double excess_VitC = solutionPoint[fcount + 16];
                double excess_Choline = solutionPoint[fcount + 17];
                double avg_deficiency = solutionPoint[fcount + 18];
                double avg_excess = solutionPoint[fcount + 19];
                double cost = lpmodel.getCost();

                TaskLauncher.execute(new UpdateMixTask(
                        mixid,
                        lifestageid,
                        model,
                        deficiency_Ca,
                        deficiency_Mg,
                        deficiency_K,
                        deficiency_Na,
                        deficiency_VitA,
                        deficiency_VitE,
                        deficiency_VitD,
                        deficiency_VitC,
                        deficiency_Choline,
                        excess_Ca,
                        excess_Mg,
                        excess_K,
                        excess_Na,
                        excess_VitA,
                        excess_VitE,
                        excess_VitD,
                        excess_VitC,
                        excess_Choline,
                        avg_deficiency,
                        avg_excess,
                        cost
                ));

                Future<BigDecimal> task_FetchTniScore = TaskLauncher.submit(new FetchTniScoreTask(mix.getMixid(), mix.getLifestageid()));
                BigDecimal tniScore = task_FetchTniScore.get();

                Optional<BigDecimal> optTniScore = Optional.ofNullable(tniScore);
                tniScore = optTniScore.orElse(BigDecimal.ZERO);
                addLogEntries(mix, lifestage, tniScore.doubleValue(), optionDescription);

                mix.setModel(model);
                mix.setCost(new BigDecimal(Double.valueOf(cost).toString()));
                mix.setTniScore(tniScore);

                opt = Optional.of(mix);
                FileName fileName = new FileName();
                String time = U.getCurrentTimeMillisTxt();
                fileName.setVariableText(time);

                if (cbToCplexMeals.isSelected()) {
                    U.write(fileName.lpsolve_cplex_meals(), lpToCplexMeals.toString());
                }
                if (cbToCplexExp.isSelected()) {
                    U.write(fileName.lpsolve_cplex_exp(), lpToCplexExp.toString());
                }
                if (cbToCplex.isSelected()) {
                    U.write(fileName.lpsolve_cplex(), lpToCplex.toString());
                }
                if (cbToR.isSelected()) {
                    U.write(fileName.lpsolve_r(), lpToR.toString());
                }
                if (cbToJava.isSelected()) {
                    U.write(fileName.commons_math(), lpToJava.toString());
                }
                if (cbToRust.isSelected()) {
                    U.write(fileName.lpsolve_rust(), lpToRust.toString());
                }
                if (cbToC.isSelected()) {
                    U.write(fileName.lpsolve_c(), lpToC.toString());
                }

            } else {

                Runnable task_UpdateMixFood = () -> {

                    MixFoodsQuery q = new MixFoodsQuery(mixid);
                    List<Map> mixfoodlist = q.get();
                    for (int i = 0; i < mixfoodlist.size(); i++) {
                        Map row = mixfoodlist.get(i);
                        String foodid = (String) row.get("FOODID");
                        (new UpdateMixFoodAction(mixid, foodid, BigDecimal.ZERO)).execute();
                    }

                    (new UpdateMixAction(mixid, lifestageid, lpToCplex.toString())).execute();
                };

                TaskLauncher.execute(task_UpdateMixFood);

                mix.setModel(lpToCplex.toString());
                mix.setCost(new BigDecimal("-1.0"));
                mix.setTniScore(BigDecimal.ZERO);

            }
            setConstraintCounts();

        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
        return opt;
    }

    private void reloadMixResults(MixDO mix) {
        String mixid = mix.getMixid();
        String model = mix.getModel();

        Future<List<List>> task00 = TaskLauncher.submit(new MixResultsTask(mix.getMixid()));
        Runnable feedback00 = () -> {
            try {
                List<List> results = task00.get();
                SwingUtilities.invokeLater(() -> {
                    tblMixResults.reload(results);
                });
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback00);

        Future<List<List>> task01 = TaskLauncher.submit(new MealPlanMealsTask(mixid));
        Runnable feedback01 = () -> {
            try {
                List<List> meals = task01.get();
                SwingUtilities.invokeLater(() -> {
                    tblMeals.reload(meals);
                });
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback01);

        txaLpProgram.setText(model);
        txaLpProgram.setCaretPosition(0);
        LifeStageDO lifestage = (LifeStageDO) cmbLifestage.getSelectedItem();

        Future<List<List>> task02
                = TaskLauncher.submit(new DriDiffTask(mix.getMixid(), lifestage.getLifeStageId()));
        Runnable feedback02 = () -> {
            try {
                List<List> diff = task02.get();
                SwingUtilities.invokeLater(() -> {
                    tblDri.reload(diff);
                });
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback02);

        setQuantityScale();
    }

    private void setHighScore(MixDO mix) {
        setTNI(mix.getTniScore());
        setCost(mix.getCost());
    }

    private void reloadMealResults(MixDO mix) {

        Future<List<List>> task00 = TaskLauncher.submit(new MealPlanPortionsTask(mix.getMixid()));
        Runnable feedback00 = () -> {
            try {
                List<List> portions = task00.get();
                SwingUtilities.invokeLater(() -> {
                    tblMealPortions.reload(portions);
                });
            } catch (Exception e) {
                e.printStackTrace();
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback00);

        Future<List<List>> task01 = TaskLauncher.submit(new MealPlanResultsTask(mix.getMixid()));
        Runnable feedback01 = () -> {
            try {
                List<List> results = task01.get();
                SwingUtilities.invokeLater(() -> {
                    if (results.size() > 1) {
                        tblMealCalories.reload(results);
                    } else {
                        tblMealCalories.clear();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback01);

        Future<List<List>> task02 = TaskLauncher.submit(new MealPlanResultsMacronutrientsTask(mix.getMixid()));
        Runnable feedback02 = () -> {
            try {
                List<List> results = task02.get();
                SwingUtilities.invokeLater(() -> {
                    if (results.size() > 1) {
                        tblMealMacronutrients.reload(results);
                    } else {
                        tblMealMacronutrients.clear();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback02);

    }

    private void importMixAndUpdateResults() {

        clearMixDiffSelection();
        solveModel(getSelectedMix());

        Future<List<Mix>> task00 = TaskLauncher.submit(new FetchMixesToRecordTask());
        Runnable feedback00 = () -> {
            try {
                List<Mix> fetchMixesToRecord = task00.get();
                SwingUtilities.invokeLater(() -> {
                    reloadCmbMixes(fetchMixesToRecord);
                    selectMix(getSelectedMix());
                });
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback00);

        reloadFoods();

        Future<List<List>> task01 = TaskLauncher.submit(new FetchMixesToListTask());
        Runnable feedback01 = () -> {
            try {
                List<List> fetchMixesToList = task01.get();
                SwingUtilities.invokeLater(() -> {
                    reloadMixes(fetchMixesToList);
                });
            } catch (Exception e) {
                //SwingUtilities.invokeLater(() -> {});
            }
        };
        FeedBackLauncher.execute(feedback01);
    }

    private void clearResultTables() {
        tblMixResults.clear();
        tblDri.clear();
        tblMeals.clear();
        tblMealPortions.clear();
        tblMealCalories.clear();
        tblMealMacronutrients.clear();
        txaLpProgram.setText("");
        tblNutrientQuantityConstraint.clear();
        tblNutrientRatio.clear();
        tblFoodQuantityConstraint.clear();
        tblFoodRatioConstraint.clear();
        tblGroupQuantityConstraint.clear();
    }

    private void setConstraintCounts() {
        lblNutrientRatioCount.setText(getNutrientRatioConstraintCount());
        lblFoodRatioCount.setText(getFoodRatioConstraintCount());
        lblFoodCount.setText(getFoodConstraintCount());
        lblNutrientCount.setText(getNutrientQuantityConstraintCount());
        lblGroupCount.setText(getGroupConstraintCount());
        // lblGroupRatioCount.setText("Fix");
    }

    private void setSplitPanelDivider() {
        splMain.setDividerLocation(410);
    }

    private void setQuantityScale() {
        if (chkResultRoundUp.isSelected()) {
            roundUp();
        } else {
            roundDown();
        }
    }

    private void showFoodStats(String foodid) {
        foodStats.reload(foodid);
        Message.showMessagePadW510(230, "Food Statistics", foodStats.get_stats());
    }

    private void showMixStats() {
        if (getSelectedMix().getMixid().isEmpty()) {
            return;
        }
        try {
            Future<List<Map<String, Object>>> task = TaskLauncher.submit(new MixStatsTask(getSelectedMix().getMixid()));
            List<Map<String, Object>> list = task.get();
            if (list.isEmpty()) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            list.forEach(row -> {
                BigDecimal calories = (BigDecimal) row.get("CALORIES");
                BigDecimal fatpct = (BigDecimal) row.get("FATPCT");
                BigDecimal carbpct = (BigDecimal) row.get("CARBPCT");
                BigDecimal proteinpct = (BigDecimal) row.get("PROTEINPCT");
                BigDecimal alcoholpct = (BigDecimal) row.get("ALCOHOLPCT");
                BigDecimal fq = (BigDecimal) row.get("FQ");
                BigDecimal satfatpct = (BigDecimal) row.get("SATFATPCT");
                BigDecimal monoufatpct = (BigDecimal) row.get("MONOUFATPCT");
                BigDecimal polyufatpct = (BigDecimal) row.get("POLYUFATPCT");
                BigDecimal essentialfatratio = (BigDecimal) row.get("ESSENTIALFATRATIO");
                BigDecimal electrolyteratio = (BigDecimal) row.get("ELECTROLYTERATIO");
                BigDecimal lapct = (BigDecimal) row.get("LAPCT");
                BigDecimal alapct = (BigDecimal) row.get("ALAPCT");
                BigDecimal pratio = (BigDecimal) row.get("PRATIO");
                BigDecimal mratio = (BigDecimal) row.get("MRATIO");
                BigDecimal sratio = (BigDecimal) row.get("SRATIO");
                sb.append("Fat: ");
                sb.append((new DecimalFormat("######0.0#")).format(fatpct));
                sb.append("%\n");
                sb.append("Carbohydrate: ");
                sb.append((new DecimalFormat("######0.0#")).format(carbpct));
                sb.append("%\n");
                sb.append("Protein: ");
                sb.append((new DecimalFormat("######0.0#")).format(proteinpct));
                sb.append("%\n");
                sb.append("Alcohol: ");
                sb.append((new DecimalFormat("######0.0#")).format(alcoholpct));
                sb.append("%\n");
                sb.append("Saturated Fat: ");
                sb.append((new DecimalFormat("######0.0#")).format(satfatpct));
                sb.append("%\n");
                sb.append("Polyunsaturated Fat: ");
                sb.append((new DecimalFormat("######0.0#")).format(polyufatpct));
                sb.append("%\n");
                sb.append("Monounsaturated Fat: ");
                sb.append((new DecimalFormat("######0.0#")).format(monoufatpct));
                sb.append("%\n");
                sb.append("Linoleic Acid: ");
                sb.append((new DecimalFormat("######0.0#")).format(lapct));
                sb.append("%\n");
                sb.append("Alpha-linolenic Acid: ");
                sb.append((new DecimalFormat("######0.0#")).format(alapct));
                sb.append("%\n");
                sb.append("Ratio SFA/TF: ");
                sb.append((new DecimalFormat("######0.0#")).format(sratio));
                sb.append("\n");
                sb.append("Ratio PUFA/TF: ");
                sb.append((new DecimalFormat("######0.0#")).format(pratio));
                sb.append("\n");
                sb.append("Ratio MUFA/TF: ");
                sb.append((new DecimalFormat("######0.0#")).format(mratio));
                sb.append("\n");
                sb.append("Ratio LA/ALA: ");
                sb.append((new DecimalFormat("######0.0#")).format(essentialfatratio));
                sb.append("\n");
                sb.append("Ratio K/Na: ");
                sb.append((new DecimalFormat("######0.0#")).format(electrolyteratio));
                sb.append("\n");
                sb.append("Food Quotient (FQ): ");
                sb.append((new DecimalFormat("######0.0#")).format(fq));
                sb.append("\n");
            });
            Message.showMessage(sb.toString());
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void deleteAllMixes() {
        JLabel lbl = new JLabel("DO YOU WANT TO DELETE ALL MIXES?");
        JPanel pnl = new JPanel();
        pnl.add(lbl);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogYesNo(inputs, "** WARNING: DELETING VALUABLE DATA **");
        if (optionValue == 0) {
            frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            try {
                Future<Boolean> task = TaskLauncher.submit(new DeleteAllMixesTask());
                task.get();
                frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                clearMixesView();
                Message.showMessage("", "ALL MIXES HAVE BEEN DELETED.");
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void deleteAll() {
        JLabel lbl = new JLabel("DO YOU WANT TO DELETE ALL MIXES AND ALL FOOD ITEMS?");
        JPanel pnl = new JPanel();
        pnl.add(lbl);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogYesNo(inputs, "** WARNING: DELETING VALUABLE DATA **");
        if (optionValue == 0) {
            frm.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            try {
                Future<Boolean> task0 = TaskLauncher.submit(new DeleteAllMixesTask());
                task0.get();
                Future<Boolean> task1 = TaskLauncher.submit(new DeleteAllFoodsTask());
                task1.get();
                Future<Boolean> task2 = TaskLauncher.submit(new DeleteAllFoodCategoriesTask());
                task2.get();
                frm.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                clearMixesView();
                clearFoodsView();
                Message.showMessage("", "ALL MIXES AND ALL FOOD ITEMS HAVE BEEN DELETED.");
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    public static void main(String[] args) {
        try {
            URL url = U.getResourceAsUrl("/resources/fonts/inconsolata.ttf");
            InputStream is = url.openStream();
            Font font = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(13f);
            MetalLookAndFeel.setCurrentTheme(new io.github.xjrga.looks.themes.Dawn_150(font));
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (ClassNotFoundException
                | IllegalAccessException
                | InstantiationException
                | UnsupportedLookAndFeelException
                | FontFormatException
                | IOException e) {
        }
        TaskLauncher.start();
        FeedBackLauncher.start();
        Splash f = new Splash();
        f.initiate();
        try {
            new Main(f);
            Namer.threadName("Main");
        } catch (Exception e) {
            e.printStackTrace();
            f.halt();
        }
    }

    private JPanel getModelLogPanel() {
        JPanel pnl = new JPanel();
        FormLayout lyo = new FormLayout(
                "p,p:GROW", // columns
                "8px,FILL:28px,FILL:p:GROW" // rows
        );
        pnl.setLayout(lyo);
        tblLog = new TableLog();
        JScrollPane scrTable = new JScrollPane(tblLog);
        scrTable.setBorder(new TitledBorder("Log"));
        pnl.add(new JLabel("Search: "), cc.xy(1, 2));
        pnl.add(tblLog.getSearchField(), cc.xy(2, 2));
        pnl.add(scrTable, cc.xyw(1, 3, 2));
        tblLog.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent keyEvent) {
                if (keyEvent.getKeyCode() == KeyEvent.VK_DELETE) {
                    tblLog.clear();
                }
            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {
            }

            @Override
            public void keyTyped(KeyEvent keyEvent) {
            }

        });
        return pnl;
    }

    private void addLogEntry(
            String mix,
            String action,
            String type,
            String object,
            String mixid,
            String foodidA,
            String nutrientidA,
            String foodidB,
            String nutrientidB,
            Integer relationshipid,
            BigDecimal A,
            BigDecimal B) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String fnow = now.format(formatter);
        List row = new ArrayList();
        row.add(fnow);
        row.add(mix);
        row.add(action);
        row.add(type);
        row.add(object);
        row.add(mixid);
        row.add(foodidA);
        row.add(nutrientidA);
        row.add(foodidB);
        row.add(nutrientidB);
        row.add(relationshipid);
        row.add(A);
        row.add(B);
        tblLog.addRow(row);
    }

    private JPanel getFoodGroupsPanel() {
        tblSelectedFoods = new TableFood();
        tblFoodGroups = new TableGroups();
        tblFoodsInFoodGroup = new TableFood();
        JScrollPane scrSelectedFoods = new JScrollPane(tblSelectedFoods);
        scrSelectedFoods.setBorder(new TitledBorder("Selected Food"));
        JScrollPane scrFoodGroups = new JScrollPane(tblFoodGroups);
        scrFoodGroups.setBorder(new TitledBorder("Food Groups"));
        JScrollPane scrFoodsInFoodGroup = new JScrollPane(tblFoodsInFoodGroup);
        JTextField txtSearchFoodGroups = tblFoodGroups.getTxtSearch();
        JTextField txtSearchSelectedFoods = tblSelectedFoods.getTxtSearch();
        JTextField txtSearchFoodsInFoodGroup = tblFoodsInFoodGroup.getTxtSearch();
        JPanel pnlMain = new JPanel();
        JPanel pnlFoodGroups = new JPanel();
        JPanel pnlSelectedFoods = new JPanel();
        JPanel pnlFoodsInFoodGroup = new JPanel();
        JPanel pnlFoodGroupButtons = new JPanel();
        JPanel pnlFoodButtons = new JPanel();
        JPanel pnlButtons = new JPanel();
        FormLayout lyoMain = new FormLayout(
                "m:GROW,8px,m:GROW", // columns
                "FILL:200px,8px,FILL:min:GROW,min" // rows
        );
        FormLayout lyoFoodGroups = new FormLayout(
                "min,min:GROW", // columns
                "8px,FILL:28px,FILL:min:GROW" // rows
        );
        FormLayout lyoSelectedFoods = new FormLayout(
                "min,min:GROW", // columns
                "FILL:28px,FILL:min:GROW" // rows
        );
        FormLayout lyoFoodsInFoodGroup = new FormLayout(
                "min,min:GROW", // columns
                "FILL:28px,FILL:min:GROW" // rows
        );
        FormLayout lyoButtons = new FormLayout(
                "m:GROW,240px,150px,m:GROW", // columns
                "min,8px" // rows
        );
        JLabel lblSearchFoodGroups = new JLabel("Search: ");
        JLabel lblSearchSelectedFoods = new JLabel("Search: ");
        JLabel lblSearchFoodsInFoodGroup = new JLabel("Search: ");
        JButton btnAddFoodGroup = new JButton("+");
        JButton btnDeleteFoodGroup = new JButton("-");
        JButton btnRenameFoodGroup = new JButton("r");
        JButton btnDuplicateFoodGroup = new JButton("d");
        JButton btnAddFoodToFoodGroup = new JButton("+");
        JButton btnDeleteFoodFromFoodGroup = new JButton("-");
        pnlFoodGroups.setLayout(lyoFoodGroups);
        pnlFoodsInFoodGroup.setLayout(lyoFoodsInFoodGroup);
        lblSearchFoodGroups.setToolTipText(
                "Search field input should be a valid regex expression (case insensitive match)");
        lblSearchSelectedFoods.setToolTipText(
                "Search field input should be a valid regex expression (case insensitive match)");
        lblSearchFoodsInFoodGroup.setToolTipText(
                "Search field input should be a valid regex expression (case insensitive match)");
        pnlFoodGroupButtons.add(btnAddFoodGroup);
        pnlFoodGroupButtons.add(btnDeleteFoodGroup);
        pnlFoodGroupButtons.add(btnRenameFoodGroup);
        pnlFoodGroupButtons.add(btnDuplicateFoodGroup);
        pnlFoodGroupButtons.setBorder(new TitledBorder("Group"));
        pnlButtons.setLayout(lyoButtons);
        pnlButtons.add(pnlFoodGroupButtons, cc.xy(2, 1));
        pnlButtons.add(pnlFoodButtons, cc.xy(3, 1));
        pnlFoodButtons.add(btnAddFoodToFoodGroup);
        pnlFoodButtons.add(btnDeleteFoodFromFoodGroup);
        pnlFoodButtons.setBorder(new TitledBorder("Food"));
        btnAddFoodGroup.setToolTipText("Create food group");
        btnDeleteFoodGroup.setToolTipText("Delete food group");
        btnRenameFoodGroup.setToolTipText("Rename food group");
        btnDuplicateFoodGroup.setToolTipText("Duplicate food group");
        btnAddFoodToFoodGroup.setToolTipText("Add food item to food group");
        btnDeleteFoodFromFoodGroup.setToolTipText("Remove food item from food group");
        scrFoodsInFoodGroup.setBorder(new TitledBorder("Foods In Group"));
        pnlMain.setLayout(lyoMain);
        pnlSelectedFoods.setLayout(lyoSelectedFoods);
        pnlFoodGroups.add(lblSearchFoodGroups, cc.xy(1, 2));
        pnlFoodGroups.add(txtSearchFoodGroups, cc.xy(2, 2));
        pnlFoodGroups.add(scrFoodGroups, cc.xyw(1, 3, 2));
        pnlFoodsInFoodGroup.add(lblSearchFoodsInFoodGroup, cc.xy(1, 1));
        pnlFoodsInFoodGroup.add(txtSearchFoodsInFoodGroup, cc.xy(2, 1));
        pnlFoodsInFoodGroup.add(scrFoodsInFoodGroup, cc.xyw(1, 2, 2));
        pnlSelectedFoods.add(lblSearchSelectedFoods, cc.xy(1, 1));
        pnlSelectedFoods.add(txtSearchSelectedFoods, cc.xy(2, 1));
        pnlSelectedFoods.add(scrSelectedFoods, cc.xyw(1, 2, 2));
        pnlMain.add(pnlFoodGroups, cc.xyw(1, 1, 3));
        pnlMain.add(pnlSelectedFoods, cc.xy(1, 3));
        pnlMain.add(pnlFoodsInFoodGroup, cc.xy(3, 3));
        pnlMain.add(pnlButtons, cc.xyw(1, 4, 3));
        btnAddFoodGroup.addActionListener((ActionEvent evt) -> {
            addFoodGroup();
        });
        btnDeleteFoodGroup.addActionListener((ActionEvent evt) -> {
            deleteFoodGroup();
        });
        btnRenameFoodGroup.addActionListener((ActionEvent evt) -> {
            renameFoodGroup();
        });
        btnDuplicateFoodGroup.addActionListener((ActionEvent evt) -> {
            duplicateFoodGroup();
        });
        tblFoodGroups.getSelectionModel().addListSelectionListener((ListSelectionEvent a) -> {
            if (a.getValueIsAdjusting()) {
                return;
            }
            if (tblFoodGroups.isSelectionEmpty()) {
                return;
            }
            TableGroups.Row foodgroup = tblFoodGroups.getSelectedValue();
            try {
                Future<List<List>> task
                        = TaskLauncher.submit(new FoodsInFoodGroupTask(getSelectedMix().getMixid(), foodgroup.getGroupid()));
                List<List> categoryFoods = task.get();
                tblFoodsInFoodGroup.reload(categoryFoods);
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        });
        btnAddFoodToFoodGroup.addActionListener((ActionEvent evt) -> {
            addFoodToFoodGroup();
        });
        btnDeleteFoodFromFoodGroup.addActionListener((ActionEvent evt) -> {
            removeFoodFromFoodGroup();
        });
        return pnlMain;
    }

    private void addFoodGroup() {
        JTextField txtInput = new JTextField();
        JComponent[] inputs = {new JLabel("What is your new food group name?"), txtInput};
        if (!getSelectedMix().getMixid().isEmpty()) {
            int optionValue = Message.showOptionDialogOkCancel(inputs, "New Food Group");
            if (optionValue == 0) {
                String foodgroupname = txtInput.getText();
                if (foodgroupname != null && foodgroupname.length() > 0) {
                    try {
                        Future<String> task = TaskLauncher.submit(new InsertFoodGroupTask(getSelectedMix().getMixid(), foodgroupname));
                        String groupid = task.get();
                        if (task.isDone()) {
                            reloadGroups(getSelectedMix().getMixid());
                            int rowIndex = tblFoodGroups.find(groupid);
                            tblFoodGroups.selectRow(rowIndex);
                            tblFoodGroups.showRow(rowIndex);
                        }
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            }
        } else {
            Message.showMessage("Create or import mix");
        }
    }

    private void deleteFoodGroup() {
        if (!tblFoodGroups.isSelectionEmpty()) {
            TableGroups.Row foodgroup = tblFoodGroups.getSelectedValue();
            try {
                Future<Boolean> task
                        = TaskLauncher.submit(new DeleteFoodGroupTask(getSelectedMix().getMixid(), foodgroup.getGroupid()));
                task.get();
                if (task.isDone()) {
                    tblFoodsInFoodGroup.clear();
                    reloadGroups(getSelectedMix().getMixid());
                    Future<List<List>> task1 = TaskLauncher.submit(new GroupConstraintsTask(getSelectedMix().getMixid()));
                    List<List> constraints = task1.get();
                    tblGroupQuantityConstraint.reload(constraints);
                    setConstraintCounts();
                }
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void renameFoodGroup() {
        if (!tblFoodGroups.isSelectionEmpty()) {
            JTextField input = new JTextField();
            JComponent[] inputs = {new JLabel("What is your new food group name?"), input};
            int optionValue = Message.showOptionDialogOkCancel(inputs, "Update Food Group");
            if (optionValue == 0) {
                String foodgroupname = input.getText();
                if (foodgroupname != null && foodgroupname.length() > 0) {
                    TableGroups.Row foodgroup = tblFoodGroups.getSelectedValue();
                    try {
                        Future<Boolean> task = TaskLauncher.submit(
                                new UpdateFoodGroupTask(getSelectedMix().getMixid(), foodgroup.getGroupid(), foodgroupname));
                        task.get();
                        if (task.isDone()) {
                            reloadGroups(getSelectedMix().getMixid());
                            int rowIndex = tblFoodGroups.find(foodgroup.getGroupid());
                            tblFoodGroups.selectRow(rowIndex);
                            tblFoodGroups.showRow(rowIndex);
                            Future<List<List>> task1
                                    = TaskLauncher.submit(new GroupConstraintsTask(getSelectedMix().getMixid()));
                            List<List> constraints = task1.get();
                            tblGroupQuantityConstraint.reload(constraints);
                        }
                    } catch (Exception e) {
                        LoggerImpl.INSTANCE.logProblem(e);
                    }
                }
            }
        }
    }

    private void duplicateFoodGroup() {
        if (!tblFoodGroups.isSelectionEmpty()) {
            TableGroups.Row foodgroup = tblFoodGroups.getSelectedValue();
            try {
                Future<String> task
                        = TaskLauncher.submit(new DuplicateFoodGroupTask(getSelectedMix().getMixid(), foodgroup.getGroupid()));
                String foodgroupid = task.get();
                if (task.isDone()) {
                    reloadGroups(getSelectedMix().getMixid());
                    int rowIndex = tblFoodGroups.find(foodgroupid);
                    tblFoodGroups.selectRow(rowIndex);
                    tblFoodGroups.showRow(rowIndex);
                }
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }

    private void reloadGroups(String mixid) {
        try {
            Future<List<List>> task1 = TaskLauncher.submit(new FoodGroupsTask(mixid));
            List<List> list01 = task1.get();
            tblFoodGroups.reload(list01);
            Future<List<GroupDO>> task2 = TaskLauncher.submit(new FoodGroupsTaskGroupDO(mixid));
            List<GroupDO> list02 = task2.get();
            cmbFoodGroup.reload(list02);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void addFoodToFoodGroup() {
        if (tblSelectedFoods.isSelectionEmpty()) {
            return;
        }
        if (tblFoodGroups.isSelectionEmpty()) {
            return;
        }
        try {
            TableGroups.Row foodgroup = tblFoodGroups.getSelectedValue();
            TableFood.Row food = tblSelectedFoods.getSelectedValue();
            Future<String> task1 = TaskLauncher.submit(
                    new InsertGroupFoodTask(getSelectedMix().getMixid(), foodgroup.getGroupid(), food.getFoodid()));
            task1.get();
            Future<List<List>> task2
                    = TaskLauncher.submit(new FoodsInFoodGroupTask(getSelectedMix().getMixid(), foodgroup.getGroupid()));
            List<List> foodsInFoodGroup = task2.get();
            tblFoodsInFoodGroup.reload(foodsInFoodGroup);
            int rowIndex = tblFoodsInFoodGroup.find(food.getFoodid());
            tblFoodsInFoodGroup.selectRow(rowIndex);
            tblFoodsInFoodGroup.showRow(rowIndex);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private void removeFoodFromFoodGroup() {
        if (tblFoodGroups.isSelectionEmpty()) {
            return;
        }
        if (tblFoodsInFoodGroup.isSelectionEmpty()) {
            return;
        }
        TableGroups.Row foodgroup = tblFoodGroups.getSelectedValue();
        TableFood.Row food = tblFoodsInFoodGroup.getSelectedValue();
        try {
            Future<Boolean> task1 = TaskLauncher.submit(
                    new DeleteFoodInFoodGroupTask(foodgroup.getGroupid(), getSelectedMix().getMixid(), food.getFoodid()));
            task1.get();
            Future<List<List>> task2
                    = TaskLauncher.submit(new FoodsInFoodGroupTask(getSelectedMix().getMixid(), foodgroup.getGroupid()));
            List<List> foodsInFoodGroup = task2.get();
            tblFoodsInFoodGroup.reload(foodsInFoodGroup);
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private JPanel getGroupConstraintsPanel() {
        JPanel pnl = new JPanel();
        FormLayout panelLayout = new FormLayout(
                "min:GROW,250px:GROW,250px:GROW,45px,100px,28px,min:GROW", // columns
                "FILL:28px,FILL:145px:GROW,min" // rows
        );
        pnl.setLayout(panelLayout);
        tblGroupQuantityConstraint = new TableGroupQuantityConstraint();
        JScrollPane scrollPane = new JScrollPane(tblGroupQuantityConstraint);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JPanel buttons = new JPanel();
        pnl.add(cmbFoodGroup, cc.xy(2, 1));
        pnl.add(cmbGroupNutrient, cc.xy(3, 1));
        pnl.add(cmbGroupRelationship, cc.xy(4, 1));
        pnl.add(txtGroupQuantityValue, cc.xy(5, 1));
        pnl.add(scrollPane, cc.xyw(2, 2, 5));
        buttons.add(btnAddGroupQuantityConstraint);
        buttons.add(btnDeleteGroupQuantityConstraint);
        buttons.add(btnGroupBlock);
        pnl.add(buttons, cc.xyw(2, 3, 5));
        scrollPane.setBorder(new TitledBorder("Group Constraints"));
        cmbGroupNutrient.setMaximumRowCount(10);
        cmbGroupRelationship.setMaximumRowCount(3);
        cmbFoodGroup.setMaximumRowCount(10);
        btnAddGroupQuantityConstraint.setToolTipText("Add Constraint");
        btnDeleteGroupQuantityConstraint.setToolTipText("Delete Constraint");
        ((JLabel) cmbGroupRelationship.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        btnAddGroupQuantityConstraint.addActionListener((ActionEvent evt) -> {
            addGroupQuantityConstraint();
        });
        btnDeleteGroupQuantityConstraint.addActionListener((ActionEvent evt) -> {
            if (tblGroupQuantityConstraint.isSelectionEmpty()) {
                return;
            }
            deleteFoodGroupQuantityConstraint();
        });
        btnGroupBlock.addActionListener((ActionEvent evt) -> {
            blockGroup();
        });
        tblGroupQuantityConstraint.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            if (tblGroupQuantityConstraint.isSelectionEmpty()) {
                return;
            }
            setFoodGroupQuantityConstraintGuiValues();
        });
        return pnl;
    }

    private Double plusQuantity(Double oldq) {
        Double total = 0.0;
        JTextField txtInput = new JTextField();
        txtInput.setText("0.0");
        JPanel pnl = new JPanel();
        txtInput.setPreferredSize(new Dimension(50, 25));
        pnl.add(new JLabel("How much would like to add?"));
        pnl.add(txtInput);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Plus");
        if (optionValue == 0) {
            String s = txtInput.getText();
            if (s != null && s.length() > 0) {
                StringBuilder sb = new StringBuilder();
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(s);
                if (checkNumber.pass()) {
                    Double newq = Double.valueOf(s);
                    total = oldq + newq;
                } else {
                    Message.showMessage("Numbers only");
                }
            }
        } else {
            total = oldq;
        }
        return total;
    }

    private Double minusQuantity(Double oldq) {
        Double total = 0.0;
        JTextField txtInput = new JTextField();
        txtInput.setText("0.0");
        JPanel pnl = new JPanel();
        txtInput.setPreferredSize(new Dimension(50, 25));
        pnl.add(new JLabel("How much would like to subtract?"));
        pnl.add(txtInput);
        JComponent[] inputs = {pnl};
        int optionValue = Message.showOptionDialogOkCancel(inputs, "Minus");
        if (optionValue == 0) {
            String s = txtInput.getText();
            if (s != null && s.length() > 0) {
                StringBuilder sb = new StringBuilder();
                NumberCheck checkNumber = new NumberCheck();
                checkNumber.addToUncheckedList(s);
                if (checkNumber.pass()) {
                    Double newq = Double.valueOf(s);
                    total = oldq - newq;
                } else {
                    Message.showMessage("Numbers only");
                }
            }
        } else {
            total = oldq;
        }
        return total;
    }

    private void addGroupQuantityConstraint() {
        if (checkFoodGroupConstraint()) {
            NumberCheck numberCheck = new NumberCheck();
            numberCheck.addToUncheckedList(txtGroupQuantityValue.getText());
            if (numberCheck.pass()) {
                GroupDO groupDO = cmbFoodGroup.getSelectedItem();
                NutrientDO nutrientDO = cmbGroupNutrient.getSelectedItem();
                RelationshipDO relationshipDO = cmbGroupRelationship.getSelectedItem();
                BigDecimal b = new BigDecimal(txtGroupQuantityValue.getText());
                executeMergeGroupQuantityConstraintTasks(getSelectedMix(), groupDO, nutrientDO, relationshipDO, b);
            } else {
                Message.showMessage("Value must be a number greater than or equal to zero");
            }
        }
    }

    private void executeMergeGroupQuantityConstraintTasks(
            MixDO mix, GroupDO groupDO, NutrientDO nutrientDO, RelationshipDO relationshipDO, BigDecimal b) {
        try {
            Future<Boolean> task1 = TaskLauncher.submit(new MergeGroupConstraintTask(
                    mix.getMixid(),
                    groupDO.getGroupid(),
                    nutrientDO.getNutr_no(),
                    relationshipDO.getRelationshipid(),
                    b));
            task1.get();
            StringBuilder sb = new StringBuilder();
            sb.append(groupDO.getGroupname());
            sb.append(" using ");
            sb.append(nutrientDO.getNutrdesc());
            sb.append(" ");
            sb.append(relationshipDO.getName());
            sb.append(" ");
            sb.append((new DecimalFormat("######0.0#################")).format(b));
            addLogEntry(
                    getSelectedMix().getName(),
                    "Add",
                    "Group Quantity Constraint",
                    sb.toString(),
                    getSelectedMix().getMixid(),
                    groupDO.getGroupid(),
                    nutrientDO.getNutr_no(),
                    "",
                    "",
                    relationshipDO.getRelationshipid(),
                    b,
                    null);
            Future<List<List>> task2 = TaskLauncher.submit(new GroupConstraintsTask(mix.getMixid()));
            List<List> constraints = task2.get();
            tblGroupQuantityConstraint.reload(constraints);
            setConstraintCounts();
        } catch (Exception e) {
            LoggerImpl.INSTANCE.logProblem(e);
        }
    }

    private Boolean checkFoodGroupConstraint() {
        boolean flag_isReady = false;
        boolean flag_mix = false;
        boolean flag_listGroup = false;
        boolean flag_listNutrient = false;
        boolean flag_listRelationship = false;
        boolean flag_quantity = false;
        if (!getSelectedMix().getMixid().isEmpty()) {
            flag_mix = true;
        } else {
            Message.showMessage("Create or import mix");
        }
        if (!this.cmbFoodGroup.isSelectionEmpty()) {
            flag_listGroup = true;
        } else {
            Message.showMessage("Select group");
        }
        if (!this.cmbGroupNutrient.isSelectionEmpty()) {
            flag_listNutrient = true;
        } else {
            Message.showMessage("Select nutrient");
        }
        if (!cmbGroupRelationship.isSelectionEmpty()) {
            flag_listRelationship = true;
        } else {
            Message.showMessage("Select relationship");
        }
        if (!txtGroupQuantityValue.getText().isEmpty()) {
            flag_quantity = true;
        } else {
            Message.showMessage("Specify amount");
        }
        if (flag_listGroup && flag_listNutrient && flag_listRelationship && flag_quantity) {
            flag_isReady = true;
        }
        return flag_isReady;
    }

    private void deleteFoodGroupQuantityConstraint() {
        if (!tblGroupQuantityConstraint.isSelectionEmpty()) {
            TableGroupQuantityConstraint.Row row = tblGroupQuantityConstraint.getSelectedValue();
            String mixid = row.getMixid();
            String groupid = row.getGroupid();
            String nutrientid = row.getNutrientid();
            Integer relationshipid = row.getRelationshipid();
            try {
                Future<Boolean> task0 = TaskLauncher.submit(new DeleteFoodGroupConstraintTask(mixid, groupid, nutrientid, relationshipid));
                Boolean completed = task0.get();
                if (!completed) {
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(row.getGroup());
                sb.append(" using ");
                sb.append(row.getNutrient());
                sb.append(" ");
                sb.append(row.getRelationship());
                sb.append(" ");
                sb.append((new DecimalFormat("######0.0#################")).format(row.getB()));
                addLogEntry(
                        getSelectedMix().getName(),
                        "Delete",
                        "Group Quantity Constraint",
                        sb.toString(),
                        getSelectedMix().getMixid(),
                        row.getGroupid(),
                        row.getNutrientid(),
                        "",
                        "",
                        row.getRelationshipid(),
                        row.getB(),
                        null);
                Future<List<List>> task1 = TaskLauncher.submit(new GroupConstraintsTask(mixid));
                List<List> constraints = task1.get();
                tblGroupQuantityConstraint.reload(constraints);
                setConstraintCounts();
            } catch (Exception e) {
                LoggerImpl.INSTANCE.logProblem(e);
            }
        }
    }
}
