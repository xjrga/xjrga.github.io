package io.github.xjrga.snack.lp.mathprog;

public interface MathProgConstraint {
  String getLhs();

  String getRhs();
}
