package io.github.xjrga.snack.datamodel;

public interface Reload {

    void reload();
}
