#!/bin/bash

lp -d HP_LaserJet_1022 test.png
