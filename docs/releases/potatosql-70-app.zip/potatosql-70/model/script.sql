DROP SCHEMA IF EXISTS groceries;
/
CREATE SCHEMA groceries;
/
USE groceries;
/
CREATE TABLE aisle
(
        store_id INT,
        product_id INT,
        aisle VARCHAR(255),
        price DOUBLE,
        PRIMARY KEY (store_id,product_id)
);
/
CREATE TABLE cart
(
        visit_id INT,
        store_id INT,
        product_id INT,
        quantity DOUBLE,
        PRIMARY KEY (visit_id,store_id,product_id)
);
/
CREATE TABLE product
(
        product_id INT,
        product_name VARCHAR(255),
        product_size DOUBLE,
        PRIMARY KEY (product_id)
);
/
CREATE TABLE store
(
        store_id INT,
        store_name VARCHAR(255),
        store_address VARCHAR(255),
        PRIMARY KEY (store_id)
);
/
CREATE TABLE visit
(
        visit_id INT,
        visit_date DATE,
        starting_balance DOUBLE,
        ending_balance DOUBLE,
        PRIMARY KEY (visit_id)
);
/
ALTER TABLE cart ADD CONSTRAINT R0_visit_cart FOREIGN KEY (visit_id) REFERENCES visit (visit_id) ON DELETE CASCADE;
/
ALTER TABLE aisle ADD CONSTRAINT R1_store_aisle FOREIGN KEY (store_id) REFERENCES store (store_id) ON DELETE CASCADE;
/
ALTER TABLE cart ADD CONSTRAINT R2_aisle_cart FOREIGN KEY (store_id, product_id) REFERENCES aisle (store_id, product_id) ON DELETE CASCADE;
/
ALTER TABLE aisle ADD CONSTRAINT R3_product_aisle FOREIGN KEY (product_id) REFERENCES product (product_id) ON DELETE CASCADE;
/
