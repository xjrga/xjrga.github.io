DROP SCHEMA accounts IF EXISTS CASCADE;
/

CREATE SCHEMA accounts;
/

SET SCHEMA accounts;
/

CREATE TABLE account
(
account_id INTEGER,
account_number INTEGER,
account_name INTEGER,
CONSTRAINT account_primaryKey PRIMARY KEY (account_id)
);
/

CREATE TABLE account_transfer
(
source_account_id INTEGER,
target_account_id INTEGER,
account_transfer_name DOUBLE,
CONSTRAINT account_transfer_primaryKey PRIMARY KEY (source_account_id, target_account_id)
);
/

ALTER TABLE account_transfer ADD CONSTRAINT R0_account_account_transfer FOREIGN KEY ( source_account_id ) REFERENCES account ( account_id ) ON DELETE CASCADE;
/
ALTER TABLE account_transfer ADD CONSTRAINT R1_account_account_transfer FOREIGN KEY ( target_account_id ) REFERENCES account ( account_id ) ON DELETE CASCADE;
/

SET SCHEMA accounts;
/

CREATE PROCEDURE account_insert (
IN v_account_id INTEGER,
IN v_account_number INTEGER,
IN v_account_name INTEGER
)
MODIFIES SQL DATA BEGIN ATOMIC
INSERT INTO account (
account_id,
account_number,
account_name
) VALUES (
v_account_id,
v_account_number,
v_account_name
);
END;
/

CREATE PROCEDURE account_update (
IN v_account_id INTEGER,
IN v_account_number INTEGER,
IN v_account_name INTEGER
)
MODIFIES SQL DATA BEGIN ATOMIC
UPDATE
account
SET
account_number = v_account_number,
account_name = v_account_name
WHERE
account_id = v_account_id;
END;
/

CREATE PROCEDURE account_delete (
IN v_account_id INTEGER
)
MODIFIES SQL DATA BEGIN ATOMIC
DELETE FROM
account
WHERE
account_id = v_account_id;
END;
/

CREATE PROCEDURE account_merge (
IN v_account_id INTEGER,
IN v_account_number INTEGER,
IN v_account_name INTEGER
)
MODIFIES SQL DATA BEGIN ATOMIC
MERGE INTO account USING ( VALUES (
v_account_id,
v_account_number,
v_account_name
) ) ON (
account_id = v_account_id
)
WHEN MATCHED THEN UPDATE SET
account_number = v_account_number,
account_name = v_account_name
WHEN NOT MATCHED THEN INSERT VALUES
v_account_id,
v_account_number,
v_account_name;
END;
/

CREATE PROCEDURE account_select (
IN v_account_id INTEGER
)
MODIFIES SQL DATA DYNAMIC RESULT SETS 1 BEGIN ATOMIC
DECLARE result CURSOR
FOR
SELECT
account_id,
account_number,
account_name
FROM
account
WHERE
account_id = v_account_id;
OPEN result;
END;
/

CREATE PROCEDURE account_delete_all ()
MODIFIES SQL DATA BEGIN ATOMIC
DELETE FROM account;
END;
/

CREATE PROCEDURE account_select_all ()
MODIFIES SQL DATA DYNAMIC RESULT SETS 1 BEGIN ATOMIC
DECLARE result CURSOR
FOR
SELECT
account_id,
account_number,
account_name 
FROM
account;
OPEN result;
END;
/

CREATE FUNCTION account_count() RETURNS INTEGER
READS SQL DATA BEGIN ATOMIC
DECLARE v_count INTEGER;
SELECT COUNT(*) INTO v_count
FROM
account;
RETURN v_count;
END;
/

CREATE PROCEDURE account_transfer_insert (
IN v_source_account_id INTEGER,
IN v_target_account_id INTEGER,
IN v_account_transfer_name DOUBLE
)
MODIFIES SQL DATA BEGIN ATOMIC
INSERT INTO account_transfer (
source_account_id,
target_account_id,
account_transfer_name
) VALUES (
v_source_account_id,
v_target_account_id,
v_account_transfer_name
);
END;
/

CREATE PROCEDURE account_transfer_update (
IN v_source_account_id INTEGER,
IN v_target_account_id INTEGER,
IN v_account_transfer_name DOUBLE
)
MODIFIES SQL DATA BEGIN ATOMIC
UPDATE
account_transfer
SET
account_transfer_name = v_account_transfer_name
WHERE
source_account_id = v_source_account_id
AND
target_account_id = v_target_account_id;
END;
/

CREATE PROCEDURE account_transfer_delete (
IN v_source_account_id INTEGER,
IN v_target_account_id INTEGER
)
MODIFIES SQL DATA BEGIN ATOMIC
DELETE FROM
account_transfer
WHERE
source_account_id = v_source_account_id
AND
target_account_id = v_target_account_id;
END;
/

CREATE PROCEDURE account_transfer_merge (
IN v_source_account_id INTEGER,
IN v_target_account_id INTEGER,
IN v_account_transfer_name DOUBLE
)
MODIFIES SQL DATA BEGIN ATOMIC
MERGE INTO account_transfer USING ( VALUES (
v_source_account_id,
v_target_account_id,
v_account_transfer_name
) ) ON (
source_account_id = v_source_account_id
AND
target_account_id = v_target_account_id
)
WHEN MATCHED THEN UPDATE SET
account_transfer_name = v_account_transfer_name
WHEN NOT MATCHED THEN INSERT VALUES
v_source_account_id,
v_target_account_id,
v_account_transfer_name;
END;
/

CREATE PROCEDURE account_transfer_select (
IN v_source_account_id INTEGER,
IN v_target_account_id INTEGER
)
MODIFIES SQL DATA DYNAMIC RESULT SETS 1 BEGIN ATOMIC
DECLARE result CURSOR
FOR
SELECT
source_account_id,
target_account_id,
account_transfer_name
FROM
account_transfer
WHERE
source_account_id = v_source_account_id
AND
target_account_id = v_target_account_id;
OPEN result;
END;
/

CREATE PROCEDURE account_transfer_delete_all ()
MODIFIES SQL DATA BEGIN ATOMIC
DELETE FROM account_transfer;
END;
/

CREATE PROCEDURE account_transfer_select_all ()
MODIFIES SQL DATA DYNAMIC RESULT SETS 1 BEGIN ATOMIC
DECLARE result CURSOR
FOR
SELECT
source_account_id,
target_account_id,
account_transfer_name 
FROM
account_transfer;
OPEN result;
END;
/

CREATE FUNCTION account_transfer_count() RETURNS INTEGER
READS SQL DATA BEGIN ATOMIC
DECLARE v_count INTEGER;
SELECT COUNT(*) INTO v_count
FROM
account_transfer;
RETURN v_count;
END;
/

