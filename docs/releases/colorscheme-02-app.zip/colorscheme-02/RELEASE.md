[Looks](https://xjrga.github.io/looks "Color Scheme: Color Pick Tool and Eyedropper")

RELEASE NOTES

01

    Initial release

02

    Fix bug
