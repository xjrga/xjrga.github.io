package io.github.xjrga.snack.datamodel;

public interface ReloadMixid {

    void reload( String mixid );
}
