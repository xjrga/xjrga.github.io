package io.github.xjrga.snack.records;

import java.math.BigDecimal;
import java.util.Objects;

/**
 *
 * @author jr
 */
public class Records {

    public record Group(
            String MixId,
            String GroupId,
            String Name) {

        @Override
        public String toString() {
            return Name;
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 79 * hash + Objects.hashCode(this.MixId);
            hash = 79 * hash + Objects.hashCode(this.GroupId);
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final Group other = (Group) obj;
            if (!Objects.equals(this.MixId, other.MixId)) {
                return false;
            }
            return Objects.equals(this.GroupId, other.GroupId);
        }

    }

    public record Mix(
            String MixId,
            String MixName,
            Integer LifeStageId,
            String Model,
            BigDecimal Cost,
            BigDecimal TniScore) {}

    public record FoodDetails(
            String food_id,
            String food_name,
            BigDecimal carbohydrates_carbs_by_diff,
            BigDecimal carbohydrates_digestible,
            BigDecimal carbohydrates_fiber,
            BigDecimal carbohydrates_fiber_insoluble,
            BigDecimal carbohydrates_fiber_soluble,
            BigDecimal carbohydrates_fructose,
            BigDecimal carbohydrates_glucose,
            BigDecimal carbohydrates_glycemic_load,
            BigDecimal carbohydrates_lactose,
            BigDecimal carbohydrates_starch,
            BigDecimal carbohydrates_sucrose,
            BigDecimal carbohydrates_sugars,
            BigDecimal energy_alcohol,
            BigDecimal energy_carbohydrate,
            BigDecimal energy_dha,
            BigDecimal energy_digestible,
            BigDecimal energy_epa,
            BigDecimal energy_fat,
            BigDecimal energy_fat_and_carbohydrate,
            BigDecimal energy_gross,
            BigDecimal energy_hcsfa,
            BigDecimal energy_lcn3pufa,
            BigDecimal energy_linoleic,
            BigDecimal energy_linolenic,
            BigDecimal energy_monounsaturated,
            BigDecimal energy_polyunsaturated,
            BigDecimal energy_protein,
            BigDecimal energy_protein_and_carbohydrate,
            BigDecimal energy_saturated,
            BigDecimal fats_cholesterol,
            BigDecimal fats_dha,
            BigDecimal fats_epa,
            BigDecimal fats_hcsfa,
            BigDecimal fats_lauric,
            BigDecimal fats_lcn3pufa,
            BigDecimal fats_linoleic,
            BigDecimal fats_linolenic,
            BigDecimal fats_monounsaturated,
            BigDecimal fats_myristic,
            BigDecimal fats_palmitic,
            BigDecimal fats_polyunsaturated,
            BigDecimal fats_saturated,
            BigDecimal fats_stearic,
            BigDecimal fats_total,
            BigDecimal minerals_calcium,
            BigDecimal minerals_copper,
            BigDecimal minerals_iron,
            BigDecimal minerals_magnesium,
            BigDecimal minerals_manganese,
            BigDecimal minerals_phosphorus,
            BigDecimal minerals_potassium,
            BigDecimal minerals_selenium,
            BigDecimal minerals_sodium,
            BigDecimal minerals_zinc,
            BigDecimal other_alcohol,
            BigDecimal other_cost,
            BigDecimal other_water,
            BigDecimal other_weight,
            BigDecimal phytonutrients_anthocyanins,
            BigDecimal phytonutrients_beta_carotene,
            BigDecimal phytonutrients_caffeine,
            BigDecimal phytonutrients_carotenoids,
            BigDecimal phytonutrients_flavanols,
            BigDecimal phytonutrients_flavanones,
            BigDecimal phytonutrients_flavones,
            BigDecimal phytonutrients_flavonoids,
            BigDecimal phytonutrients_flavonols,
            BigDecimal phytonutrients_gamma_tocopherol,
            BigDecimal phytonutrients_isoflavones,
            BigDecimal phytonutrients_lutein_zeaxanthin,
            BigDecimal phytonutrients_lycopene,
            BigDecimal phytonutrients_phytosterols,
            BigDecimal phytonutrients_theobromine,
            BigDecimal protein_complete,
            BigDecimal protein_total,
            BigDecimal vitamins_choline,
            BigDecimal vitamins_folate,
            BigDecimal vitamins_niacin,
            BigDecimal vitamins_pantothenic_acid,
            BigDecimal vitamins_riboflavin,
            BigDecimal vitamins_thiamin,
            BigDecimal vitamins_vitamin_a,
            BigDecimal vitamins_vitamin_b6,
            BigDecimal vitamins_vitamin_b12,
            BigDecimal vitamins_vitamin_c,
            BigDecimal vitamins_vitamin_d,
            BigDecimal vitamins_vitamin_e,
            BigDecimal vitamins_vitamin_k
            ) {}

}
