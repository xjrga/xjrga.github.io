SET autocommit=1;
/
