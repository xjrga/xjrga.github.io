#!/bin/bash

rm snack*.lp
rm snack*.sol
