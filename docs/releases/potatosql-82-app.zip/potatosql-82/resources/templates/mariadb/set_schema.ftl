USE ${schema_name};
/
