package io.github.xjrga.snack.other;

import java.util.List;

/**
 * @author jr
 */
public interface Reload {

    void clear();


    void reload( List<List> data );
}
