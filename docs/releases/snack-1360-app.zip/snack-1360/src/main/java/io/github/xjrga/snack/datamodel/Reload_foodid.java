package io.github.xjrga.snack.datamodel;

public interface Reload_foodid {
  void reload(String foodid);
}
